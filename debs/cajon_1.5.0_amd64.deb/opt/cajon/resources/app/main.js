'use strict';
const { app, BrowserWindow, ipcMain, shell, protocol, net, nativeImage, clipboard, ClipboardItem, nativeTheme, screen } = require('electron');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const { pathToFileURL, fileURLToPath } = require('url');
const fsops = require('./lib/fsops');
const jobs = require('./lib/jobs');
const system = require('./lib/system');

app.setName('Cajón');
if (process.platform === 'linux') app.commandLine.appendSwitch('class', 'cajon');

protocol.registerSchemesAsPrivileged([
  { scheme: 'thumb', privileges: { standard: true, secure: true, supportFetchAPI: true, bypassCSP: true, stream: true } },
]);

/* ---------- configuración ---------- */
const CONFIG_DIR = path.join(process.env.XDG_CONFIG_HOME || path.join(require('os').homedir(), '.config'), 'cajon');
const CONFIG_FILE = path.join(CONFIG_DIR, 'config.json');
// datos internos de Chromium en ~/.config/cajon/datos (no directamente en ~/.config)
app.setPath('userData', path.join(CONFIG_DIR, 'datos'));
const DEFAULTS = {
  theme: 'system', accent: '#3b82f6', view: 'grid', zoom: 4, listZoom: 2, zoomScale: 2, showHidden: false, foldersFirst: true,
  singleClick: false, confirmTrash: false, thumbnails: true, restoreSession: true, sidebar: true, preview: false,
  sortKey: 'name', sortDir: 1, sidebarWidth: 236, previewWidth: 320, nativeFrame: false, session: null, bounds: null,
  showExtensions: true, collapsed: {}, printOpts: {}, tileZoom: 2, compactZoom: 2, galleryZoom: 2, groupBy: 'none', listCols: ['size', 'type', 'mtime'],
  colWidths: {}, gridInfo: 'none', thumbCrop: false, checkboxes: false, striped: true, rememberViews: false, folderViews: {},
};
let config = Object.assign({}, DEFAULTS);
try {
  const saved = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
  // versiones anteriores tenían menos tamaños de icono: traducir los índices guardados
  if (!saved.zoomScale) {
    const maps = { zoom: [2, 3, 4, 5, 7, 9], listZoom: [1, 2, 4], tileZoom: [1, 2, 3], compactZoom: [1, 2, 3], galleryZoom: [1, 2, 3] };
    for (const [k, m] of Object.entries(maps)) if (saved[k] != null) saved[k] = m[saved[k]] != null ? m[saved[k]] : DEFAULTS[k];
    saved.zoomScale = 2;
  }
  config = Object.assign({}, DEFAULTS, saved);
} catch (_) { /* primera vez */ }
let saveTimer = null;
function saveConfig() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { fs.mkdirSync(CONFIG_DIR, { recursive: true }); fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2)); } catch (_) { /* nada */ }
  }, 300);
}
function applyTheme() { nativeTheme.themeSource = config.theme === 'light' || config.theme === 'dark' ? config.theme : 'system'; }

/* ---------- argumentos ---------- */
function parseArgs(argv) {
  let rest = argv.slice(1);
  if (!app.isPackaged) {
    const appPath = app.getAppPath();
    const idx = argv.findIndex((a) => { try { return path.resolve(a) === appPath; } catch (_) { return false; } });
    rest = idx >= 0 ? argv.slice(idx + 1) : [];
  }
  const args = rest.filter((a) => a && !a.startsWith('-') && a !== '.');
  const out = [];
  for (let a of args) {
    try { if (a.startsWith('file://')) a = fileURLToPath(a); } catch (_) { continue; }
    a = path.resolve(a);
    try {
      const st = fs.statSync(a);
      out.push(st.isDirectory() ? { path: a } : { path: path.dirname(a), select: a });
    } catch (_) { /* no existe */ }
  }
  return out;
}

/* ---------- ventanas ---------- */
const windows = new Set();
const ICON = path.join(__dirname, 'renderer', 'assets', 'cajon.png');

function createWindow(start, opts = {}) {
  let b = config.bounds;
  if (b && opts.offset) b = Object.assign({}, b, { x: b.x + 30, y: b.y + 30 });
  const area = screen.getPrimaryDisplay().workAreaSize;
  const win = new BrowserWindow({
    width: b ? b.width : Math.min(1280, area.width - 80),
    height: b ? b.height : Math.min(820, area.height - 80),
    x: b ? b.x : undefined,
    y: b ? b.y : undefined,
    minWidth: 640,
    minHeight: 420,
    frame: !!config.nativeFrame,
    show: false,
    icon: ICON,
    backgroundColor: nativeTheme.shouldUseDarkColors ? '#17181c' : '#f6f7f9',
    title: 'Cajón',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      plugins: true,
      spellcheck: false,
    },
  });
  win.__start = start || null;
  win.__isPrimary = windows.size === 0;
  windows.add(win);
  if (config.bounds && config.bounds.maximized && !opts.offset) win.maximize();
  win.once('ready-to-show', () => win.show());
  win.webContents.on('did-finish-load', () => { win.webContents.setZoomFactor(1); win.webContents.setVisualZoomLevelLimits(1, 1).catch(() => {}); });
  win.webContents.on('zoom-changed', () => win.webContents.setZoomFactor(1));
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  const sendState = () => { if (!win.isDestroyed()) win.webContents.send('win:state', { maximized: win.isMaximized(), focused: win.isFocused() }); };
  win.on('maximize', sendState); win.on('unmaximize', sendState); win.on('focus', sendState); win.on('blur', sendState);
  win.on('close', () => {
    if (!win.isMaximized() && !win.isMinimized()) config.bounds = Object.assign({}, win.getBounds(), { maximized: false });
    else if (win.isMaximized()) config.bounds = Object.assign({}, config.bounds || win.getNormalBounds(), { maximized: true });
    saveConfig();
  });
  win.on('closed', () => windows.delete(win));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  return win;
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', (_e, argv) => {
    const targets = parseArgs(argv);
    if (targets.length) targets.forEach((t, i) => createWindow(t, { offset: i > 0 || windows.size > 0 }));
    else createWindow(null, { offset: true });
  });

  app.whenReady().then(() => {
    applyTheme();
    protocol.handle('thumb', async (req) => {
      try {
        const u = new URL(req.url);
        const p = u.searchParams.get('p');
        const s = Math.min(512, Math.max(64, Number(u.searchParams.get('s')) || 256));
        const r = await system.thumbnail(nativeImage, p, s);
        if (!r) return new Response('', { status: 404 });
        return net.fetch(pathToFileURL(r.file).href);
      } catch (_) { return new Response('', { status: 500 }); }
    });
    const targets = parseArgs(process.argv);
    if (targets.length) targets.forEach((t, i) => createWindow(t, { offset: i > 0 }));
    else createWindow(null);
  });
  app.on('window-all-closed', () => app.quit());
}

/* ---------- IPC ---------- */
function handle(channel, fn) {
  ipcMain.handle(channel, async (event, ...args) => {
    try { return { ok: true, data: await fn(event, ...args) }; } catch (e) { return { ok: false, error: friendlyError(e) }; }
  });
}
function friendlyError(e) {
  const m = {
    EACCES: 'Permiso denegado', EPERM: 'Operación no permitida', ENOENT: 'No existe el archivo o la carpeta',
    EEXIST: 'Ya existe un elemento con ese nombre', ENOTEMPTY: 'La carpeta no está vacía', ENOSPC: 'No queda espacio en el disco',
    EROFS: 'El sistema de archivos es de solo lectura', ENOTDIR: 'No es una carpeta', EISDIR: 'Es una carpeta', EBUSY: 'El recurso está ocupado',
  };
  return (e && e.code && m[e.code]) || (e && e.message) || String(e);
}

handle('app:init', (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  return {
    config, start: win ? win.__start : null, primary: win ? win.__isPrimary : false, home: fsops.HOME,
    places: fsops.userDirs(app), templatesDir: fsops.templatesDir(), version: app.getVersion(), user: require('os').userInfo().username,
    hostname: require('os').hostname(), dark: nativeTheme.shouldUseDarkColors,
  };
});
handle('config:set', (_e, patch) => {
  Object.assign(config, patch);
  if ('theme' in patch) applyTheme();
  saveConfig();
  for (const w of windows) if (!w.isDestroyed() && w.webContents !== _e.sender) w.webContents.send('config:changed', patch);
  return config;
});
nativeTheme.on('updated', () => { for (const w of windows) if (!w.isDestroyed()) w.webContents.send('theme:dark', nativeTheme.shouldUseDarkColors); });

handle('fs:list', (_e, dir) => fsops.listDir(dir));
handle('sys:users', () => fsops.usersMap());
handle('fs:stat', (_e, p) => fsops.statEntry(p));
handle('fs:details', (_e, p) => fsops.details(p));
handle('fs:statfs', (_e, p) => fsops.statfs(p));
handle('fs:exists', (_e, p) => fs.existsSync(p));
handle('fs:mkdir', (_e, dir, name) => fsops.mkdir(dir, name));
handle('fs:newfile', (_e, dir, name, content) => fsops.newFile(dir, name, content));
handle('fs:rename', (_e, p, name) => fsops.rename(p, name));
handle('fs:readText', (_e, p, max) => fsops.readText(p, max));
handle('fs:chmod', (_e, p, mode) => fsops.chmod(p, mode));
handle('fs:dirsize', (e, id, p) => fsops.dirSize(id, p, (prog) => { if (!e.sender.isDestroyed()) e.sender.send('dirsize:progress', prog); }));
handle('fs:dirsize:cancel', (_e, id) => fsops.cancelDirSize(id));
handle('fs:search', (e, id, root, q, opts) => { fsops.search(id, root, q, opts, (r) => { if (!e.sender.isDestroyed()) e.sender.send('search:results', r); }); return id; });
handle('fs:search:cancel', (_e, id) => fsops.cancelSearch(id));
handle('fs:watch', (e, id, dir) => fsops.watch(id, dir, (wid, d) => { if (!e.sender.isDestroyed()) e.sender.send('fs:changed', { id: wid, dir: d }); }));
handle('fs:unwatch', (_e, id) => fsops.unwatch(id));
handle('fs:sameDevice', async (_e, a, b) => { try { return (await fsp.stat(a)).dev === (await fsp.stat(b)).dev; } catch (_) { return false; } });

handle('places:bookmarks', () => fsops.getBookmarks());
handle('places:setBookmarks', (_e, list) => fsops.setBookmarks(list));
handle('places:recent', () => fsops.recent());
handle('places:drives', () => system.drives());
handle('drive:mount', (_e, dev) => system.mount(dev));
handle('drive:unmount', (_e, d) => system.unmount(d));
handle('drive:eject', (_e, d) => system.eject(d));

handle('trash:list', () => fsops.trashList());
handle('trash:count', () => fsops.trashCount());
handle('trash:restore', (_e, names) => fsops.trashRestore(names));
handle('trash:restoreByOrig', (_e, paths) => fsops.trashRestoreByOrig(paths));
handle('trash:delete', (_e, names) => fsops.trashDelete(names));
handle('trash:empty', () => fsops.trashEmpty());

handle('job:transfer', (e, op, sources, dest) => jobs.transfer(e.sender, op, sources, dest));
handle('job:trash', (e, paths) => jobs.trash(e.sender, shell, paths));
handle('job:delete', (e, paths) => jobs.deleteForever(e.sender, paths));
handle('job:compress', (e, paths, dest, name, format) => jobs.compress(e.sender, paths, dest, name, format));
handle('job:extract', (e, archive, dest) => jobs.extract(e.sender, archive, dest));
handle('job:cancel', (_e, id) => jobs.cancel(id));
handle('job:print', (e, files, opts) => jobs.print(e.sender, nativeImage, files, opts));
handle('print:printers', () => system.printers());
handle('print:settings', () => system.printerSettings());
handle('wallpaper:set', (_e, p, mode) => system.setWallpaper(nativeImage, p, mode));
handle('wallpaper:restore', (_e, prev) => system.restoreWallpaper(prev));
handle('wallpaper:settings', () => system.backgroundSettings());
handle('job:resolve', (_e, id, decision) => jobs.resolveConflict(id, decision));

handle('open:default', async (_e, p) => {
  const err = await shell.openPath(p);
  if (err) throw new Error(err);
  return true;
});
handle('open:apps', (_e, p) => system.appsFor(p));
handle('open:appIcon', (_e, id) => system.appIcon(id));
handle('open:with', (_e, id, paths) => system.launchApp(id, paths));
handle('open:setDefault', (_e, id, mime) => system.setDefaultApp(id, mime));
handle('open:terminal', (_e, dir) => system.openTerminal(dir));
handle('open:external', (_e, url) => shell.openExternal(url));
handle('open:newWindow', (_e, p) => { createWindow(p ? { path: p } : null, { offset: true }); return true; });
handle('thumbs:clear', () => system.clearThumbCache());

/* portapapeles compatible con Nemo/Nautilus (API de Electron 44+, asíncrona y con ClipboardItem) */
const RAW = (f) => `electron application/osclipboard;format="${f}"`;
handle('clipboard:write', async (_e, paths, cut) => {
  const uris = paths.map((p) => pathToFileURL(p).href);
  await clipboard.write([new ClipboardItem({
    [RAW('x-special/gnome-copied-files')]: new Blob([`${cut ? 'cut' : 'copy'}\n${uris.join('\n')}`]),
    [RAW('text/uri-list')]: new Blob([uris.join('\r\n') + '\r\n']),
    'text/plain': paths.join('\n'),
  })]);
  return true;
});
async function blobText(item, type) {
  try { const b = await item.getType(type); return typeof b === 'string' ? b : await b.text(); } catch (_) { return null; }
}
handle('clipboard:read', async () => {
  const parse = (txt) => txt.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.startsWith('file://')).map((u) => { try { return fileURLToPath(u); } catch (_) { return null; } }).filter(Boolean);
  let items = [];
  try { items = await clipboard.read(); } catch (_) { items = []; }
  for (const item of items) {
    const types = item.types || [];
    if (types.includes(RAW('x-special/gnome-copied-files'))) {
      const txt = (await blobText(item, RAW('x-special/gnome-copied-files'))) || '';
      const lines = txt.split(/\r?\n/);
      return { paths: parse(lines.slice(1).join('\n')), cut: lines[0].trim() === 'cut' };
    }
    if (types.includes(RAW('text/uri-list'))) {
      const txt = await blobText(item, RAW('text/uri-list'));
      if (txt) return { paths: parse(txt), cut: false };
    }
  }
  let text = '';
  try { text = await clipboard.readText(); } catch (_) { text = ''; }
  const asPaths = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (asPaths.length && asPaths.every((l) => l.startsWith('file://') || (path.isAbsolute(l) && fs.existsSync(l)))) {
    return { paths: asPaths.map((l) => (l.startsWith('file://') ? fileURLToPath(l) : l)), cut: false };
  }
  return { paths: [], cut: false };
});
handle('clipboard:text', async (_e, text) => { await clipboard.writeText(text); return true; });
/* copiar la imagen en sí (para pegarla en Word, LibreOffice, el correo…) */
async function writeClipImage(img) {
  const s = img.getSize();
  // las imágenes enormes se reducen para que los programas no se atasquen al pegar
  const MAX = 6000;
  if (s.width > MAX || s.height > MAX) img = s.width >= s.height ? img.resize({ width: MAX, quality: 'best' }) : img.resize({ height: MAX, quality: 'best' });
  const png = img.toPNG();
  await clipboard.write([new ClipboardItem({ 'image/png': new Blob([new Uint8Array(png)], { type: 'image/png' }) })]);
  return img.getSize();
}
handle('clipboard:image', async (_e, p) => {
  const img = nativeImage.createFromPath(p);
  if (img.isEmpty()) return { ok: false, unsupported: true };
  return Object.assign({ ok: true }, await writeClipImage(img));
});
handle('clipboard:imageData', async (_e, dataUrl) => {
  const img = nativeImage.createFromDataURL(dataUrl);
  if (img.isEmpty()) throw new Error('no se pudo leer la imagen');
  return Object.assign({ ok: true }, await writeClipImage(img));
});

/* ventana */
ipcMain.on('win:cmd', (e, cmd) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  if (!win) return;
  if (cmd === 'minimize') win.minimize();
  else if (cmd === 'maximize') { if (win.isMaximized()) win.unmaximize(); else win.maximize(); }
  else if (cmd === 'close') win.close();
  else if (cmd === 'devtools') win.webContents.toggleDevTools();
  else if (cmd === 'quit') app.quit();
});
ipcMain.on('win:title', (e, title) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  if (win) win.setTitle(title);
});
