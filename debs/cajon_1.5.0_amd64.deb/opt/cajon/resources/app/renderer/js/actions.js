'use strict';
/* Cajón — acciones sobre archivos, menús y atajos */

/* ---------- menús ---------- */
function sortMenu(p) {
  const k = p.sort.key;
  const keys = p.path === TRASH ? [['name', 'Nombre'], ['size', 'Tamaño'], ['deleted', 'Fecha de eliminación'], ['location', 'Ubicación original']]
    : [['name', p.path === RECENT && p.sort.recentDefault !== false ? 'Nombre (ahora: más reciente)' : 'Nombre'], ['size', 'Tamaño'], ['type', 'Tipo'], ['mtime', 'Fecha de modificación']];
  return [
    { header: 'Ordenar por' },
    ...keys.map(([key, label]) => ({ label, checked: k === key && !(p.path === RECENT && p.sort.recentDefault !== false && key === 'name'), action: () => { if (p.sort.key !== key || (p.path === RECENT && p.sort.recentDefault !== false)) { p.sort.key = key; p.sort.dir = key === 'mtime' || key === 'size' || key === 'deleted' ? -1 : 1; p.sort.recentDefault = false; setConfig({ sortKey: key, sortDir: p.sort.dir }); computeVisible(p); renderPane(p, { keepScroll: true }); } } })),
    '-',
    { label: 'Ascendente', checked: p.sort.dir > 0, action: () => { p.sort.dir = 1; p.sort.recentDefault = false; setConfig({ sortDir: 1 }); computeVisible(p); renderPane(p, { keepScroll: true }); } },
    { label: 'Descendente', checked: p.sort.dir < 0, action: () => { p.sort.dir = -1; p.sort.recentDefault = false; setConfig({ sortDir: -1 }); computeVisible(p); renderPane(p, { keepScroll: true }); } },
    '-',
    { label: 'Carpetas primero', checked: !!S.config.foldersFirst, action: () => { setConfig({ foldersFirst: !S.config.foldersFirst }); allPanes().forEach((pp) => { computeVisible(pp); pp.el && renderPane(pp, { keepScroll: true }); }); } },
    { label: 'Mostrar archivos ocultos', checked: !!S.config.showHidden, accel: 'Ctrl+H', action: toggleHidden },
  ];
}

function mainMenu() {
  const p = pane();
  const real = p.path && !isVirtual(p.path);
  return [
    { label: 'Nueva ventana', icon: 'window', accel: 'Ctrl+N', action: () => api.call('open:newWindow', real ? p.path : null) },
    { label: 'Nueva pestaña', icon: 'plus', accel: 'Ctrl+T', action: () => openTab(real ? p.path : S.home) },
    { label: 'Nueva carpeta', icon: 'newFolder', accel: 'Ctrl+Mayús+N', disabled: !real, action: () => newFolder(p) },
    '-',
    { label: 'Vista', icon: (VIEWS.find((x) => x.id === p.view) || VIEWS[0]).icon, submenu: viewSubmenu(p) },
    { label: 'Panel lateral', checked: !!S.config.sidebar, accel: 'F9', action: toggleSidebar },
    { label: 'Vista dividida', checked: tab().split, accel: 'F3', action: toggleSplit },
    { label: 'Panel de vista previa', checked: !!S.config.preview, accel: 'Alt+P', action: togglePreview },
    { label: 'Mostrar archivos ocultos', checked: !!S.config.showHidden, accel: 'Ctrl+H', action: toggleHidden },
    '-',
    { label: 'Tema', icon: S.dark ? 'moon' : 'sun', submenu: [
      { label: 'Según el sistema', checked: S.config.theme === 'system', action: () => { setConfig({ theme: 'system' }); applyTheme(); } },
      { label: 'Claro', checked: S.config.theme === 'light', action: () => { setConfig({ theme: 'light' }); applyTheme(); } },
      { label: 'Oscuro', checked: S.config.theme === 'dark', action: () => { setConfig({ theme: 'dark' }); applyTheme(); } },
    ] },
    { label: 'Abrir terminal aquí', icon: 'terminal', accel: 'F4', disabled: !real, action: () => openTerminal(p.path) },
    { label: 'Deshacer', icon: 'undo', accel: 'Ctrl+Z', disabled: !S.undo.length, action: undo },
    '-',
    { label: 'Preferencias', icon: 'settings', accel: 'Ctrl+,', action: showSettings },
    { label: 'Atajos de teclado', icon: 'keyboard', accel: 'F1', action: showShortcuts },
    { label: 'Acerca de Cajón', icon: 'info', action: showAbout },
  ];
}

function itemMenu(p) {
  const sel = selected(p);
  if (!sel.length) return backgroundMenu(p);
  const one = sel.length === 1 ? sel[0] : null;
  const allDirs = sel.every((e) => e.isDir);
  if (p.path === TRASH && !p.search) {
    return [
      { label: 'Restaurar', icon: 'rotateCcw', action: () => restoreTrash(sel) },
      { label: 'Eliminar definitivamente', icon: 'trash', danger: true, accel: 'Supr', action: () => deleteTrashItems(sel) },
      '-',
      one && one.isDir ? { label: 'Ver contenido', icon: 'folderOpen', action: () => navigate(p, one.path) } : null,
      { label: 'Vista previa', icon: 'eye', accel: 'Espacio', disabled: !one, action: () => quickLook(p) },
      { label: 'Propiedades', icon: 'info', accel: 'Alt+Intro', action: () => showProperties(sel.map((e) => e.path)) },
    ];
  }
  const inResults = !!p.search || p.path === RECENT;
  const readOnlyLoc = p.path === RECENT;
  const items = [
    { label: one && one.isDir ? 'Abrir' : sel.length > 1 ? `Abrir ${sel.length} elementos` : 'Abrir', icon: 'folderOpen', accel: 'Intro', action: () => openEntries(sel) },
    allDirs ? { label: 'Abrir en una pestaña nueva', icon: 'tab', accel: 'Ctrl+Intro', action: () => sel.forEach((e) => openTab(e.path, { background: sel.length > 1 })) } : null,
    one && one.isDir ? { label: 'Abrir en una ventana nueva', icon: 'window', action: () => api.call('open:newWindow', one.path) } : null,
    one && one.isDir && otherPane() ? { label: 'Abrir en el otro panel', icon: 'split', action: () => navigate(otherPane(), one.path) } : null,
    !allDirs && sel.every((e) => !e.isDir) ? { label: 'Abrir con', icon: 'external', submenu: () => openWithSubmenu(sel) } : null,
    one && isWallpaperable(one) ? { label: 'Establecer como fondo de pantalla', icon: 'wallpaper', submenu: wallpaperMenu(one) } : null,
    sel.some(isPrintable) ? { label: sel.length > 1 && sel.filter(isPrintable).length > 1 ? `Imprimir ${sel.filter(isPrintable).length} archivos…` : 'Imprimir…', icon: 'printer', accel: 'Ctrl+P', action: () => printDialog(sel) } : null,
    inResults ? { label: 'Abrir la carpeta contenedora', icon: 'folder', action: () => { const t = sel[0]; navigate(p, dirname(t.path), { select: [t.path] }); } } : null,
    '-',
    { label: 'Cortar', icon: 'cut', accel: 'Ctrl+X', disabled: readOnlyLoc, action: () => clipSet(sel.map((e) => e.path), true) },
    { label: 'Copiar', icon: 'copy', accel: 'Ctrl+C', action: () => clipSet(sel.map((e) => e.path), false) },
    one && isCopyableImage(one) ? { label: 'Copiar imagen', icon: 'copyImage', accel: 'Ctrl+Alt+C', action: () => copyImage(one) } : null,
    one && one.isDir ? { label: 'Pegar dentro de la carpeta', icon: 'paste', action: () => paste(one.path) } : null,
    otherPane() && otherPane().path && !isVirtual(otherPane().path) ? { label: 'Copiar al otro panel', icon: 'copy', accel: 'F5', action: () => transfer('copy', sel.map((e) => e.path), otherPane().path) } : null,
    otherPane() && otherPane().path && !isVirtual(otherPane().path) ? { label: 'Mover al otro panel', icon: 'cut', accel: 'F6', action: () => transfer('move', sel.map((e) => e.path), otherPane().path) } : null,
    { label: 'Copiar ruta', icon: 'link', accel: 'Ctrl+Mayús+C', action: () => copyPathText(sel.map((e) => e.path)) },
    '-',
    { label: sel.length > 1 ? 'Renombrar en lote…' : 'Renombrar…', icon: 'rename', accel: 'F2', disabled: readOnlyLoc && sel.length > 1, action: () => startRename(p) },
    { label: 'Mover a la papelera', icon: 'trash', accel: 'Supr', action: () => trashSelected(p) },
    { label: 'Eliminar definitivamente', icon: 'trash', danger: true, accel: 'Mayús+Supr', action: () => deleteSelected(p) },
    '-',
    { label: 'Comprimir…', icon: 'archive', action: () => compressDialog(sel) },
    sel.every((e) => FT.isArchive(e)) ? { label: 'Extraer aquí', icon: 'extract', action: () => sel.forEach((e) => extract(e.path, dirname(e.path))) } : null,
    sel.every((e) => FT.isArchive(e)) ? { label: 'Extraer en…', icon: 'extract', action: () => extractTo(sel) } : null,
    allDirs ? { label: 'Añadir a marcadores', icon: 'bookmark', accel: 'Ctrl+D', action: () => sel.forEach((e) => addBookmark(e.path)) } : null,
    one && one.isDir ? { label: 'Abrir en un terminal', icon: 'terminal', action: () => openTerminal(one.path) } : null,
    one && !one.isDir && one.exec ? { label: 'Ejecutar en un terminal', icon: 'terminal', action: () => openTerminal(dirname(one.path)) } : null,
    '-',
    { label: 'Vista previa', icon: 'eye', accel: 'Espacio', action: () => quickLook(p) },
    { label: 'Propiedades', icon: 'info', accel: 'Alt+Intro', action: () => showProperties(sel.map((e) => e.path)) },
  ];
  return items;
}

function backgroundMenu(p) {
  if (p.path === TRASH) {
    return [
      { label: 'Vaciar papelera', icon: 'trash', danger: true, disabled: !p.entries.length, action: emptyTrash },
      { label: 'Restaurar todo', icon: 'rotateCcw', disabled: !p.entries.length, action: () => restoreTrash(p.entries) },
      '-', { label: 'Seleccionar todo', icon: 'selectAll', accel: 'Ctrl+A', action: () => selectAll(p) },
      { label: 'Ordenar por', icon: 'sort', submenu: sortMenu(p) },
      { label: 'Vista', icon: 'grid', submenu: viewSubmenu(p) },
    ];
  }
  const real = p.path && !isVirtual(p.path) && !p.search;
  return [
    real ? { label: 'Nueva carpeta', icon: 'newFolder', accel: 'Ctrl+Mayús+N', action: () => newFolder(p) } : null,
    real ? { label: 'Nuevo archivo', icon: 'newFile', submenu: () => newFileSubmenu(p) } : null,
    real ? { label: 'Pegar', icon: 'paste', accel: 'Ctrl+V', action: () => paste(p.path) } : null,
    real ? '-' : null,
    { label: 'Seleccionar todo', icon: 'selectAll', accel: 'Ctrl+A', disabled: !p.visible.length, action: () => selectAll(p) },
    { label: 'Invertir selección', accel: 'Ctrl+Mayús+I', iconHtml: '', disabled: !p.visible.length, action: () => invertSelection(p) },
    '-',
    { label: 'Ordenar por', icon: 'sort', submenu: sortMenu(p) },
    { label: 'Vista', icon: (VIEWS.find((x) => x.id === p.view) || VIEWS[0]).icon, submenu: viewSubmenu(p) },
    { label: 'Actualizar', icon: 'refresh', accel: 'F5', action: () => reload(p, { keep: true }) },
    '-',
    real ? { label: 'Abrir terminal aquí', icon: 'terminal', accel: 'F4', action: () => openTerminal(p.path) } : null,
    real ? { label: 'Añadir a marcadores', icon: 'bookmark', accel: 'Ctrl+D', action: () => addBookmark(p.path) } : null,
    real ? { label: 'Propiedades', icon: 'info', action: () => showProperties([p.path]) } : null,
  ];
}
function viewSubmenu(p) {
  const noGroup = p.view === 'columns' || p.view === 'gallery';
  return [
    ...VIEWS.map((v) => ({ label: v.label, checked: p.view === v.id, accel: 'Ctrl+' + v.key, action: () => setView(p, v.id) })),
    '-',
    { label: 'Agrupar por', icon: 'group', disabled: noGroup, submenu: GROUP_BY.map(([k, l]) => ({ label: l, checked: (p.groupBy || 'none') === k, action: () => setGroupBy(p, k) })) },
    p.view === 'list' ? { label: 'Columnas', icon: 'table', submenu: columnMenu(p) } : null,
    p.view === 'grid' ? { label: 'Debajo del nombre', icon: 'info', submenu: [['none', 'Nada'], ['size', 'Tamaño'], ['mtime', 'Fecha'], ['type', 'Tipo']].map(([k, l]) => ({ label: l, checked: (S.config.gridInfo || 'none') === k, action: () => { setConfig({ gridInfo: k }); rerenderAll(); } })) } : null,
    '-',
    { label: 'Ampliar', icon: 'zoomIn', accel: 'Ctrl++', action: () => zoom(1) },
    { label: 'Reducir', icon: 'zoomOut', accel: 'Ctrl+-', action: () => zoom(-1) },
    { label: 'Tamaño normal', accel: 'Ctrl+0', iconHtml: '', action: resetZoom },
    '-',
    { label: 'Más opciones de vista…', icon: 'settings', action: () => showViewPopover($('#btn-view')) },
  ];
}
async function newFileSubmenu(p) {
  const items = [
    { label: 'Documento vacío', icon: 'newFile', action: () => newFile(p, 'Documento nuevo', '') },
    { label: 'Documento de texto (.txt)', icon: 'documents', action: () => newFile(p, 'Documento nuevo.txt', '') },
    { label: 'Markdown (.md)', icon: 'documents', action: () => newFile(p, 'Notas.md', '# Notas\n\n') },
    { label: 'Script de shell (.sh)', icon: 'terminal', action: () => newFile(p, 'script.sh', '#!/usr/bin/env bash\n\n', 0o755) },
    { label: 'Página web (.html)', icon: 'public', action: () => newFile(p, 'pagina.html', '<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="utf-8">\n  <title>Página</title>\n</head>\n<body>\n\n</body>\n</html>\n') },
  ];
  if (S.templatesDir) {
    try {
      const tpl = (await api.call('fs:list', S.templatesDir)).filter((e) => !e.isDir && !e.hidden).sort((a, b) => collator.compare(a.name, b.name));
      if (tpl.length) {
        items.push('-', { header: 'Plantillas' });
        for (const t of tpl.slice(0, 20)) items.push({ label: t.name.replace(/\.[^.]+$/, ''), iconHtml: `<span class="mini-fi">${fileSvg(FT.kind(t), '')}</span>`, action: () => newFromTemplate(p, t.path) });
      }
    } catch (_) { /* sin plantillas */ }
    items.push('-', { label: 'Abrir carpeta de plantillas', icon: 'templates', action: () => navigate(p, S.templatesDir) });
  }
  return items;
}

/* ---------- portapapeles ---------- */
function clipSet(paths, cut) {
  if (!paths.length) return;
  S.clip = { paths, cut, set: new Set(paths) };
  api.call('clipboard:write', paths, cut).catch(() => {});
  refreshCutClasses();
  toast(`${cut ? 'Cortado' : 'Copiado'}: ${paths.length === 1 ? `«${basename(paths[0])}»` : `${paths.length} elementos`}`, { icon: cut ? 'cut' : 'copy', timeout: 1800 });
}
async function paste(destDir) {
  if (!destDir || isVirtual(destDir)) return;
  let clip = null;
  try { clip = await api.call('clipboard:read'); } catch (_) { /* nada */ }
  let paths; let cut;
  if (clip && clip.paths.length) { paths = clip.paths; cut = clip.cut; }
  else if (S.clip) { paths = S.clip.paths; cut = S.clip.cut; }
  else { toast('No hay nada que pegar', { timeout: 1800 }); return; }
  transfer(cut ? 'move' : 'copy', paths, destDir);
  if (cut) { S.clip = null; api.call('clipboard:text', '').catch(() => {}); refreshCutClasses(); }
}
function copyPathText(paths) {
  api.call('clipboard:text', paths.join('\n'));
  toast(paths.length === 1 ? 'Ruta copiada' : `${paths.length} rutas copiadas`, { icon: 'link', timeout: 1600 });
}

/* ---------- trabajos en segundo plano ---------- */
const JOB_META = new Map();
async function transfer(op, sources, dest) {
  sources = sources.filter((s) => s !== dest);
  if (!sources.length) return;
  try {
    const id = await api.call('job:transfer', op, sources, dest);
    JOB_META.set(id, { op, sources, dest });
  } catch (e) { errorToast(e); }
}
function jobTitle(j) {
  const n = j.info.count;
  const what = n === 1 ? `«${j.info.name}»` : `${n} elementos`;
  const to = j.info.dest ? ` a «${displayName(j.info.dest)}»` : '';
  return {
    copy: `Copiando ${what}${to}`, move: `Moviendo ${what}${to}`, delete: `Eliminando ${what}`, trash: `Enviando ${what} a la papelera`,
    print: `Imprimiendo ${what} en «${j.info.dest}»`, compress: `Comprimiendo «${j.info.name}»`, extract: `Extrayendo «${j.info.name}»`,
  }[j.kind] || 'Trabajando…';
}
function onJobProgress(j) {
  let card = S.jobs.get(j.id);
  if (!card) {
    // se muestra solo si dura más de 400 ms
    if (!JOB_META.has('shown' + j.id)) {
      JOB_META.set('shown' + j.id, setTimeout(() => { JOB_META.set('shown' + j.id, true); const last = JOB_META.get('last' + j.id); if (last) onJobProgress(last); }, 400));
      JOB_META.set('last' + j.id, j);
      return;
    }
    if (JOB_META.get('shown' + j.id) !== true) { JOB_META.set('last' + j.id, j); return; }
    card = h('div', { class: 'job' },
      h('div', { class: 'job-top' }, h('span', { class: 'job-ic', html: ic(j.kind === 'trash' || j.kind === 'delete' ? 'trash' : j.kind === 'compress' ? 'archive' : j.kind === 'print' ? 'printer' : j.kind === 'extract' ? 'extract' : j.kind === 'move' ? 'cut' : 'copy') }),
        h('div', { class: 'job-title' }), h('button', { class: 'icon-btn tiny', title: 'Cancelar', html: ic('x'), onclick: () => api.call('job:cancel', j.id) })),
      h('div', { class: 'bar' }, h('span')), h('div', { class: 'job-sub' }));
    $('#jobs').appendChild(card);
    S.jobs.set(j.id, card);
  }
  $('.job-title', card).textContent = jobTitle(j);
  const bar = $('.bar', card);
  bar.classList.toggle('indeterminate', !!j.indeterminate || !j.total);
  const pct = j.total ? Math.min(100, (j.done / j.total) * 100) : 0;
  $('.bar span', card).style.width = pct + '%';
  let sub = '';
  if (j.kind === 'copy' || j.kind === 'move') sub = j.indeterminate ? 'Preparando…' : `${fmtSize(j.done)} de ${fmtSize(j.total)}${j.files > 1 ? ` · ${fmtNum(Math.min(j.filesDone, j.files))} de ${fmtNum(j.files)}` : ''}`;
  else if (j.kind === 'trash') sub = `${j.done} de ${j.total}`;
  else if (j.kind === 'print') sub = `${j.current ? esc(j.current) + ' · ' : ''}${j.done} de ${j.total}`;
  else sub = j.current ? esc(j.current) : '';
  $('.job-sub', card).innerHTML = sub;
}
async function onJobDone(r) {
  const t = JOB_META.get('shown' + r.id);
  if (t && t !== true) clearTimeout(t);
  JOB_META.delete('shown' + r.id); JOB_META.delete('last' + r.id);
  const card = S.jobs.get(r.id);
  if (card) { card.classList.add('out'); setTimeout(() => card.remove(), 250); S.jobs.delete(r.id); }
  const meta = JOB_META.get(r.id) || {};
  JOB_META.delete(r.id);
  const errors = r.errors || [];
  if (r.kind === 'copy' || r.kind === 'move') {
    const done = (r.results || []).filter((x) => !x.skipped);
    const dirs = new Set([meta.dest, ...(meta.sources || []).map(dirname)]);
    reloadDirs([...dirs]);
    if (r.cancelled) toast('Operación cancelada', { icon: 'x' });
    else if (errors.length) toast(errors.length === 1 ? errors[0] : `${errors.length} errores: ${errors[0]}`, { type: 'error' });
    if (done.length) {
      const targets = done.map((x) => x.target);
      if (r.kind === 'move') pushUndo({ type: 'move', moves: done.map((x) => ({ from: x.target, toDir: dirname(x.src) })) }, `${done.length === 1 ? `«${basename(done[0].target)}» movido` : `${done.length} elementos movidos`} a «${displayName(meta.dest)}»`);
      else pushUndo({ type: 'copy', created: targets }, `${done.length === 1 ? `«${basename(done[0].target)}» copiado` : `${done.length} elementos copiados`} a «${displayName(meta.dest)}»`);
      // seleccionar lo pegado si el destino está a la vista
      setTimeout(() => {
        for (const p of allPanes()) if (p.path === meta.dest) { p.sel = new Set(targets); p.focus = targets[0]; p.anchor = targets[0]; refreshSelectionClasses(p); scrollToItem(p, targets[0]); }
      }, 450);
    }
  } else if (r.kind === 'trash') {
    const ok = (r.results || []).filter((x) => x.ok).map((x) => x.path);
    reloadDirs([...new Set((r.results || []).map((x) => dirname(x.path)))]);
    refreshTrashCount();
    if (ok.length) pushUndo({ type: 'trash', paths: ok }, ok.length === 1 ? `«${basename(ok[0])}» se ha movido a la papelera` : `${ok.length} elementos movidos a la papelera`);
    if (r.failed && r.failed.length) {
      const names = r.failed.map((f) => basename(f.path));
      const go = await confirmDialog('No se puede usar la papelera', `${names.length === 1 ? `«${names[0]}»` : `${names.length} elementos`} no se pueden mover a la papelera (${r.failed[0].error}). ¿Quieres eliminarlos definitivamente?`, { okLabel: 'Eliminar definitivamente', danger: true, icon: 'alert' });
      if (go) startDelete(r.failed.map((f) => f.path));
    }
  } else if (r.kind === 'delete') {
    reloadAll();
    if (errors.length) toast(errors[0], { type: 'error' });
    else if (!r.cancelled) toast(r.info.count === 1 ? `«${r.info.name}» eliminado definitivamente` : `${r.info.count} elementos eliminados`, { icon: 'trash' });
  } else if (r.kind === 'print') {
    const ok = (r.results || []).length;
    if (r.cancelled) toast('Impresión cancelada', { icon: 'x' });
    if (errors.length) toast(errors.length === 1 ? `No se pudo imprimir ${errors[0]}` : `${errors.length} archivos no se pudieron imprimir: ${errors[0]}`, { type: 'error', timeout: 9000 });
    if (ok) toast(ok === 1 ? `«${basename(r.results[0].file)}» enviado a «${r.printer}»` : `${ok} archivos enviados a «${r.printer}»`, { icon: 'printer' });
  } else if (r.kind === 'compress' || r.kind === 'extract') {
    reloadAll();
    if (r.cancelled) toast('Operación cancelada', { icon: 'x' });
    else if (!r.ok) toast(`${r.kind === 'compress' ? 'Error al comprimir' : 'Error al extraer'}: ${errors[0] || ''}`, { type: 'error' });
    else {
      toast(`${r.kind === 'compress' ? 'Archivo creado' : 'Extraído en'}: «${basename(r.output)}»`, { icon: 'check', action: { label: 'Mostrar', fn: () => navigate(pane(), dirname(r.output), { select: [r.output] }) } });
      setTimeout(() => { for (const p of allPanes()) if (p.path === dirname(r.output)) { selectOnly(p, r.output); scrollToItem(p, r.output); } }, 450);
    }
  }
}
async function onJobConflict(c) {
  const srcI = c.srcInfo || {}; const dstI = c.dstInfo || {};
  const bothDirs = srcI.isDir && dstI.isDir;
  const name = basename(c.target);
  const all = h('input', { type: 'checkbox', id: 'cf-all' });
  const card = (title, info, path) => h('div', { class: 'cf-card' },
    h('div', { class: 'cf-ic', html: info.isDir ? folderSvg(null) : fileSvg(FT.kind({ name: basename(path), isDir: false }), FT.ext(basename(path))) }),
    h('div', { class: 'cf-info' }, h('div', { class: 'cf-t', text: title }), h('div', { class: 'cf-d', text: info.isDir ? 'Carpeta' : fmtSize(info.size) }), h('div', { class: 'cf-d', text: `Modificado: ${fmtDate(info.mtime)}` })));
  const newer = srcI.mtime > dstI.mtime ? 'El que vas a pegar es más reciente.' : srcI.mtime < dstI.mtime ? 'El que ya existe es más reciente.' : '';
  const body = h('div', { class: 'conflict' },
    h('p', { class: 'dlg-text', text: bothDirs ? `Ya existe una carpeta llamada «${name}» en «${displayName(dirname(c.target))}». Si las combinas, los archivos con el mismo nombre se reemplazarán.` : `Ya existe un elemento llamado «${name}» en «${displayName(dirname(c.target))}». ${newer}` }),
    h('div', { class: 'cf-cards' }, card('Original', dstI, c.target), card('Nuevo', srcI, c.src)),
    h('label', { class: 'check' }, all, h('span', { text: 'Aplicar a todos los conflictos' })));
  const action = await Dialog.open({
    title: bothDirs ? '¿Combinar carpetas?' : '¿Reemplazar el archivo?', body, width: 520, icon: ic('alert'),
    buttons: [{ label: 'Cancelar', value: 'cancel', ghost: true }, { spacer: true }, { label: 'Omitir', value: 'skip' }, { label: 'Mantener ambos', value: 'rename' }, { label: bothDirs ? 'Combinar' : 'Reemplazar', value: 'replace', primary: true }],
  });
  api.call('job:resolve', c.id, { action: action || 'cancel', all: all.checked });
}

/* ---------- papelera y borrado ---------- */
async function trashPaths(paths) {
  if (!paths.length) return;
  if (S.config.confirmTrash && !(await confirmDialog('Mover a la papelera', paths.length === 1 ? `¿Mover «${basename(paths[0])}» a la papelera?` : `¿Mover ${paths.length} elementos a la papelera?`, { okLabel: 'Mover a la papelera' }))) return;
  try { await api.call('job:trash', paths); } catch (e) { errorToast(e); }
}
function trashSelected(p) {
  if (p.path === TRASH && !p.search) { deleteTrashItems(selected(p)); return; }
  const sel = selected(p);
  if (!sel.length) return;
  moveFocusAfterRemoval(p, sel);
  trashPaths(sel.map((e) => e.path));
}
function moveFocusAfterRemoval(p, sel) {
  const set = new Set(sel.map((e) => e.path));
  const idx = p.visible.findIndex((e) => set.has(e.path));
  const rest = p.visible.filter((e) => !set.has(e.path));
  const next = rest[Math.min(idx, rest.length - 1)];
  if (next) { p.pendingFocus = next.path; setTimeout(() => { if (p.visible.some((e) => e.path === next.path)) selectOnly(p, next.path); }, 500); }
}
async function deleteSelected(p) {
  const sel = selected(p);
  if (!sel.length) return;
  if (p.path === TRASH && !p.search) { deleteTrashItems(sel); return; }
  const ok = await confirmDialog('¿Eliminar definitivamente?', sel.length === 1 ? `«${sel[0].name}» se eliminará para siempre. No se puede deshacer.` : `${sel.length} elementos se eliminarán para siempre. No se puede deshacer.`, { okLabel: 'Eliminar', danger: true, icon: 'alert' });
  if (!ok) return;
  moveFocusAfterRemoval(p, sel);
  startDelete(sel.map((e) => e.path));
}
async function startDelete(paths) { try { await api.call('job:delete', paths); } catch (e) { errorToast(e); } }
async function deleteTrashItems(items) {
  if (!items.length) return;
  const ok = await confirmDialog('¿Eliminar definitivamente?', items.length === 1 ? `«${items[0].name}» se eliminará para siempre.` : `${items.length} elementos se eliminarán para siempre.`, { okLabel: 'Eliminar', danger: true, icon: 'alert' });
  if (!ok) return;
  try { await api.call('trash:delete', items.map((e) => e.trashName)); } catch (e) { errorToast(e); }
  reloadAll();
}
async function emptyTrash() {
  const ok = await confirmDialog('¿Vaciar la papelera?', 'Todos los elementos de la papelera se eliminarán para siempre.', { okLabel: 'Vaciar papelera', danger: true, icon: 'trash' });
  if (!ok) return;
  try { await api.call('trash:empty'); toast('Papelera vaciada', { icon: 'trash' }); } catch (e) { errorToast(e); }
  reloadAll();
}
async function restoreTrash(items) {
  if (!items.length) return;
  try {
    const res = await api.call('trash:restore', items.map((e) => e.trashName));
    const bad = res.filter((r) => !r.ok);
    if (bad.length) toast(`No se pudieron restaurar ${bad.length}: ${bad[0].error}`, { type: 'error' });
    const good = res.filter((r) => r.ok);
    if (good.length) toast(good.length === 1 ? `Restaurado en «${prettyDir(dirname(good[0].dest))}»` : `${good.length} elementos restaurados`, { icon: 'rotateCcw', action: good.length === 1 ? { label: 'Mostrar', fn: () => navigate(pane(), dirname(good[0].dest), { select: [good[0].dest] }) } : null });
  } catch (e) { errorToast(e); }
  reloadAll();
}

/* ---------- crear ---------- */
async function newFolder(p) {
  if (!p.path || isVirtual(p.path)) return;
  try {
    const created = await api.call('fs:mkdir', p.path, 'Carpeta nueva');
    pushUndo({ type: 'create', path: created }, null);
    await reload(p, { keep: false });
    selectOnly(p, created);
    scrollToItem(p, created);
    startRename(p, { isNew: true });
  } catch (e) { errorToast(e, 'No se pudo crear la carpeta'); }
}
async function newFile(p, name, content, mode) {
  try {
    const created = await api.call('fs:newfile', p.path, name, content);
    if (mode) await api.call('fs:chmod', created, mode).catch(() => {});
    pushUndo({ type: 'create', path: created }, null);
    await reload(p, { keep: false });
    selectOnly(p, created);
    scrollToItem(p, created);
    startRename(p, { isNew: true });
  } catch (e) { errorToast(e, 'No se pudo crear el archivo'); }
}
function newFromTemplate(p, tplPath) { transfer('copy', [tplPath], p.path); }

/* ---------- renombrar ---------- */
function startRename(p, opts = {}) {
  const sel = selected(p);
  if (!sel.length) return;
  if (sel.length > 1) { batchRenameDialog(sel); return; }
  const e = sel[0];
  if (p.path === TRASH || p.path === RECENT || p.view === 'gallery') { renameDialog(e); return; }
  const el = elFor(p, e.path);
  if (!el) { renameDialog(e); return; }
  el.scrollIntoView({ block: 'nearest' });
  const nameEl = $('.name', el);
  const box = h(p.view === 'grid' ? 'textarea' : 'input', { class: 'rename-box', spellcheck: 'false', rows: '1' });
  const host = p.view === 'list' ? $('.c-name', el) : el;
  box.value = e.name;
  nameEl.style.visibility = 'hidden';
  el.classList.add('renaming');
  el.draggable = false;
  host.appendChild(box);
  const autosize = () => { if (box.tagName === 'TEXTAREA') { box.style.height = 'auto'; box.style.height = box.scrollHeight + 'px'; } };
  autosize();
  box.focus();
  const dot = e.isDir ? -1 : e.name.lastIndexOf('.');
  box.setSelectionRange(0, dot > 0 ? dot : e.name.length);
  let finished = false;
  p.renaming = true;
  const finish = async (commit) => {
    if (finished) return;
    finished = true;
    const v = box.value.trim().replace(/\n/g, ' ');
    box.remove();
    nameEl.style.visibility = '';
    el.classList.remove('renaming');
    el.draggable = true;
    p.renaming = false;
    p.viewEl.focus({ preventScroll: true });
    if (!commit || !v || v === e.name) {
      if (p.pendingReload) { p.pendingReload = false; reload(p, { keep: true }); }
      return;
    }
    p.pendingReload = false;
    await doRename(p, e, v);
  };
  box.addEventListener('keydown', (ev) => {
    ev.stopPropagation();
    if (ev.key === 'Enter') { ev.preventDefault(); finish(true); }
    else if (ev.key === 'Escape') { ev.preventDefault(); finish(false); }
    else if (ev.key === 'Tab') {
      ev.preventDefault();
      finish(true).then(() => {
        const idx = p.visible.findIndex((x) => x.path === e.path);
        const n = p.visible[idx + (ev.shiftKey ? -1 : 1)];
        if (n) { selectOnly(p, n.path); startRename(p); }
      });
    }
  });
  box.addEventListener('input', autosize);
  box.addEventListener('blur', () => finish(true));
  box.addEventListener('mousedown', (ev) => ev.stopPropagation());
  box.addEventListener('dblclick', (ev) => ev.stopPropagation());
  void opts;
}
async function doRename(p, e, newName) {
  if (newName.includes('/')) { toast('El nombre no puede contener «/»', { type: 'error' }); return; }
  try {
    const dest = await api.call('fs:rename', e.path, newName);
    pushUndo({ type: 'rename', path: dest, oldName: e.name }, null);
    await reload(p, { keep: false });
    selectOnly(p, dest);
    scrollToItem(p, dest);
    if (S.bookmarks.some((b) => b.path === e.path)) {
      const list = S.bookmarks.map((b) => (b.path === e.path ? { path: dest, label: b.label === e.name ? newName : b.label } : b));
      S.bookmarks = await api.call('places:setBookmarks', list); renderSidebar();
    }
  } catch (err) { errorToast(err, 'No se pudo renombrar'); }
}
async function renameDialog(e) {
  const v = await promptDialog(e.isDir ? 'Renombrar carpeta' : 'Renombrar archivo', { label: 'Nombre nuevo', value: e.name, selectBase: !e.isDir, okLabel: 'Renombrar', validate: (x) => (!x ? 'Escribe un nombre' : x.includes('/') ? 'No puede contener «/»' : null) });
  if (v && v !== e.name) doRename(pane(), e, v);
}

/* ---------- comprimir / extraer ---------- */
async function compressDialog(sel) {
  const paths = sel.map((e) => e.path);
  const dir = dirname(paths[0]);
  const def = sel.length === 1 ? sel[0].name.replace(/\.[^.]+$/, '') || sel[0].name : (pane().path && !isVirtual(pane().path) ? basename(pane().path) : 'Archivo');
  const input = h('input', { class: 'input', value: def, spellcheck: 'false' });
  let format = 'zip';
  const seg = h('div', { class: 'segmented' }, ...[['zip', '.zip', 'Compatible con todo'], ['tar.gz', '.tar.gz', 'Linux, rápido'], ['tar.xz', '.tar.xz', 'Máxima compresión'], ['7z', '.7z', 'Necesita p7zip']].map(([v, label, hint]) =>
    h('button', { class: `seg${v === format ? ' on' : ''}`, title: hint, onclick: (ev) => { format = v; $$('.seg', seg).forEach((b) => b.classList.remove('on')); ev.currentTarget.classList.add('on'); } }, h('b', { text: label }), h('small', { text: hint }))));
  const body = h('div', {}, h('div', { class: 'field' }, h('label', { text: 'Nombre del archivo' }), input), h('div', { class: 'field' }, h('label', { text: 'Formato' }), seg),
    h('p', { class: 'dlg-hint', text: `${plural(sel.length, 'elemento', 'elementos')} · se guardará en «${displayName(dir)}»` }));
  const r = await Dialog.open({ title: 'Comprimir', icon: ic('archive'), body, width: 480, buttons: [{ spacer: true }, { label: 'Cancelar', value: null }, { label: 'Crear', primary: true, value: () => input.value.trim() }], onOpen: () => setTimeout(() => input.select(), 40) });
  if (!r) return;
  try { await api.call('job:compress', paths, dir, r, format); } catch (e) { errorToast(e); }
}
async function extract(archive, dest) { try { await api.call('job:extract', archive, dest); } catch (e) { errorToast(e); } }
async function extractTo(sel) {
  const p2 = otherPane();
  const def = p2 && p2.path && !isVirtual(p2.path) ? p2.path : dirname(sel[0].path);
  const v = await promptDialog('Extraer en…', { label: 'Carpeta de destino', value: def, okLabel: 'Extraer' });
  if (!v) return;
  const dest = v.startsWith('~') ? S.home + v.slice(1) : v;
  try { const st = await api.call('fs:stat', dest); if (!st.isDir) throw new Error('No es una carpeta'); } catch (e) { errorToast(e, 'Destino no válido'); return; }
  sel.forEach((e) => extract(e.path, dest));
}

/* ---------- deshacer ---------- */
function pushUndo(entry, message) {
  S.undo.push(entry);
  if (S.undo.length > 50) S.undo.shift();
  if (message) toast(message, { icon: entry.type === 'trash' ? 'trash' : 'check', action: { label: 'Deshacer', fn: () => undoEntry(entry) } });
}
function undo() {
  const entry = S.undo.pop();
  if (!entry) { toast('No hay nada que deshacer', { timeout: 1500 }); return; }
  undoEntry(entry);
}
async function undoEntry(entry) {
  const i = S.undo.indexOf(entry);
  if (i >= 0) S.undo.splice(i, 1);
  try {
    if (entry.type === 'rename') {
      await api.call('fs:rename', entry.path, entry.oldName);
      toast(`Deshecho: vuelve a llamarse «${entry.oldName}»`, { icon: 'undo' });
      reloadDirs([dirname(entry.path)]);
    } else if (entry.type === 'renames') {
      for (const r of entry.list.slice().reverse()) await api.call('fs:rename', r.path, r.oldName).catch(() => {});
      toast('Renombrado en lote deshecho', { icon: 'undo' });
      reloadDirs([dirname(entry.list[0].path)]);
    } else if (entry.type === 'move') {
      const byDir = new Map();
      for (const m of entry.moves) { if (!byDir.has(m.toDir)) byDir.set(m.toDir, []); byDir.get(m.toDir).push(m.from); }
      for (const [dir, list] of byDir) await transfer('move', list, dir);
    } else if (entry.type === 'copy') {
      await api.call('job:trash', entry.created);
    } else if (entry.type === 'trash') {
      const res = await api.call('trash:restoreByOrig', entry.paths);
      const ok = res.filter((r) => r.ok).length;
      toast(ok ? `${ok === 1 ? 'Elemento restaurado' : `${ok} elementos restaurados`}` : 'No se pudo restaurar', { icon: 'undo', type: ok ? '' : 'error' });
      reloadDirs(entry.paths.map(dirname));
      refreshTrashCount();
    } else if (entry.type === 'create') {
      await api.call('job:trash', [entry.path]);
    }
  } catch (e) { errorToast(e, 'No se pudo deshacer'); }
}

/* ---------- teclado ---------- */
let typeBuf = ''; let typeTimer = null;
function isTyping(e) {
  const t = e.target;
  if (!t) return false;
  if (t.tagName === 'INPUT') return !['checkbox', 'radio', 'range', 'button', 'submit', 'color'].includes((t.type || '').toLowerCase());
  return t.tagName === 'TEXTAREA' || t.isContentEditable || t.tagName === 'SELECT';
}
function onKey(e) {
  if (Menu.isOpen()) { if (Menu.key(e)) { e.preventDefault(); e.stopPropagation(); } return; }
  if (Popover.isOpen() && e.key === 'Escape') { e.preventDefault(); Popover.close(); return; }
  if (QL.open) { if (QL.key(e)) { e.preventDefault(); e.stopPropagation(); } return; }
  if (Dialog.isOpen()) { if (Dialog.key(e)) { e.preventDefault(); e.stopPropagation(); } return; }
  const k = e.key;
  const ctrl = e.ctrlKey || e.metaKey;
  const p = pane();
  const typing = isTyping(e);

  const combo = (ctrl ? 'C-' : '') + (e.altKey ? 'A-' : '') + (e.shiftKey && (k.length > 1 || /[a-zA-Z]/.test(k)) ? 'S-' : '') + (k.length === 1 ? k.toLowerCase() : k);
  const global = {
    'C-t': () => openTab(p.path && !isVirtual(p.path) ? p.path : S.home),
    'C-w': () => closeTab(S.active),
    'C-n': () => api.call('open:newWindow', p.path && !isVirtual(p.path) ? p.path : null),
    'C-q': () => api.win('quit'),
    'C-Tab': () => switchTab((S.active + 1) % S.tabs.length),
    'C-S-Tab': () => switchTab((S.active - 1 + S.tabs.length) % S.tabs.length),
    'C-PageDown': () => switchTab((S.active + 1) % S.tabs.length),
    'C-PageUp': () => switchTab((S.active - 1 + S.tabs.length) % S.tabs.length),
    'C-l': () => editPath(true),
    'A-d': () => editPath(true),
    'C-f': () => toggleSearch(true),
    'C-h': toggleHidden,
    'C-r': () => reload(p, { keep: true }),
    'F5': () => { const o = otherPane(); if (o && selected(p).length && !typing && o.path && !isVirtual(o.path)) transfer('copy', selected(p).map((x) => x.path), o.path); else reload(p, { keep: true }); },
    'F6': () => { const o = otherPane(); if (o && selected(p).length && o.path && !isVirtual(o.path)) transfer('move', selected(p).map((x) => x.path), o.path); },
    'F3': toggleSplit,
    'F9': toggleSidebar,
    'A-p': togglePreview,
    'F4': () => { if (p.path && !isVirtual(p.path)) openTerminal(p.path); },
    'F1': showShortcuts,
    'C-?': showShortcuts,
    'C-,': showSettings,
    'A-ArrowLeft': () => goHistory(p, -1),
    'A-ArrowRight': () => goHistory(p, 1),
    'A-ArrowUp': () => goUp(p),
    'A-Home': () => navigate(p, S.home),
    'BrowserBack': () => goHistory(p, -1),
    'BrowserForward': () => goHistory(p, 1),
    'C-1': () => setView(p, 'grid'),
    'C-2': () => setView(p, 'list'),
    'C-=': () => { zoom(1); showZoomBadge(p); }, 'C-+': () => { zoom(1); showZoomBadge(p); }, 'C-S-+': () => { zoom(1); showZoomBadge(p); }, 'C--': () => { zoom(-1); showZoomBadge(p); }, 'C-0': resetZoom,
    'C-3': () => setView(p, 'tiles'), 'C-4': () => setView(p, 'compact'), 'C-5': () => setView(p, 'columns'), 'C-6': () => setView(p, 'gallery'),
    'C-d': () => addBookmark(p.path),
    'C-S-n': () => newFolder(p),
    'C-A-n': () => newFile(p, 'Documento nuevo.txt', ''),
    'F12': () => api.win('devtools'),
  };
  if (/^A-[1-9]$/.test(combo)) { e.preventDefault(); switchTab(Math.min(Number(combo[2]), S.tabs.length) - 1); return; }
  if (global[combo] && !(typing && ['C-h', 'C-1', 'C-2', 'C-3', 'C-4', 'C-5', 'C-6', 'C-d', 'C-0', 'C--', 'C-=', 'A-ArrowLeft', 'A-ArrowRight', 'A-ArrowUp'].includes(combo) && e.target.id !== 'search-input')) {
    if (typing && (combo === 'C-l' || combo === 'C-f') && e.target.id === (combo === 'C-l' ? 'path-input' : 'search-input')) return;
    e.preventDefault(); e.stopPropagation();
    global[combo]();
    return;
  }
  if (typing) return;
  const sel = selected(p);
  const fileKeys = {
    'Enter': () => openEntries(sel),
    'C-Enter': () => sel.filter((x) => x.isDir).forEach((x) => openTab(x.path, { background: true })),
    'A-Enter': () => showProperties(sel.length ? sel.map((x) => x.path) : (p.path && !isVirtual(p.path) ? [p.path] : [])),
    'Backspace': () => goUp(p),
    'F2': () => startRename(p),
    'Delete': () => trashSelected(p),
    'S-Delete': () => deleteSelected(p),
    'C-c': () => clipSet(sel.map((x) => x.path), false),
    'C-x': () => { if (p.path !== RECENT) clipSet(sel.map((x) => x.path), true); },
    'C-v': () => paste(p.path),
    'C-S-c': () => copyPathText(sel.length ? sel.map((x) => x.path) : [p.path]),
    'C-a': () => selectAll(p),
    'C-S-a': () => selectOnly(p, null),
    'C-S-i': () => invertSelection(p),
    'C-z': undo,
    'C-A-c': () => { const im = sel.length === 1 ? sel[0] : null; if (im && isCopyableImage(im)) copyImage(im); else toast('Selecciona una sola imagen para copiarla'); },
    'C-p': () => printSelected(p),
    ' ': () => quickLook(p),
    'Escape': () => { if (p.search || p.filter) toggleSearch(false); else selectOnly(p, null); },
  };
  if (fileKeys[combo]) { e.preventDefault(); fileKeys[combo](); return; }
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Home', 'End', 'PageUp', 'PageDown'].includes(k) && !e.altKey) {
    e.preventDefault();
    moveFocus(p, k, e.shiftKey, ctrl);
    return;
  }
  // búsqueda por tecleo
  if (k.length === 1 && !ctrl && !e.altKey && k !== ' ') {
    clearTimeout(typeTimer);
    typeBuf += k.toLowerCase();
    typeTimer = setTimeout(() => { typeBuf = ''; }, 900);
    const q = normalize(typeBuf);
    const found = p.visible.find((x) => normalize(x.name).startsWith(q)) || p.visible.find((x) => normalize(x.name).includes(q));
    if (found) { selectOnly(p, found.path); scrollToItem(p, found.path); }
  }
}
function gridColumns(p) {
  const els = itemEls(p);
  if (!['grid', 'tiles', 'compact'].includes(p.view) || els.length < 2) return 1;
  const top = els[0].offsetTop;
  let n = 0;
  while (n < els.length && els[n].offsetTop === top) n++;
  return Math.max(1, n);
}
function moveFocus(p, key, shift, ctrl) {
  const n = p.visible.length;
  if (!n) return;
  let i = p.visible.findIndex((x) => x.path === p.focus);
  const cols = gridColumns(p);
  const pageRows = Math.max(1, Math.floor(p.viewEl.clientHeight / ((itemEls(p)[0] || {}).offsetHeight || 40)) - 1);
  if (p.view === 'columns' && (key === 'ArrowLeft' || key === 'ArrowRight')) {
    if (key === 'ArrowLeft') { goUp(p); return; }
    const f = p.visible[i];
    if (f && f.isDir) navigate(p, f.path, { selectFirst: true });
    return;
  }
  const strip = p.view === 'gallery';
  const twoD = p.view === 'grid' || p.view === 'tiles' || p.view === 'compact' || strip;
  if (i < 0) i = key === 'End' ? n - 1 : 0;
  else if (strip && (key === 'ArrowDown' || key === 'ArrowRight')) i = i + 1;
  else if (strip && (key === 'ArrowUp' || key === 'ArrowLeft')) i = i - 1;
  else if (key === 'ArrowRight') i = twoD ? i + 1 : i;
  else if (key === 'ArrowLeft') i = twoD ? i - 1 : i;
  else if (key === 'ArrowDown') i = i + cols;
  else if (key === 'ArrowUp') i = i - cols;
  else if (key === 'Home') i = 0;
  else if (key === 'End') i = n - 1;
  else if (key === 'PageDown') i = i + cols * pageRows;
  else if (key === 'PageUp') i = i - cols * pageRows;
  i = Math.max(0, Math.min(n - 1, i));
  const path = p.visible[i].path;
  if (shift) selectRange(p, path, false);
  else if (ctrl) { p.focus = path; refreshSelectionClasses(p); }
  else selectOnly(p, path);
  if (!shift) p.anchor = path;
  scrollToItem(p, path);
}
