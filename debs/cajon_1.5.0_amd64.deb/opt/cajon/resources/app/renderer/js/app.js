'use strict';
/* Cajón — núcleo: estado, pestañas, paneles y vistas */
const api = window.cajon;
const GRID_SIZES = [32, 40, 48, 64, 80, 96, 112, 128, 160, 192, 224, 256];
const LIST_SIZES = [{ row: 24, icon: 16 }, { row: 28, icon: 18 }, { row: 34, icon: 22 }, { row: 40, icon: 26 }, { row: 48, icon: 32 }, { row: 58, icon: 42 }];
const TRASH = 'trash://';
const RECENT = 'recent://';
const collator = new Intl.Collator('es', { numeric: true, sensitivity: 'base' });

const S = {
  config: {}, home: '/', places: [], bookmarks: [], drives: [], trashCount: 0, templatesDir: null,
  tabs: [], active: 0, clip: null, undo: [], dark: false, nextId: 1, jobs: new Map(), user: '',
};

/* ---------- utilidades de estado ---------- */
function tab() { return S.tabs[S.active]; }
function pane() { const t = tab(); return t.panes[t.activePane] || t.panes[0]; }
function allPanes() { return S.tabs.flatMap((t) => t.panes); }
function isVirtual(p) { return p === TRASH || p === RECENT; }
function setConfig(patch) { Object.assign(S.config, patch); api.call('config:set', patch).catch(() => {}); }
function placeFor(p) { return S.places.find((x) => x.path === p); }
function glyphFor(p) { const pl = placeFor(p); return pl ? pl.key : null; }
function displayName(p) {
  if (p === TRASH) return 'Papelera';
  if (p === RECENT) return 'Recientes';
  if (p === '/') return 'Sistema de archivos';
  const pl = placeFor(p);
  if (pl) return pl.label;
  const d = S.drives.find((x) => x.mountpoint === p);
  if (d) return d.label;
  return basename(p);
}
function mountOf(p) {
  let best = '/';
  for (const d of S.drives) if (d.mountpoint && (p === d.mountpoint || p.startsWith(d.mountpoint + '/')) && d.mountpoint.length > best.length) best = d.mountpoint;
  return best;
}

/* ---------- modelo ---------- */
function newPane(path) {
  return {
    id: 'p' + S.nextId++, path: null, history: [], hIndex: -1, entries: [], visible: [], sel: new Set(), anchor: null, focus: null,
    view: VIEW_IDS.includes(S.config.view) ? S.config.view : 'grid', sort: { key: S.config.sortKey, dir: S.config.sortDir }, groupBy: S.config.groupBy || 'none', collapsed: new Set(), filter: '', search: null, loading: false, error: null,
    scrollMemo: new Map(), el: null, renderToken: 0, initial: path,
  };
}
function newTab(path) { return { id: 't' + S.nextId++, panes: [newPane(path)], activePane: 0, split: false }; }

/* ---------- inicio ---------- */
async function init() {
  const info = await api.call('app:init');
  try { S.users = await api.call('sys:users'); } catch (_) { S.users = {}; }
  S.config = info.config; S.home = info.home; S.places = info.places; S.dark = info.dark; S.user = info.user; S.templatesDir = info.templatesDir;
  applyTheme();
  buildChrome();
  let starts = [];
  if (info.start) starts = [info.start];
  else if (info.primary && S.config.restoreSession && S.config.session && S.config.session.length) starts = S.config.session.map((p) => ({ path: p }));
  if (!starts.length) starts = [{ path: S.home }];
  for (const st of starts) S.tabs.push(newTab(st.path));
  S.active = info.primary && !info.start && S.config.sessionActive != null ? Math.min(S.config.sessionActive, S.tabs.length - 1) : 0;
  renderTabs();
  renderPanes();
  await Promise.all(S.tabs.map(async (t, i) => {
    const p = t.panes[0];
    const st = starts[i];
    const ok = await navigate(p, st.path, { select: st.select ? [st.select] : null, silent: true });
    if (!ok) await navigate(p, S.home, { silent: true });
  }));
  refreshSidebar();
  setInterval(refreshDrives, 5000);
  api.on('fs:changed', ({ id }) => { const p = allPanes().find((x) => x.id === id); if (p) reload(p, { keep: true }); });
  api.on('theme:dark', (d) => { S.dark = d; applyTheme(); });
  api.on('config:changed', (patch) => { Object.assign(S.config, patch); applyTheme(); renderSidebar(); allPanes().forEach((p) => renderPane(p)); });
  api.on('win:state', (st) => { document.body.classList.toggle('maximized', st.maximized); document.body.classList.toggle('blurred', !st.focused); updateWinButtons(st.maximized); });
  api.on('search:results', onSearchResults);
  api.on('job:progress', onJobProgress);
  api.on('job:done', onJobDone);
  api.on('job:conflict', onJobConflict);
  window.addEventListener('beforeunload', saveSession);
  document.addEventListener('keydown', onKey, true);
  window.addEventListener('focus', () => { refreshTrashCount(); });
}

function saveSession() {
  const paths = S.tabs.map((t) => t.panes[t.activePane] ? t.panes[t.activePane].path : t.panes[0].path).filter((p) => p && !isVirtual(p));
  api.call('config:set', { session: paths, sessionActive: S.active }).catch(() => {});
}

function applyTheme() {
  const theme = S.config.theme === 'system' ? (S.dark ? 'dark' : 'light') : S.config.theme;
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.setProperty('--accent', S.config.accent || '#3b82f6');
  document.body.classList.toggle('native-frame', !!S.config.nativeFrame);
  document.body.classList.toggle('no-sidebar', !S.config.sidebar);
  document.body.classList.toggle('with-preview', !!S.config.preview);
  document.documentElement.style.setProperty('--sidebar-w', (S.config.sidebarWidth || 236) + 'px');
  document.documentElement.style.setProperty('--preview-w', (S.config.previewWidth || 320) + 'px');
}

/* ---------- estructura fija ---------- */
function buildChrome() {
  $('#btn-back').innerHTML = ic('back');
  $('#btn-forward').innerHTML = ic('forward');
  $('#btn-up').innerHTML = ic('up');
  $('#btn-search').innerHTML = ic('search');
  $('#btn-view').innerHTML = ic('grid');
  $('#btn-sort').innerHTML = ic('sort');
  $('#btn-split').innerHTML = ic('split');
  $('#btn-preview').innerHTML = ic('panelRight');
  $('#btn-menu').innerHTML = ic('menu');
  $('#btn-sidebar').innerHTML = ic('sidebar');
  $('#btn-newtab').innerHTML = ic('plus');
  $('#search-ic').innerHTML = ic('search');
  $('#search-clear').innerHTML = ic('x');
  $('#wc-min').innerHTML = ic('minimize');
  $('#wc-max').innerHTML = ic('maximize');
  $('#wc-close').innerHTML = ic('close');
  $('#sb-app-icon').innerHTML = '<img src="assets/cajon.png" alt="">';
  $('#zoom-out').innerHTML = ic('zoomOut');
  $('#zoom-in').innerHTML = ic('zoomIn');

  $('#btn-back').onclick = () => goHistory(pane(), -1);
  $('#btn-forward').onclick = () => goHistory(pane(), 1);
  $('#btn-up').onclick = () => goUp(pane());
  $('#btn-search').onclick = () => toggleSearch(true);
  $('#btn-view').onclick = (e) => showViewPopover(e.currentTarget);
  $('#btn-sort').onclick = (e) => Menu.showAt(sortMenu(pane()), e.currentTarget);
  $('#btn-split').onclick = () => toggleSplit();
  $('#btn-preview').onclick = () => togglePreview();
  $('#btn-menu').onclick = (e) => Menu.showAt(mainMenu(), e.currentTarget);
  $('#btn-sidebar').onclick = () => toggleSidebar();
  $('#btn-newtab').onclick = () => openTab(pane().path && !isVirtual(pane().path) ? pane().path : S.home);
  $('#wc-min').onclick = () => api.win('minimize');
  $('#wc-max').onclick = () => api.win('maximize');
  $('#wc-close').onclick = () => api.win('close');
  $('#zoom-out').onclick = () => zoom(-1);
  $('#zoom-in').onclick = () => zoom(1);
  $('#zoom-range').oninput = (e) => setZoom(Number(e.target.value));
  $('#headerbar').addEventListener('dblclick', (e) => { if (e.target.id === 'headerbar' || e.target.classList.contains('drag-space')) api.win('maximize'); });

  const si = $('#search-input');
  si.addEventListener('input', () => applyFilter(pane(), si.value));
  si.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); if (si.value.trim()) startSearch(pane(), si.value.trim()); }
    else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); toggleSearch(false); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); focusView(pane()); }
  });
  $('#search-clear').onclick = () => toggleSearch(false);

  initPathbar();
  initSidebarResize();
  initPreviewResize();
  initPreview();
}

function updateWinButtons(max) { $('#wc-max').innerHTML = ic(max ? 'restore' : 'maximize'); $('#wc-max').title = max ? 'Restaurar' : 'Maximizar'; }

/* ---------- pestañas ---------- */
function renderTabs() {
  const bar = $('#tabbar');
  const list = $('#tabs');
  bar.classList.toggle('hidden', S.tabs.length < 2);
  list.innerHTML = '';
  S.tabs.forEach((t, i) => {
    const p = t.panes[t.activePane] || t.panes[0];
    const title = p.search ? `Buscar «${p.search.query}»` : p.path ? displayName(p.path) : 'Cargando…';
    const el = h('div', { class: `tab${i === S.active ? ' active' : ''}`, title: p.path || '' },
      h('span', { class: 'tab-ic', html: p.path === TRASH ? ic('trash') : p.path === RECENT ? ic('recent') : p.search ? ic('search') : ic('folder') }),
      h('span', { class: 'tab-title', text: title }),
      h('button', { class: 'tab-close', title: 'Cerrar pestaña (Ctrl+W)', html: ic('x'), onclick: (e) => { e.stopPropagation(); closeTab(i); } }));
    el.addEventListener('mousedown', (e) => { if (e.button === 1) { e.preventDefault(); closeTab(i); } else if (e.button === 0) switchTab(i); });
    el.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      Menu.show([
        { label: 'Nueva pestaña', icon: 'plus', accel: 'Ctrl+T', action: () => openTab(p.path) },
        { label: 'Duplicar pestaña', icon: 'copy', action: () => openTab(p.path) },
        '-',
        { label: 'Cerrar pestaña', icon: 'x', accel: 'Ctrl+W', action: () => closeTab(i) },
        { label: 'Cerrar las demás pestañas', disabled: S.tabs.length < 2, action: () => { S.tabs.filter((_, j) => j !== i).forEach((tt) => tt.panes.forEach(disposePane)); S.tabs = [S.tabs[i]]; S.active = 0; renderTabs(); renderPanes(); } },
      ], e.clientX, e.clientY);
    });
    let hoverT = null;
    el.addEventListener('dragenter', () => { hoverT = setTimeout(() => switchTab(i), 600); });
    el.addEventListener('dragleave', () => clearTimeout(hoverT));
    el.addEventListener('drop', () => clearTimeout(hoverT));
    list.appendChild(el);
  });
  updateTitle();
}
async function openTab(path, opts = {}) {
  const t = newTab(path);
  S.tabs.splice(S.active + 1, 0, t);
  if (!opts.background) S.active = S.active + 1;
  renderTabs();
  renderPanes();
  await navigate(t.panes[0], path, { silent: true });
  renderTabs();
}
function closeTab(i) {
  if (S.tabs.length === 1) { api.win('close'); return; }
  S.tabs[i].panes.forEach(disposePane);
  S.tabs.splice(i, 1);
  if (S.active >= S.tabs.length) S.active = S.tabs.length - 1;
  else if (i < S.active) S.active--;
  renderTabs();
  renderPanes();
}
function switchTab(i) {
  if (i < 0 || i >= S.tabs.length || i === S.active) return;
  S.active = i;
  renderTabs();
  renderPanes();
}
function disposePane(p) {
  api.call('fs:unwatch', p.id).catch(() => {});
  if (p.search && p.search.running) api.call('fs:search:cancel', p.search.id).catch(() => {});
}

/* ---------- paneles ---------- */
function renderPanes() {
  const host = $('#panes');
  host.innerHTML = '';
  const t = tab();
  host.classList.toggle('split', t.split);
  t.panes.forEach((p, i) => {
    if (!p.el) buildPaneEl(p);
    p.el.classList.toggle('active', i === t.activePane);
    if (i > 0) host.appendChild(h('div', { class: 'pane-divider' }));
    host.appendChild(p.el);
    if (p.path) renderPane(p, { keepScroll: true });
  });
  updateChrome();
}

function buildPaneEl(p) {
  const el = h('section', { class: 'pane', 'data-pane': p.id });
  el.innerHTML = `
    <div class="pane-head"><span class="ph-ic"></span><span class="ph-title"></span><button class="icon-btn tiny ph-close" title="Cerrar vista dividida">${ic('x')}</button></div>
    <div class="banner hidden"></div>
    <div class="view" tabindex="0">
      <div class="list-header"></div>
      <div class="items"></div>
      <div class="empty hidden"></div>
      <div class="rubber hidden"></div>
    </div>`;
  p.el = el;
  p.viewEl = $('.view', el);
  p.itemsEl = $('.items', el);
  p.emptyEl = $('.empty', el);
  p.bannerEl = $('.banner', el);
  p.headerEl = $('.list-header', el);
  p.rubberEl = $('.rubber', el);
  $('.ph-close', el).onclick = (e) => { e.stopPropagation(); closeSplit(p); };
  el.addEventListener('mousedown', () => activatePane(p), true);
  attachViewEvents(p);
}

function activatePane(p) {
  const t = tab();
  const i = t.panes.indexOf(p);
  if (i < 0 || i === t.activePane) return;
  t.activePane = i;
  t.panes.forEach((pp, j) => pp.el && pp.el.classList.toggle('active', j === i));
  updateChrome();
  renderTabs();
}

function toggleSplit() {
  const t = tab();
  if (t.split) { closeSplit(t.panes[1]); return; }
  const cur = pane();
  const p2 = newPane(cur.path);
  p2.view = cur.view;
  t.panes.push(p2);
  t.split = true;
  t.activePane = 1;
  renderPanes();
  navigate(p2, cur.path && !isVirtual(cur.path) ? cur.path : S.home, { silent: true });
}
function closeSplit(p) {
  const t = tab();
  if (!t.split) return;
  const i = t.panes.indexOf(p);
  disposePane(p);
  t.panes.splice(i, 1);
  t.split = false;
  t.activePane = 0;
  renderPanes();
}
function otherPane() { const t = tab(); return t.split ? t.panes[1 - t.activePane] : null; }

/* ---------- navegación ---------- */
async function navigate(p, path, opts = {}) {
  if (!path) return false;
  if (path !== TRASH && path !== RECENT && path.length > 1) path = path.replace(/\/+$/, '');
  if (p.search) stopSearch(p, { keepFilter: false });
  const result = await loadPath(p, path, opts);
  if (!result) return false;
  if (p.path && p.viewEl) p.scrollMemo.set(p.path, p.viewEl.scrollTop);
  if (opts.history !== false && p.history[p.hIndex] !== path) {
    p.history = p.history.slice(0, p.hIndex + 1);
    p.history.push(path);
    p.hIndex = p.history.length - 1;
  }
  const prev = p.path;
  p.path = path;
  p.entries = result;
  p.filter = '';
  p.error = null;
  if (p === pane()) $('#search-input').value = '';
  p.sel = new Set();
  p.focus = null;
  p.anchor = null;
  if (opts.select) { opts.select.forEach((s) => p.sel.add(s)); p.focus = opts.select[0]; p.anchor = opts.select[0]; }
  else if (opts.fromChild) { p.sel.add(opts.fromChild); p.focus = opts.fromChild; p.anchor = opts.fromChild; }
  if (path !== prev) loadFolderView(p, path);
  computeVisible(p);
  if (opts.selectFirst && p.visible.length) { const f = p.visible[0].path; p.sel = new Set([f]); p.focus = f; p.anchor = f; }
  renderPane(p, { scrollTo: opts.select ? opts.select[0] : opts.fromChild || null, scrollTop: opts.history === false ? p.scrollMemo.get(path) : 0 });
  if (!isVirtual(path)) api.call('fs:watch', p.id, path).catch(() => {});
  else api.call('fs:unwatch', p.id).catch(() => {});
  if (prev !== path) { updateChrome(); renderTabs(); renderSidebarActive(); }
  return true;
}

async function loadPath(p, path, opts) {
  try {
    p.loading = true;
    if (path === TRASH) return await api.call('trash:list');
    if (path === RECENT) return await api.call('places:recent');
    return await api.call('fs:list', path);
  } catch (e) {
    if (!opts.silent) errorToast(e, `No se puede abrir «${displayName(path)}»`);
    return null;
  } finally { p.loading = false; }
}

async function reload(p, { keep } = {}) {
  if (!p.path || p.search) return;
  if (p.renaming) { p.pendingReload = true; return; }
  const path = p.path;
  let entries;
  try {
    if (path === TRASH) entries = await api.call('trash:list');
    else if (path === RECENT) entries = await api.call('places:recent');
    else entries = await api.call('fs:list', path);
  } catch (e) {
    // la carpeta desapareció: subir al primer padre existente
    let up = dirname(path);
    while (up !== '/' && !(await api.call('fs:exists', up).catch(() => false))) up = dirname(up);
    navigate(p, up, { silent: true });
    return;
  }
  if (p.path !== path) return;
  p.entries = entries;
  if (!keep) { p.sel.clear(); }
  else {
    const exists = new Set(entries.map((e) => e.path));
    for (const s of [...p.sel]) if (!exists.has(s)) p.sel.delete(s);
  }
  computeVisible(p);
  renderPane(p, { keepScroll: true });
  if (path === TRASH || p === pane()) refreshTrashCount();
}
function reloadDirs(dirs) {
  const set = new Set(dirs);
  for (const p of allPanes()) if (p.path && (set.has(p.path) || p.path === TRASH || p.path === RECENT)) reload(p, { keep: true });
}
function reloadAll() { allPanes().forEach((p) => reload(p, { keep: true })); refreshTrashCount(); }

function goHistory(p, delta) {
  const i = p.hIndex + delta;
  if (i < 0 || i >= p.history.length) return;
  const from = p.path;
  p.hIndex = i;
  navigate(p, p.history[i], { history: false, fromChild: delta < 0 && p.history[i] === dirname(from) ? from : null });
}
function goUp(p) {
  if (!p.path || p.path === '/' || isVirtual(p.path)) return;
  navigate(p, dirname(p.path), { fromChild: p.path });
}

/* ---------- ordenación, agrupación y filtro ---------- */
function sortCmp(p) {
  const { key } = p.sort;
  const byName = (a, b) => collator.compare(a.name, b.name);
  if (p.path === RECENT && !p.search && (p.sort.recentDefault !== false || key === 'recent')) return (a, b) => (b.recentTime || 0) - (a.recentTime || 0);
  switch (key) {
    case 'size': return (a, b) => (a.isDir && b.isDir ? (a.children || 0) - (b.children || 0) : a.size - b.size) || byName(a, b);
    case 'mtime': return (a, b) => a.mtime - b.mtime || byName(a, b);
    case 'btime': return (a, b) => (a.btime || 0) - (b.btime || 0) || byName(a, b);
    case 'atime': return (a, b) => (a.atime || 0) - (b.atime || 0) || byName(a, b);
    case 'type': return (a, b) => collator.compare(FT.typeName(a), FT.typeName(b)) || byName(a, b);
    case 'ext': return (a, b) => collator.compare(a.isDir ? '' : FT.ext(a.name), b.isDir ? '' : FT.ext(b.name)) || byName(a, b);
    case 'perms': return (a, b) => ((a.mode || 0) & 0o777) - ((b.mode || 0) & 0o777) || byName(a, b);
    case 'owner': return (a, b) => collator.compare(ownerName(a.uid), ownerName(b.uid)) || byName(a, b);
    case 'deleted': return (a, b) => (a.deletedAt || 0) - (b.deletedAt || 0) || byName(a, b);
    case 'location': return (a, b) => collator.compare(dirname(a.origPath || a.path), dirname(b.origPath || b.path)) || byName(a, b);
    default: return byName;
  }
}
function computeVisible(p) {
  let list = p.search ? p.search.results : p.entries;
  if (!S.config.showHidden && p.path !== TRASH) list = list.filter((e) => !e.hidden);
  if (p.filter) {
    const q = normalize(p.filter);
    list = list.filter((e) => normalize(e.name).includes(q));
  }
  const cmp = sortCmp(p);
  const dir = p.path === RECENT && !p.search && p.sort.recentDefault !== false ? 1 : p.sort.dir;
  const ff = S.config.foldersFirst;
  list = list.slice().sort((a, b) => {
    if (ff && a.isDir !== b.isDir) return a.isDir ? -1 : 1;
    return cmp(a, b) * dir;
  });
  p.visible = applyGrouping(p, list);
}
function applyFilter(p, text) {
  p.filter = p.search ? '' : text;
  computeVisible(p);
  renderPane(p);
}
function setSort(p, key) {
  if (p.sort.key === key && !(p.path === RECENT && p.sort.recentDefault !== false)) p.sort.dir = -p.sort.dir;
  else { p.sort.key = key; p.sort.dir = key === 'mtime' || key === 'size' || key === 'deleted' || key === 'btime' || key === 'atime' ? -1 : 1; }
  p.sort.recentDefault = false;
  persistSort(p);
}
function setView(p, view) {
  if (!VIEW_IDS.includes(view)) return;
  p.view = view;
  if (!S.config.rememberViews) setConfig({ view });
  saveFolderView(p);
  computeVisible(p);
  renderPane(p, { scrollTo: p.focus });
  updateChrome();
}
function zoom(d) {
  const v = pane().view;
  const z = zoomSpec(v);
  setZoom(Math.max(0, Math.min(z.max, zoomVal(v) + d)));
}
function setZoom(v) {
  const z = zoomSpec(pane().view);
  setConfig({ [z.key]: v });
  allPanes().forEach((pp) => pp.path && renderPane(pp, { keepScroll: true }));
  updateStatus();
}
function resetZoom() { setZoom(zoomSpec(pane().view).def); showZoomBadge(pane()); }
function showZoomBadge(p, limit) {
  if (!p || !p.el) return;
  let b = $('.zoom-badge', p.el);
  if (!b) { b = h('div', { class: 'zoom-badge' }); p.el.appendChild(b); }
  const z = zoomSpec(p.view);
  const v = zoomVal(p.view);
  const dots = Array.from({ length: z.max + 1 }, (_, i) => `<span class="zd${i <= v ? ' on' : ''}"></span>`).join('');
  b.innerHTML = `${ic(limit && v === 0 ? 'zoomOut' : 'zoomIn')}<span>${limit ? (v === 0 ? 'Tamaño mínimo' : 'Tamaño máximo') : 'Tamaño'}</span><span class="zdots">${dots}</span>`;
  b.classList.add('show');
  clearTimeout(b._t);
  b._t = setTimeout(() => b.classList.remove('show'), 900);
}
// evitar que Ctrl+rueda amplíe toda la ventana en cualquier otra zona
document.addEventListener('wheel', (e) => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });

/* ---------- renderizado de elementos ---------- */
function iconHtml(e, size) {
  if (e.isDir) return folderSvg(glyphFor(e.path) || (e.path === S.templatesDir ? 'templates' : null));
  const kind = FT.kind(e);
  const x = FT.ext(e.name);
  const label = x && x.length <= 5 && !x.includes('.') ? x : (kind === 'archive' && x ? x.split('.').pop() : '');
  let html = fileSvg(kind, size >= 40 ? label : '');
  if (S.config.thumbnails && FT.hasThumb(e) && !e.broken && size >= 22) {
    const s = size > 96 ? 512 : 256;
    html += `<img class="th" loading="lazy" decoding="async" draggable="false" src="thumb://t/?p=${encodeURIComponent(e.path)}&s=${s}&m=${Math.round(e.mtime)}">`;
  }
  return html;
}
const CHK = () => `<span class="chk" title="Seleccionar">${ic('check')}</span>`;
function gridSub(p, e) {
  const g = S.config.gridInfo;
  if (!g || g === 'none') return '';
  const t = g === 'size' ? sizeText(e) : g === 'mtime' ? fmtDate(dateOf(p, e)) : FT.typeName(e);
  return `<div class="sub">${esc(t)}</div>`;
}
function itemHtml(p, e, i, mode) {
  const cls = (p.sel.has(e.path) ? ' sel' : '') + (S.clip && S.clip.cut && S.clip.set.has(e.path) ? ' cut' : '') + (e.hidden ? ' hidden-file' : '');
  const attrs = `data-i="${i}" draggable="true" title="${esc(e.name)}"`;
  const link = e.isLink ? linkBadge() : '';
  const name = esc(S.config.showExtensions || e.isDir ? e.name : e.name.replace(/\.[^.]+$/, '') || e.name);
  const chk = S.config.checkboxes ? CHK() : '';
  if (mode === 'grid') {
    return `<div class="item${cls}" ${attrs}><div class="thumb">${iconHtml(e, GRID_SIZES[zoomVal('grid')])}${link}${chk}</div><div class="name">${name}</div>${gridSub(p, e)}</div>`;
  }
  if (mode === 'gallery') {
    return `<div class="item gitem${cls}" ${attrs}><div class="thumb">${iconHtml(e, GALLERY_SIZES[zoomVal('gallery')])}${link}</div><div class="name">${name}</div></div>`;
  }
  if (mode === 'tiles') {
    const t = TILE_SIZES[zoomVal('tiles')];
    return `<div class="item tile${cls}" ${attrs}>${chk}<div class="thumb">${iconHtml(e, t.icon)}${link}</div><div class="tinfo"><div class="name">${name}</div><div class="sub">${esc(FT.typeName(e))}</div><div class="sub dim2">${esc(sizeText(e))} · ${fmtDate(dateOf(p, e))}</div></div></div>`;
  }
  if (mode === 'compact') {
    const c = COMPACT_SIZES[zoomVal('compact')];
    return `<div class="item cmp${cls}" ${attrs}>${chk}<span class="ico" style="width:${c.icon}px;height:${c.icon}px">${iconHtml(e, c.icon)}${link}</span><span class="name">${name}</span></div>`;
  }
  if (mode === 'columns') {
    const ls = LIST_SIZES[zoomVal('columns')];
    return `<div class="item mrow${cls}" ${attrs}><span class="ico" style="width:${ls.icon}px;height:${ls.icon}px">${iconHtml(e, ls.icon)}${link}</span><span class="name">${name}</span>${e.isDir ? `<span class="mchev">${ic('chevronRight')}</span>` : ''}</div>`;
  }
  const ls = LIST_SIZES[zoomVal('list')];
  const cols = columnsFor(p).map((c) => `<div class="c c-${c}${COLS[c].align === 'right' ? ' r' : ''}">${COLS[c].html(e, p)}</div>`).join('');
  return `<div class="item row${cls}" ${attrs}><div class="c c-name">${chk}<span class="ico" style="width:${ls.icon}px;height:${ls.icon}px">${iconHtml(e, ls.icon)}${link}</span><span class="name">${name}</span></div>${cols}</div>`;
}
function sizeText(e) {
  if (e.isDir) return e.children == null ? '—' : plural(e.children, 'elemento', 'elementos');
  return fmtSize(e.size);
}
function prettyDir(d) {
  if (d === S.home) return 'Carpeta personal';
  if (d.startsWith(S.home + '/')) return '~' + d.slice(S.home.length);
  return d;
}

function renderPane(p, opts = {}) {
  if (!p.el) return;
  const v = p.viewEl;
  const prevScroll = v.scrollTop;
  if (!VIEW_IDS.includes(p.view)) p.view = 'grid';
  const mode = p.view;
  const wide = p.search || p.path === RECENT || p.path === TRASH;
  v.className = `view ${mode}` + (p.path === TRASH ? ' trash' : '') + (wide ? ' wide' : '') + (S.config.striped !== false ? ' striped' : '') +
    (S.config.checkboxes ? ' checks' : '') + (S.config.thumbCrop ? ' crop' : '') + (p.groups ? ' grouped' : '') + (p.sel.size ? ' has-sel' : '');
  const gs = GRID_SIZES[zoomVal('grid')];
  v.style.setProperty('--icon', gs + 'px');
  v.style.setProperty('--cell', Math.max(gs + 36, 100) + 'px');
  const ls = LIST_SIZES[zoomVal(mode === 'columns' ? 'columns' : 'list')];
  v.style.setProperty('--row', ls.row + 'px');
  const ts = TILE_SIZES[zoomVal('tiles')];
  v.style.setProperty('--ticon', ts.icon + 'px');
  v.style.setProperty('--tile-w', ts.w + 'px');
  const cs = COMPACT_SIZES[zoomVal('compact')];
  v.style.setProperty('--crow', cs.row + 'px');
  v.style.setProperty('--cicon', cs.icon + 'px');
  v.style.setProperty('--cw', cs.w + 'px');
  v.style.setProperty('--gthumb', GALLERY_SIZES[zoomVal('gallery')] + 'px');

  if (mode === 'list') renderListHeader(p); else p.headerEl.innerHTML = '';

  $('.ph-title', p.el).textContent = p.search ? `Resultados: «${p.search.query}»` : displayName(p.path || '');
  $('.ph-ic', p.el).innerHTML = ic(p.path === TRASH ? 'trash' : p.path === RECENT ? 'recent' : 'folder');
  renderBanner(p);

  const token = ++p.renderToken;
  // estructura según el modo
  if (mode === 'gallery') {
    if (!p.sel.size && p.visible.length) { const f = p.visible[0].path; p.sel.add(f); p.focus = f; p.anchor = f; v.classList.add('has-sel'); }
    p.itemsEl.innerHTML = '<div class="gal-stage"></div><div class="gal-strip"></div>';
    p.listEl = $('.gal-strip', p.itemsEl);
    p.stageEl = $('.gal-stage', p.itemsEl);
  } else if (mode === 'columns') {
    p.itemsEl.innerHTML = '<div class="mcols"><div class="mcol cur"></div><div class="mcol mnext hidden"></div></div>';
    p.listEl = $('.mcol.cur', p.itemsEl);
    p.listEl.dataset.dir = p.path && !isVirtual(p.path) && !p.search ? p.path : '';
    p.stageEl = null;
    renderAncestorColumns(p, token);
  } else { p.listEl = p.itemsEl; p.stageEl = null; }

  // elementos (por bloques para carpetas grandes)
  const seq = buildSeq(p);
  const tokHtml = (t) => (t < 0 ? groupHeadHtml(p.groups[-1 - t]) : itemHtml(p, p.visible[t], t, mode));
  const FIRST = 400;
  let html = '';
  for (let k = 0; k < Math.min(FIRST, seq.length); k++) html += tokHtml(seq[k]);
  p.listEl.innerHTML = html;
  let done = Math.min(FIRST, seq.length);
  const finished = () => {
    if (opts.scrollTo) scrollToItem(p, opts.scrollTo);
    if (mode === 'columns') updateNextColumn(p);
    if (mode === 'gallery') { renderStage(p); if (p.focus) scrollToItem(p, p.focus); }
  };
  const more = () => {
    if (token !== p.renderToken) return;
    const end = Math.min(done + 800, seq.length);
    let chunk = '';
    for (let k = done; k < end; k++) chunk += tokHtml(seq[k]);
    p.listEl.insertAdjacentHTML('beforeend', chunk);
    done = end;
    if (done < seq.length) setTimeout(more, 16); else finished();
  };
  if (done < seq.length) setTimeout(more, 16);

  // estado vacío
  const empty = p.visible.length === 0 && !p.loading && !(p.groups && p.groups.length);
  p.emptyEl.classList.toggle('hidden', !empty || mode === 'columns');
  if (empty) {
    let icon = 'folderOpen'; let title = 'Carpeta vacía'; let sub = 'Arrastra archivos aquí o crea algo nuevo.';
    if (p.search) { icon = 'search'; title = p.search.running ? 'Buscando…' : 'Sin resultados'; sub = p.search.running ? '' : `No se ha encontrado nada que contenga «${p.search.query}».`; }
    else if (p.filter) { icon = 'search'; title = 'Sin coincidencias'; sub = 'Pulsa Intro para buscar también en las subcarpetas.'; }
    else if (p.path === TRASH) { icon = 'trash'; title = 'La papelera está vacía'; sub = 'Los elementos que elimines aparecerán aquí.'; }
    else if (p.path === RECENT) { icon = 'recent'; title = 'No hay archivos recientes'; sub = ''; }
    else if (p.entries.length && !S.config.showHidden) { icon = 'eyeOff'; title = 'Solo hay archivos ocultos'; sub = 'Pulsa Ctrl+H para mostrarlos.'; }
    p.emptyEl.innerHTML = `<div class="empty-ic">${ic(icon)}</div><div class="empty-title">${esc(title)}</div><div class="empty-sub">${esc(sub)}</div>`;
    if (mode === 'columns') p.listEl.innerHTML = `<div class="mcol-empty">${esc(title)}</div>`;
  }

  if (mode === 'columns' || mode === 'gallery') v.scrollTop = 0;
  else if (opts.scrollTo) requestAnimationFrame(() => scrollToItem(p, opts.scrollTo));
  else if (opts.keepScroll) v.scrollTop = prevScroll;
  else v.scrollTop = opts.scrollTop || 0;
  if (done >= seq.length) finished();
  if (p === pane()) { updateStatus(); schedulePreview(); }
}

function renderBanner(p) {
  const b = p.bannerEl;
  let html = '';
  if (p.search) {
    const s = p.search;
    html = `<span class="bn-ic">${ic(s.running ? 'search' : 'check')}</span><span class="bn-text">${s.running ? 'Buscando' : 'Búsqueda terminada'}: <b>«${esc(s.query)}»</b> en ${esc(displayName(s.root))} · ${plural(s.results.length, 'resultado', 'resultados')}${s.count >= 5000 ? ' (límite alcanzado)' : ''}</span>${s.running ? '<span class="spinner"></span>' : ''}<span class="spacer"></span>${s.running ? `<button class="btn small" data-act="stop">${ic('stop')}Detener</button>` : ''}<button class="btn small ghost" data-act="close">Cerrar búsqueda</button>`;
  } else if (p.path === TRASH && p.entries.length) {
    html = `<span class="bn-ic">${ic('trash')}</span><span class="bn-text">${plural(p.entries.length, 'elemento', 'elementos')} en la papelera</span><span class="spacer"></span><button class="btn small" data-act="restore-all">${ic('rotateCcw')}Restaurar todo</button><button class="btn small danger" data-act="empty">Vaciar papelera</button>`;
  }
  b.classList.toggle('hidden', !html);
  b.innerHTML = html;
  $$('button', b).forEach((btn) => {
    btn.onclick = () => {
      const a = btn.dataset.act;
      if (a === 'stop') stopSearch(p, { keepResults: true });
      else if (a === 'close') { stopSearch(p, {}); toggleSearch(false); }
      else if (a === 'empty') emptyTrash();
      else if (a === 'restore-all') restoreTrash(p.entries);
    };
  });
}

const NO_ITEMS = [];
function itemEls(p) { return p.listEl ? p.listEl.getElementsByClassName('item') : NO_ITEMS; }
function elFor(p, path) {
  const i = p.visible.findIndex((e) => e.path === path);
  return i >= 0 ? itemEls(p)[i] || null : null;
}
function scrollToItem(p, path) {
  const el = elFor(p, path);
  if (el) el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}
function refreshSelectionClasses(p) {
  const els = itemEls(p);
  for (let i = 0; i < els.length; i++) {
    const e = p.visible[i];
    if (!e) continue;
    els[i].classList.toggle('sel', p.sel.has(e.path));
    els[i].classList.toggle('focus', p.focus === e.path && document.activeElement === p.viewEl);
  }
  if (p.viewEl) p.viewEl.classList.toggle('has-sel', p.sel.size > 0);
  if (p.view === 'gallery') scheduleStage(p);
  if (p.view === 'columns') scheduleNextColumn(p);
  if (p === pane()) { updateStatus(); schedulePreview(); }
}
function refreshCutClasses() {
  for (const p of allPanes()) {
    if (!p.el) continue;
    const els = itemEls(p);
    for (let i = 0; i < els.length; i++) { const e = p.visible[i]; if (e) els[i].classList.toggle('cut', !!(S.clip && S.clip.cut && S.clip.set.has(e.path))); }
  }
}

/* ---------- selección ---------- */
function selected(p) { p = p || pane(); return p.visible.filter((e) => p.sel.has(e.path)); }
function selectOnly(p, path) { p.sel = new Set(path ? [path] : []); p.focus = path; p.anchor = path; refreshSelectionClasses(p); }
function selectAll(p) { p.sel = new Set(p.visible.map((e) => e.path)); refreshSelectionClasses(p); }
function invertSelection(p) { p.sel = new Set(p.visible.filter((e) => !p.sel.has(e.path)).map((e) => e.path)); refreshSelectionClasses(p); }
function selectRange(p, toPath, additive) {
  const a = p.visible.findIndex((e) => e.path === (p.anchor || toPath));
  const b = p.visible.findIndex((e) => e.path === toPath);
  if (a < 0 || b < 0) return selectOnly(p, toPath);
  if (!additive) p.sel = new Set();
  for (let i = Math.min(a, b); i <= Math.max(a, b); i++) p.sel.add(p.visible[i].path);
  p.focus = toPath;
  refreshSelectionClasses(p);
}
function focusView(p) { p.viewEl.focus({ preventScroll: true }); if (!p.focus && p.visible.length) selectOnly(p, p.visible[0].path); }

/* ---------- eventos de la vista ---------- */
function attachViewEvents(p) {
  const v = p.viewEl;
  let pendingSingle = null;
  let rubber = null;

  v.addEventListener('error', (e) => { if (e.target.classList && e.target.classList.contains('th')) e.target.remove(); }, true);
  v.addEventListener('load', (e) => { if (e.target.classList && e.target.classList.contains('th')) e.target.parentElement.classList.add('has-thumb'); }, true);
  v.addEventListener('focus', () => refreshSelectionClasses(p));
  v.addEventListener('blur', () => refreshSelectionClasses(p));

  p.headerEl.addEventListener('mousedown', (e) => { const r = e.target.closest('.col-resize'); if (r) startColResize(p, e, r.dataset.col); });
  p.headerEl.addEventListener('click', (e) => { if (p.justResized || e.target.closest('.col-resize')) return; const c = e.target.closest('[data-sort]'); if (c) setSort(p, c.dataset.sort); });
  p.headerEl.addEventListener('contextmenu', (e) => { e.preventDefault(); e.stopPropagation(); Menu.show(columnMenu(p), e.clientX, e.clientY); });
  let wheelAcc = 0; let wheelT = 0;
  v.addEventListener('wheel', (e) => {
    if (e.ctrlKey) {
      e.preventDefault();
      activatePane(p);
      // ratones con rueda: un paso por muesca; touchpads: acumular
      const now = Date.now();
      if (now - wheelT > 400) wheelAcc = 0;
      wheelT = now;
      wheelAcc += e.deltaMode === 1 ? e.deltaY * 40 : e.deltaY;
      if (Math.abs(wheelAcc) >= 50) {
        const before = zoomVal(p.view);
        zoom(wheelAcc < 0 ? 1 : -1);
        wheelAcc = 0;
        if (zoomVal(p.view) !== before) showZoomBadge(p);
        else showZoomBadge(p, true);
      }
      return;
    }
    const strip = p.view === 'gallery' && e.target.closest('.gal-strip');
    if (strip && Math.abs(e.deltaY) > Math.abs(e.deltaX)) { strip.scrollLeft += e.deltaY; e.preventDefault(); }
  }, { passive: false });

  v.addEventListener('mousedown', (e) => {
    if (e.target.closest('.list-header') || e.target.closest('.rename-box')) return;
    const gh = e.target.closest('.ghead');
    if (gh) { if (e.button === 0) { e.preventDefault(); toggleGroup(p, gh.dataset.g); } return; }
    const ac = e.target.closest('.acol-item');
    if (ac) { if (e.button === 0) { e.preventDefault(); acolMouse(p, e, ac); } else if (e.button === 1 && ac.dataset.isdir === '1') { e.preventDefault(); openTab(ac.dataset.path, { background: true }); } return; }
    if (e.target.closest('.gal-stage') || e.target.closest('.mprev')) return;
    const chkEl = e.target.closest('.chk');
    if (chkEl && e.button === 0) {
      e.preventDefault(); e.stopPropagation();
      const it = chkEl.closest('.item'); const en = it && p.visible[Number(it.dataset.i)];
      if (en) { if (p.sel.has(en.path)) p.sel.delete(en.path); else p.sel.add(en.path); p.focus = en.path; p.anchor = en.path; refreshSelectionClasses(p); }
      v.focus({ preventScroll: true });
      return;
    }
    const itemEl = e.target.closest('.item');
    if (e.button === 1) {
      e.preventDefault();
      if (itemEl) { const en = p.visible[Number(itemEl.dataset.i)]; if (en && en.isDir) openTab(en.path, { background: true }); }
      return;
    }
    if (e.button !== 0 && e.button !== 2) return;
    v.focus({ preventScroll: true });
    // Zona «blanda»: el hueco de la fila o la casilla alrededor del icono/nombre.
    // Al hacer clic selecciona como siempre; al arrastrar dibuja el recuadro de selección.
    const lassoView = p.view !== 'columns' && p.view !== 'gallery';
    const soft = itemEl && e.button === 0 && lassoView && !e.target.closest('.thumb, .ico, .name');
    if (itemEl && !soft) {
      const en = p.visible[Number(itemEl.dataset.i)];
      if (!en) return;
      if (e.button === 2) { if (!p.sel.has(en.path)) selectOnly(p, en.path); return; }
      clickSelect(en, e);
      return;
    }
    if (e.button === 2) { if (!e.ctrlKey) selectOnly(p, null); return; }
    if (!lassoView) { if (!e.ctrlKey && !e.shiftKey && p.view !== 'gallery') selectOnly(p, null); return; }
    // selección por arrastre (rectángulo)
    if (e.target.closest('.items') || e.target === v || e.target.closest('.empty')) {
      e.preventDefault();
      const softEntry = soft ? p.visible[Number(itemEl.dataset.i)] : null;
      const mode = e.ctrlKey ? 'toggle' : e.shiftKey ? 'add' : 'replace';
      const base = mode === 'replace' ? new Set() : new Set(p.sel);
      const startSel = new Set(p.sel);
      if (mode === 'replace' && !softEntry) selectOnly(p, null);
      const vr = v.getBoundingClientRect();
      rubber = { x0: e.clientX - vr.left + v.scrollLeft, y0: e.clientY - vr.top + v.scrollTop, base, mode, rects: null, moved: false, lastX: e.clientX, lastY: e.clientY, softEntry, startSel, ev: { ctrlKey: e.ctrlKey, shiftKey: e.shiftKey } };
      const els = itemEls(p);
      rubber.rects = Array.from(els, (el) => ({ l: el.offsetLeft, t: el.offsetTop, r: el.offsetLeft + el.offsetWidth, b: el.offsetTop + el.offsetHeight }));
      const move = (ev) => { rubber.lastX = ev.clientX; rubber.lastY = ev.clientY; updateRubber(); };
      const scrollTimer = setInterval(() => {
        const r = v.getBoundingClientRect();
        if (rubber.lastY < r.top + 30) { v.scrollTop -= 18; updateRubber(); }
        else if (rubber.lastY > r.bottom - 20) { v.scrollTop += 18; updateRubber(); }
      }, 30);
      const up = () => {
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
        clearInterval(scrollTimer);
        p.rubberEl.classList.add('hidden');
        const r = rubber;
        rubber = null;
        // sin movimiento sobre un elemento: es un clic normal
        if (r && !r.moved && r.softEntry) { p.sel = r.startSel; clickSelect(r.softEntry, r.ev, true); }
      };
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
    }
  });

  function clickSelect(en, e, fromSoft) {
    if (e.ctrlKey && e.shiftKey) selectRange(p, en.path, true);
    else if (e.ctrlKey) { if (p.sel.has(en.path)) p.sel.delete(en.path); else p.sel.add(en.path); p.focus = en.path; p.anchor = en.path; refreshSelectionClasses(p); }
    else if (e.shiftKey) selectRange(p, en.path, false);
    else if (p.sel.has(en.path) && !fromSoft) { pendingSingle = en.path; p.focus = en.path; }
    else selectOnly(p, en.path);
  }

  function updateRubber() {
    if (!rubber) return;
    const vr = v.getBoundingClientRect();
    const x1 = rubber.lastX - vr.left + v.scrollLeft;
    const y1 = rubber.lastY - vr.top + v.scrollTop;
    const l = Math.min(rubber.x0, x1); const t = Math.min(rubber.y0, y1);
    const r = Math.max(rubber.x0, x1); const b = Math.max(rubber.y0, y1);
    if (!rubber.moved && r - l < 4 && b - t < 4) return;
    rubber.moved = true;
    const re = p.rubberEl;
    re.classList.remove('hidden');
    Object.assign(re.style, { left: l + 'px', top: t + 'px', width: (r - l) + 'px', height: (b - t) + 'px' });
    const ox = p.itemsEl.offsetLeft; const oy = p.itemsEl.offsetTop;
    const sel = new Set(rubber.base);
    let last = null;
    rubber.rects.forEach((rc, i) => {
      if (rc.r + ox > l && rc.l + ox < r && rc.b + oy > t && rc.t + oy < b) {
        const en = p.visible[i];
        if (!en) return;
        if (rubber.mode === 'toggle' && rubber.base.has(en.path)) sel.delete(en.path); else sel.add(en.path);
        last = en.path;
      }
    });
    if (last) p.focus = last;
    p.sel = sel;
    refreshSelectionClasses(p);
  }

  v.addEventListener('mouseup', (e) => {
    if (pendingSingle && e.button === 0 && !e.ctrlKey && !e.shiftKey) {
      const itemEl = e.target.closest('.item');
      const en = itemEl && p.visible[Number(itemEl.dataset.i)];
      if (en && en.path === pendingSingle) selectOnly(p, en.path);
    }
    pendingSingle = null;
  });

  v.addEventListener('click', (e) => {
    if (!S.config.singleClick || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    const itemEl = e.target.closest('.item');
    if (itemEl && !e.target.closest('.rename-box')) { const en = p.visible[Number(itemEl.dataset.i)]; if (en) openEntries([en], { newTab: false }); }
  });
  v.addEventListener('dblclick', (e) => {
    const ac = e.target.closest('.acol-item');
    if (ac) {
      if (ac.dataset.isdir === '1') navigate(p, ac.dataset.path, { selectFirst: true });
      else api.call('open:default', ac.dataset.path).catch((err) => errorToast(err));
      return;
    }
    if (S.config.singleClick) return;
    const itemEl = e.target.closest('.item');
    if (!itemEl || e.target.closest('.rename-box')) return;
    const en = p.visible[Number(itemEl.dataset.i)];
    if (en) openEntries([en], {});
  });
  v.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    if (e.target.closest('.rename-box') || e.target.closest('.ghead')) return;
    const ac = e.target.closest('.acol-item');
    if (ac) { const x = e.clientX; const y = e.clientY; acolMouse(p, e, ac).then(() => Menu.show(itemMenu(p), x, y)); return; }
    const itemEl = e.target.closest('.item');
    if (itemEl) {
      const en = p.visible[Number(itemEl.dataset.i)];
      if (en && !p.sel.has(en.path)) selectOnly(p, en.path);
      Menu.show(itemMenu(p), e.clientX, e.clientY);
    } else Menu.show(backgroundMenu(p), e.clientX, e.clientY);
  });

  /* arrastrar y soltar */
  v.addEventListener('dragstart', (e) => {
    const itemEl = e.target.closest('.item');
    if (!itemEl) return;
    const en = p.visible[Number(itemEl.dataset.i)];
    if (!en) return;
    if (!p.sel.has(en.path)) selectOnly(p, en.path);
    pendingSingle = null;
    const paths = selected(p).map((x) => x.path);
    startDrag(e, paths, p);
  });
  v.addEventListener('dragend', () => endDrag());
  v.addEventListener('dragover', (e) => {
    const target = dropTargetInView(p, e);
    highlightDrop(target ? target.el : null);
    if (!target) { e.dataTransfer.dropEffect = 'none'; return; }
    e.preventDefault();
    e.dataTransfer.dropEffect = dropEffectFor(e, target.dir);
  });
  v.addEventListener('dragleave', (e) => { if (!v.contains(e.relatedTarget)) highlightDrop(null); });
  v.addEventListener('drop', (e) => {
    const target = dropTargetInView(p, e);
    highlightDrop(null);
    if (!target) return;
    e.preventDefault();
    handleDrop(e, target.dir);
  });
}

/* ---------- arrastrar y soltar (común) ---------- */
let DRAG = null;
function startDrag(e, paths, p) {
  DRAG = { paths, from: p ? p.path : null, set: new Set(paths) };
  const dt = e.dataTransfer;
  dt.effectAllowed = 'copyMove';
  dt.setData('application/x-cajon', JSON.stringify(paths));
  dt.setData('text/uri-list', paths.map((x) => fileUrl(x)).join('\r\n'));
  dt.setData('text/plain', paths.join('\n'));
  const ghost = h('div', { class: 'drag-ghost' }, h('span', { html: paths.length === 1 ? ic('documents') : ic('copy') }), h('span', { text: paths.length === 1 ? basename(paths[0]) : `${paths.length} elementos` }));
  document.body.appendChild(ghost);
  dt.setDragImage(ghost, 14, 14);
  setTimeout(() => ghost.remove(), 0);
  document.body.classList.add('dragging');
}
function endDrag() { DRAG = null; highlightDrop(null); document.body.classList.remove('dragging'); }
let dropEl = null;
function highlightDrop(el) { if (dropEl === el) return; if (dropEl) dropEl.classList.remove('drop'); dropEl = el; if (el) el.classList.add('drop'); }
function dropTargetInView(p, e) {
  const ac = e.target.closest('.acol-item');
  if (ac) {
    const dir = ac.dataset.isdir === '1' ? ac.dataset.path : ac.closest('.mcol').dataset.dir;
    if (dir && !(DRAG && (DRAG.set.has(dir) || DRAG.paths.every((x) => dirname(x) === dir)))) return { dir, el: ac.dataset.isdir === '1' ? ac : ac.closest('.mcol') };
    return null;
  }
  const itemEl = e.target.closest('.item');
  if (itemEl) {
    const en = p.visible[Number(itemEl.dataset.i)];
    if (en && en.isDir && p.path !== TRASH && !(DRAG && DRAG.set.has(en.path))) return { dir: en.path, el: itemEl };
  }
  if (!p.path || p.search || p.path === RECENT) return null;
  if (p.path === TRASH) return { dir: TRASH, el: p.viewEl };
  if (DRAG && DRAG.paths.every((x) => dirname(x) === p.path)) return null;
  return { dir: p.path, el: p.viewEl };
}
function dropEffectFor(e, dir) {
  if (dir === TRASH) return 'move';
  if (e.ctrlKey) return 'copy';
  if (e.shiftKey) return 'move';
  const src = DRAG ? DRAG.paths[0] : null;
  if (!src) return 'copy';
  return mountOf(src) === mountOf(dir) ? 'move' : 'copy';
}
function pathsFromDrop(e) {
  const dt = e.dataTransfer;
  const internal = dt.getData('application/x-cajon');
  if (internal) { try { return JSON.parse(internal); } catch (_) { /* nada */ } }
  const out = [];
  for (const f of Array.from(dt.files || [])) { const p = api.pathForFile(f); if (p) out.push(p); }
  if (out.length) return out;
  const uris = dt.getData('text/uri-list');
  if (uris) {
    for (const line of uris.split(/\r?\n/)) {
      if (!line.startsWith('file://')) continue;
      try { out.push(decodeURIComponent(new URL(line).pathname)); } catch (_) { /* nada */ }
    }
  }
  return out;
}
function handleDrop(e, dir) {
  const paths = pathsFromDrop(e).filter((x) => x !== dir);
  if (!paths.length) return;
  if (dir === TRASH) { trashPaths(paths); return; }
  const src = paths[0];
  let op;
  if (e.ctrlKey) op = 'copy'; else if (e.shiftKey) op = 'move'; else op = mountOf(src) === mountOf(dir) ? 'move' : 'copy';
  if (e.ctrlKey && e.shiftKey) { askDropAction(paths, dir, e.clientX, e.clientY); return; }
  transfer(op, paths, dir);
}
function askDropAction(paths, dir, x, y) {
  Menu.show([
    { label: 'Mover aquí', icon: 'cut', action: () => transfer('move', paths, dir) },
    { label: 'Copiar aquí', icon: 'copy', action: () => transfer('copy', paths, dir) },
    '-', { label: 'Cancelar', icon: 'x', action: () => {} },
  ], x, y);
}

/* ---------- barra de ruta ---------- */
function initPathbar() {
  const bar = $('#pathbar');
  const input = $('#path-input');
  bar.addEventListener('mousedown', (e) => {
    if (e.target === bar || e.target.classList.contains('crumbs') || e.target.classList.contains('crumb-fill')) { e.preventDefault(); editPath(true); }
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); editPath(false); focusView(pane()); }
    else if (e.key === 'Enter') { e.preventDefault(); submitPath(input.value); }
    else if (e.key === 'Tab') { e.preventDefault(); completePath(); }
    else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); moveSuggestion(e.key === 'ArrowDown' ? 1 : -1); }
  });
  input.addEventListener('input', () => suggestPaths(input.value));
  input.addEventListener('blur', () => setTimeout(() => { if (document.activeElement !== input) editPath(false); }, 150));
}
function editPath(on) {
  const bar = $('#pathbar');
  const input = $('#path-input');
  bar.classList.toggle('editing', on);
  if (on) {
    const p = pane();
    input.value = p.path && !isVirtual(p.path) ? (p.path === '/' ? '/' : p.path + '/') : '';
    input.focus();
    input.select();
  } else $('#path-suggest').classList.add('hidden');
}
async function submitPath(v) {
  v = v.trim();
  if (!v) return;
  if (v === 'trash:' || v === 'trash:///' || v === TRASH) { editPath(false); navigate(pane(), TRASH); return; }
  if (v === 'recent:' || v === RECENT) { editPath(false); navigate(pane(), RECENT); return; }
  if (v.startsWith('file://')) { try { v = decodeURIComponent(new URL(v).pathname); } catch (_) { /* nada */ } }
  if (v === '~' || v.startsWith('~/')) v = S.home + v.slice(1);
  if (!v.startsWith('/')) v = joinPath(pane().path && !isVirtual(pane().path) ? pane().path : S.home, v);
  try {
    const st = await api.call('fs:stat', v.length > 1 ? v.replace(/\/+$/, '') : v);
    editPath(false);
    if (st.isDir) await navigate(pane(), st.path);
    else await navigate(pane(), dirname(st.path), { select: [st.path] });
    focusView(pane());
  } catch (e) {
    toast(`No existe «${v}»`, { type: 'error' });
  }
}
let suggestState = { items: [], idx: -1, token: 0 };
async function suggestPaths(v) {
  const box = $('#path-suggest');
  const token = ++suggestState.token;
  let full = v.startsWith('~') ? S.home + v.slice(1) : v;
  if (!full.startsWith('/')) { box.classList.add('hidden'); return; }
  const dir = full.endsWith('/') ? full.replace(/\/+$/, '') || '/' : dirname(full);
  const prefix = full.endsWith('/') ? '' : basename(full);
  let entries;
  try { entries = await api.call('fs:list', dir); } catch (_) { box.classList.add('hidden'); return; }
  if (token !== suggestState.token) return;
  const q = normalize(prefix);
  const items = entries.filter((e) => e.isDir && (S.config.showHidden || !e.hidden || prefix.startsWith('.')) && normalize(e.name).startsWith(q)).sort((a, b) => collator.compare(a.name, b.name)).slice(0, 10);
  suggestState.items = items; suggestState.idx = -1;
  if (!items.length || (items.length === 1 && items[0].name === prefix)) { box.classList.add('hidden'); return; }
  box.innerHTML = '';
  items.forEach((e, i) => {
    box.appendChild(h('div', { class: 'sg', 'data-i': i, onmousedown: (ev) => { ev.preventDefault(); $('#path-input').value = e.path + '/'; suggestPaths(e.path + '/'); $('#path-input').focus(); } },
      h('span', { html: ic('folder') }), h('span', { text: e.name })));
  });
  box.classList.remove('hidden');
}
function moveSuggestion(d) {
  const n = suggestState.items.length;
  if (!n) return;
  suggestState.idx = (suggestState.idx + d + n) % n;
  $$('#path-suggest .sg').forEach((el, i) => el.classList.toggle('active', i === suggestState.idx));
  $('#path-input').value = suggestState.items[suggestState.idx].path + '/';
}
function completePath() {
  const it = suggestState.items[Math.max(0, suggestState.idx)];
  if (it) { $('#path-input').value = it.path + '/'; suggestPaths(it.path + '/'); }
}

function renderCrumbs() {
  const host = $('#crumbs');
  const p = pane();
  host.innerHTML = '';
  if (!p.path) return;
  const segs = [];
  if (p.search) segs.push({ label: `Buscar «${p.search.query}»`, path: null, icon: 'search' });
  else if (p.path === TRASH) segs.push({ label: 'Papelera', path: TRASH, icon: 'trash' });
  else if (p.path === RECENT) segs.push({ label: 'Recientes', path: RECENT, icon: 'recent' });
  else {
    let rest = p.path;
    if (p.path === S.home || p.path.startsWith(S.home + '/')) {
      segs.push({ label: 'Carpeta personal', path: S.home, icon: 'home' });
      rest = p.path.slice(S.home.length);
      let acc = S.home;
      for (const part of rest.split('/').filter(Boolean)) { acc += '/' + part; segs.push({ label: part, path: acc }); }
    } else {
      const m = S.drives.find((d) => d.mountpoint && d.mountpoint !== '/' && (p.path === d.mountpoint || p.path.startsWith(d.mountpoint + '/')));
      let acc;
      if (m) { segs.push({ label: m.label, path: m.mountpoint, icon: m.kind === 'network' ? 'network' : m.removable ? 'usb' : 'disk' }); acc = m.mountpoint; rest = p.path.slice(m.mountpoint.length); }
      else { segs.push({ label: '', path: '/', icon: 'system', title: 'Sistema de archivos' }); acc = ''; }
      for (const part of rest.split('/').filter(Boolean)) { acc += '/' + part; segs.push({ label: part, path: acc }); }
    }
  }
  segs.forEach((s, i) => {
    if (i > 0) host.appendChild(h('span', { class: 'crumb-sep', html: ic('chevronRight') }));
    const el = h('button', { class: `crumb${i === segs.length - 1 ? ' current' : ''}`, title: s.title || s.path || '' },
      s.icon ? h('span', { class: 'crumb-ic', html: ic(s.icon) }) : null, s.label ? h('span', { text: s.label }) : null);
    if (s.path) {
      el.onclick = () => { if (s.path !== p.path) navigate(p, s.path, { fromChild: p.path.startsWith(s.path + '/') ? segs[i + 1] && segs[i + 1].path : null }); };
      el.oncontextmenu = (e) => {
        e.preventDefault();
        Menu.show([
          { label: 'Abrir en una pestaña nueva', icon: 'tab', action: () => openTab(s.path) },
          { label: 'Abrir en una ventana nueva', icon: 'window', disabled: isVirtual(s.path), action: () => api.call('open:newWindow', s.path) },
          '-',
          { label: 'Copiar ruta', icon: 'link', disabled: isVirtual(s.path), action: () => copyPathText([s.path]) },
          { label: 'Abrir en un terminal', icon: 'terminal', disabled: isVirtual(s.path), action: () => openTerminal(s.path) },
          { label: 'Propiedades', icon: 'info', disabled: isVirtual(s.path), action: () => showProperties([s.path]) },
        ], e.clientX, e.clientY);
      };
      if (!isVirtual(s.path)) {
        el.addEventListener('dragover', (e) => { if (DRAG && DRAG.paths.every((x) => dirname(x) === s.path)) return; e.preventDefault(); e.dataTransfer.dropEffect = dropEffectFor(e, s.path); highlightDrop(el); });
        el.addEventListener('dragleave', () => highlightDrop(null));
        el.addEventListener('drop', (e) => { e.preventDefault(); highlightDrop(null); handleDrop(e, s.path); });
      }
    }
    host.appendChild(el);
  });
  host.appendChild(h('span', { class: 'crumb-fill' }));
  requestAnimationFrame(() => { host.scrollLeft = host.scrollWidth; });
}

/* ---------- barra superior y estado ---------- */
function updateChrome() {
  const p = pane();
  if (!p) return;
  $('#btn-back').disabled = p.hIndex <= 0;
  $('#btn-forward').disabled = p.hIndex >= p.history.length - 1;
  $('#btn-up').disabled = !p.path || p.path === '/' || isVirtual(p.path);
  const vdef = VIEWS.find((x) => x.id === p.view) || VIEWS[0];
  $('#btn-view').innerHTML = ic(vdef.icon) + `<span class="vb-label">${vdef.label}</span>` + ic('chevronDown', 'vb-chev');
  $('#btn-view').title = 'Opciones de vista';
  $('#btn-split').classList.toggle('on', tab().split);
  $('#btn-preview').classList.toggle('on', !!S.config.preview);
  $('#btn-sidebar').classList.toggle('on', !!S.config.sidebar);
  const si = $('#search-input');
  if (document.activeElement !== si) si.value = p.search ? p.search.query : p.filter;
  $('#searchbox').classList.toggle('open', !!(p.filter || p.search) || document.activeElement === si);
  renderCrumbs();
  renderSidebarActive();
  updateStatus();
  updateTitle();
  schedulePreview();
}
function updateTitle() {
  const p = pane();
  if (!p || !p.path) return;
  const name = p.search ? `Buscar «${p.search.query}»` : displayName(p.path);
  document.title = `${name} — Cajón`;
  api.setTitle(document.title);
}
let statfsCache = { path: null, data: null, t: 0 };
async function updateStatus() {
  const p = pane();
  if (!p) return;
  const vis = p.visible;
  const dirs = vis.filter((e) => e.isDir).length;
  const files = vis.length - dirs;
  const sel = selected(p);
  let left = `${plural(vis.length, 'elemento', 'elementos')}`;
  if (vis.length) left += ` <span class="dim">(${plural(dirs, 'carpeta', 'carpetas')}, ${plural(files, 'archivo', 'archivos')})</span>`;
  if (sel.length) {
    const size = sel.filter((e) => !e.isDir).reduce((a, e) => a + e.size, 0);
    const selDirs = sel.filter((e) => e.isDir).length;
    const one = sel.length === 1 ? sel[0] : null;
    left = `<b>${one ? `«${esc(one.name)}» seleccionado` : `${fmtNum(sel.length)} de ${fmtNum(vis.length)} seleccionados`}</b>`;
    if (one) left += ` <span class="dim">· ${one.isDir ? (one.children == null ? 'carpeta' : plural(one.children, 'elemento', 'elementos')) : fmtSize(one.size)}</span>`;
    else if (size || selDirs) left += ` <span class="dim">· ${size ? fmtSize(size) : ''}${size && selDirs ? ' + ' : ''}${selDirs ? plural(selDirs, 'carpeta', 'carpetas') : ''}</span>`;
  }
  $('#status-left').innerHTML = left;
  const zr = $('#zoom-range');
  zr.max = zoomSpec(p.view).max;
  zr.value = zoomVal(p.view);
  let right = '';
  if (p.path && !isVirtual(p.path)) {
    if (statfsCache.path !== p.path || Date.now() - statfsCache.t > 5000) {
      try { statfsCache = { path: p.path, data: await api.call('fs:statfs', p.path), t: Date.now() }; } catch (_) { statfsCache = { path: p.path, data: null, t: Date.now() }; }
    }
    const d = statfsCache.data;
    if (d && d.total) right = `${fmtSize(d.free)} libres de ${fmtSize(d.total)}`;
  } else if (p.path === TRASH) {
    const total = p.entries.reduce((a, e) => a + (e.size || 0), 0);
    right = total ? `${fmtSize(total)} en la papelera` : '';
  }
  $('#status-right').textContent = right;
}

/* ---------- búsqueda ---------- */
function toggleSearch(on) {
  const box = $('#searchbox');
  const si = $('#search-input');
  const p = pane();
  if (on) {
    box.classList.add('open');
    si.focus();
    si.select();
  } else {
    if (p.search) stopSearch(p, {});
    si.value = '';
    if (p.filter) applyFilter(p, '');
    box.classList.remove('open');
    focusView(p);
  }
}
function startSearch(p, query) {
  if (!p.path || p.path === TRASH) return;
  const root = p.search ? p.search.root : p.path === RECENT ? S.home : p.path;
  if (p.search && p.search.running) api.call('fs:search:cancel', p.search.id).catch(() => {});
  const id = 's' + S.nextId++;
  p.search = { id, query, root, results: [], running: true, count: 0 };
  p.filter = '';
  p.sel.clear();
  computeVisible(p);
  renderPane(p);
  updateChrome();
  renderTabs();
  api.call('fs:search', id, root, query, { showHidden: S.config.showHidden }).catch((e) => errorToast(e));
}
let searchRenderTimer = null;
function onSearchResults(r) {
  const p = allPanes().find((x) => x.search && x.search.id === r.id);
  if (!p) return;
  p.search.results.push(...r.items);
  p.search.count = r.count;
  if (r.done) p.search.running = false;
  clearTimeout(searchRenderTimer);
  searchRenderTimer = setTimeout(() => { computeVisible(p); renderPane(p, { keepScroll: true }); }, r.done ? 0 : 150);
}
function stopSearch(p, { keepResults } = {}) {
  if (!p.search) return;
  if (p.search.running) api.call('fs:search:cancel', p.search.id).catch(() => {});
  if (keepResults) { p.search.running = false; renderBanner(p); return; }
  p.search = null;
  computeVisible(p);
  renderPane(p);
  updateChrome();
  renderTabs();
}

/* ---------- abrir ---------- */
async function openEntries(entries, { newTab } = {}) {
  const p = pane();
  if (!entries.length) return;
  if (entries.length === 1 && entries[0].isDir) {
    if (newTab) openTab(entries[0].path); else navigate(p, entries[0].path);
    return;
  }
  if (p.path === TRASH) { toast('Restaura el elemento para poder abrirlo', { icon: 'trash' }); return; }
  const dirs = entries.filter((e) => e.isDir);
  const files = entries.filter((e) => !e.isDir);
  if (files.length > 8 && !(await confirmDialog('Abrir muchos archivos', `¿Seguro que quieres abrir ${files.length} archivos a la vez?`, { okLabel: 'Abrir todos' }))) return;
  dirs.forEach((d) => openTab(d.path, { background: true }));
  for (const f of files) {
    try { await api.call('open:default', f.path); } catch (e) {
      const r = await confirmDialog('No hay ninguna aplicación predeterminada', `No se sabe con qué abrir «${f.name}». ¿Quieres elegir una aplicación?`, { okLabel: 'Elegir aplicación' });
      if (r) openWithDialog([f]);
    }
  }
}
async function openTerminal(dir) {
  try { const r = await api.call('open:terminal', dir); if (!r.ok) toast(r.error, { type: 'error' }); } catch (e) { errorToast(e); }
}

/* ---------- barra lateral ---------- */
async function refreshSidebar() {
  try { S.bookmarks = await api.call('places:bookmarks'); } catch (_) { S.bookmarks = []; }
  await refreshDrives(true);
  await refreshTrashCount();
  renderSidebar();
}
let drivesSig = '';
async function refreshDrives(silent) {
  try {
    const d = await api.call('places:drives');
    const sig = JSON.stringify(d.map((x) => [x.id, x.mountpoint, Math.round((x.free || 0) / 1e8)]));
    const before = drivesSig;
    S.drives = d;
    if (sig !== drivesSig) {
      drivesSig = sig;
      if (!silent) renderSidebar();
      // si una unidad desaparece, salir de ella
      if (before) for (const p of allPanes()) if (p.path && !isVirtual(p.path)) {
        const m = mountOf(p.path);
        if (m !== '/' && !S.drives.some((x) => x.mountpoint === m)) navigate(p, S.home, { silent: true });
      }
    }
  } catch (_) { /* nada */ }
}
async function refreshTrashCount() {
  try {
    const n = await api.call('trash:count');
    if (n !== S.trashCount) { S.trashCount = n; renderSidebar(); }
  } catch (_) { /* nada */ }
}

function sbItem({ icon, label, path, badge, extra, onclick, oncontext, drop, cls, title, usage }) {
  const el = h('div', { class: `sb-item${cls ? ' ' + cls : ''}`, 'data-path': path || '', title: title || path || label, tabindex: '-1' },
    h('span', { class: 'sb-ic', html: ic(icon) }),
    h('span', { class: 'sb-label' }, h('span', { class: 'sb-text', text: label }), usage ? h('span', { class: 'usage' }, h('span', { style: { width: usage + '%' }, class: usage > 90 ? 'full' : '' })) : null),
    badge ? h('span', { class: 'sb-badge', text: badge }) : null,
    extra || null);
  el.addEventListener('click', (e) => { if (e.target.closest('.sb-action')) return; onclick && onclick(e); });
  el.addEventListener('mousedown', (e) => { if (e.button === 1 && path && !e.target.closest('.sb-action')) { e.preventDefault(); openTab(path, { background: true }); } });
  if (oncontext) el.addEventListener('contextmenu', (e) => { e.preventDefault(); oncontext(e); });
  if (drop) {
    el.addEventListener('dragover', (e) => { if (DRAG && drop !== TRASH && DRAG.paths.every((x) => dirname(x) === drop)) return; e.preventDefault(); e.dataTransfer.dropEffect = dropEffectFor(e, drop); highlightDrop(el); });
    el.addEventListener('dragleave', () => highlightDrop(null));
    el.addEventListener('drop', (e) => { e.preventDefault(); highlightDrop(null); handleDrop(e, drop); });
  }
  return el;
}
function placeMenu(path, extra) {
  return [
    { label: 'Abrir', icon: 'folderOpen', action: () => navigate(pane(), path) },
    { label: 'Abrir en una pestaña nueva', icon: 'tab', action: () => openTab(path) },
    { label: 'Abrir en una ventana nueva', icon: 'window', disabled: isVirtual(path), action: () => api.call('open:newWindow', path) },
    otherPane() ? { label: 'Abrir en el otro panel', icon: 'split', action: () => navigate(otherPane(), path) } : null,
    ...(extra || []),
    '-',
    { label: 'Abrir en un terminal', icon: 'terminal', disabled: isVirtual(path), action: () => openTerminal(path) },
    { label: 'Propiedades', icon: 'info', disabled: isVirtual(path), action: () => showProperties([path]) },
  ];
}
function sbSection(id, title, children, action) {
  const collapsed = !!(S.config.collapsed || {})[id];
  const sec = h('div', { class: `sb-section${collapsed ? ' collapsed' : ''}`, 'data-sec': id });
  const head = h('div', { class: 'sb-head' }, h('span', { class: 'sb-chev', html: ic('chevronDown') }), h('span', { text: title }), h('span', { class: 'spacer' }), action || null);
  head.addEventListener('click', (e) => {
    if (e.target.closest('.sb-action')) return;
    const c = Object.assign({}, S.config.collapsed || {});
    c[id] = !c[id];
    setConfig({ collapsed: c });
    sec.classList.toggle('collapsed', !!c[id]);
  });
  sec.append(head, h('div', { class: 'sb-list' }, children));
  return sec;
}
function renderSidebar() {
  const host = $('#sb-scroll');
  const scroll = host.scrollTop;
  host.innerHTML = '';
  const places = [
    sbItem({ icon: 'recent', label: 'Recientes', path: RECENT, onclick: () => navigate(pane(), RECENT), oncontext: (e) => Menu.show([{ label: 'Abrir', icon: 'folderOpen', action: () => navigate(pane(), RECENT) }, { label: 'Abrir en una pestaña nueva', icon: 'tab', action: () => openTab(RECENT) }], e.clientX, e.clientY) }),
    ...S.places.map((pl) => sbItem({ icon: pl.key === 'home' ? 'home' : pl.key, label: pl.label, path: pl.path, drop: pl.path, onclick: () => navigate(pane(), pl.path), oncontext: (e) => Menu.show(placeMenu(pl.path), e.clientX, e.clientY) })),
    sbItem({
      icon: S.trashCount ? 'trashFull' : 'trash', label: 'Papelera', path: TRASH, badge: S.trashCount ? String(S.trashCount) : null, drop: TRASH, cls: 'trash-item',
      onclick: () => navigate(pane(), TRASH),
      oncontext: (e) => Menu.show([
        { label: 'Abrir', icon: 'folderOpen', action: () => navigate(pane(), TRASH) },
        { label: 'Abrir en una pestaña nueva', icon: 'tab', action: () => openTab(TRASH) },
        '-', { label: 'Vaciar papelera', icon: 'trash', danger: true, disabled: !S.trashCount, action: () => emptyTrash() },
      ], e.clientX, e.clientY),
    }),
  ];
  host.appendChild(sbSection('places', 'Lugares', places));

  const bms = S.bookmarks.map((b, i) => sbItem({
    icon: b.remote ? 'network' : 'bookmark', label: b.label, path: b.path, cls: b.exists === false ? 'missing' : '', drop: b.path && b.exists !== false ? b.path : null,
    onclick: () => { if (b.path) navigate(pane(), b.path); else toast('Las ubicaciones remotas no están disponibles en Cajón todavía'); },
    oncontext: (e) => Menu.show(placeMenu(b.path, [
      '-',
      { label: 'Renombrar marcador…', icon: 'rename', action: () => renameBookmark(i) },
      { label: 'Subir', icon: 'up', disabled: i === 0, action: () => moveBookmark(i, -1) },
      { label: 'Bajar', icon: 'chevronDown', disabled: i === S.bookmarks.length - 1, action: () => moveBookmark(i, 1) },
      { label: 'Quitar de marcadores', icon: 'x', danger: true, action: () => removeBookmark(i) },
    ]), e.clientX, e.clientY),
  }));
  const bmSec = sbSection('bookmarks', 'Marcadores', bms.length ? bms : [h('div', { class: 'sb-hint', text: 'Arrastra carpetas aquí o pulsa Ctrl+D' })],
    h('button', { class: 'sb-action icon-btn tiny', title: 'Añadir la carpeta actual (Ctrl+D)', html: ic('plus'), onclick: () => addBookmark(pane().path) }));
  bmSec.addEventListener('dragover', (e) => { if (!DRAG && !e.dataTransfer.types.includes('Files')) return; if (e.target.closest('.sb-item')) return; e.preventDefault(); e.dataTransfer.dropEffect = 'link'; highlightDrop(bmSec); });
  bmSec.addEventListener('dragleave', (e) => { if (!bmSec.contains(e.relatedTarget)) highlightDrop(null); });
  bmSec.addEventListener('drop', async (e) => {
    if (e.target.closest('.sb-item')) return;
    e.preventDefault(); highlightDrop(null);
    for (const p of pathsFromDrop(e)) { try { const st = await api.call('fs:stat', p); if (st.isDir) await addBookmark(p, true); } catch (_) { /* nada */ } }
  });
  host.appendChild(bmSec);

  const drv = S.drives.map((d) => {
    const usage = d.total && d.free != null ? Math.round((1 - d.free / d.total) * 100) : null;
    const icon = d.kind === 'system' ? 'system' : d.kind === 'network' ? 'network' : d.kind === 'optical' ? 'optical' : d.removable ? 'usb' : 'disk';
    const title = d.mountpoint ? `${d.label}\n${d.mountpoint}${d.total ? `\n${fmtSize(d.free)} libres de ${fmtSize(d.total)}` : ''}` : `${d.label} (sin montar) — haz clic para montar`;
    const ejectBtn = d.mountpoint && d.kind !== 'system' && (d.removable || d.kind === 'disk')
      ? h('button', { class: 'sb-action icon-btn tiny eject', title: d.removable ? 'Expulsar' : 'Desmontar', html: ic('eject'), onclick: (e) => { e.stopPropagation(); d.removable ? ejectDrive(d) : unmountDrive(d); } })
      : null;
    return sbItem({
      icon, label: d.label, path: d.mountpoint, title, usage: d.mountpoint ? usage : null, extra: ejectBtn, cls: d.mountpoint ? '' : 'unmounted', drop: d.mountpoint,
      onclick: () => openDrive(d),
      oncontext: (e) => Menu.show(d.mountpoint ? placeMenu(d.mountpoint, d.kind === 'system' ? [] : ['-',
        { label: 'Desmontar', icon: 'eject', action: () => unmountDrive(d) },
        d.removable && d.parent ? { label: 'Expulsar de forma segura', icon: 'eject', action: () => ejectDrive(d) } : null]) : [
        { label: 'Montar', icon: 'disk', action: () => openDrive(d, true) },
        { label: 'Montar y abrir', icon: 'folderOpen', action: () => openDrive(d) },
      ], e.clientX, e.clientY),
    });
  });
  host.appendChild(sbSection('devices', 'Dispositivos', drv));
  host.scrollTop = scroll;
  renderSidebarActive();
}
function renderSidebarActive() {
  const p = pane();
  if (!p) return;
  $$('#sb-scroll .sb-item').forEach((el) => el.classList.toggle('active', !!el.dataset.path && el.dataset.path === p.path && !p.search));
}
async function openDrive(d, onlyMount) {
  if (d.mountpoint) { navigate(pane(), d.mountpoint); return; }
  const close = toast(`Montando «${d.label}»…`, { icon: 'disk', timeout: 15000 });
  try {
    const r = await api.call('drive:mount', d.device);
    close();
    if (!r.ok) { toast(`No se pudo montar «${d.label}»: ${r.error}`, { type: 'error' }); return; }
    await refreshDrives();
    renderSidebar();
    const mp = r.mountpoint || (S.drives.find((x) => x.id === d.id) || {}).mountpoint;
    if (mp && !onlyMount) navigate(pane(), mp);
  } catch (e) { close(); errorToast(e); }
}
async function unmountDrive(d) {
  leaveDrive(d);
  const r = await api.call('drive:unmount', d).catch((e) => ({ ok: false, error: e.message }));
  if (!r.ok) toast(`No se pudo desmontar «${d.label}»: ${r.error}`, { type: 'error' });
  else toast(`«${d.label}» desmontada`, { icon: 'eject' });
  await refreshDrives(); renderSidebar();
}
async function ejectDrive(d) {
  leaveDrive(d);
  const r = await api.call('drive:eject', d).catch((e) => ({ ok: false, error: e.message }));
  if (!r.ok) toast(`No se pudo expulsar «${d.label}»: ${r.error}`, { type: 'error' });
  else toast(r.warning || `Ya puedes retirar «${d.label}» con seguridad`, { icon: 'check' });
  await refreshDrives(); renderSidebar();
}
function leaveDrive(d) {
  for (const p of allPanes()) if (p.path && d.mountpoint && (p.path === d.mountpoint || p.path.startsWith(d.mountpoint + '/'))) { api.call('fs:unwatch', p.id).catch(() => {}); navigate(p, S.home, { silent: true }); }
}

/* marcadores */
async function addBookmark(path, quiet) {
  if (!path || isVirtual(path)) return;
  if (S.bookmarks.some((b) => b.path === path)) { if (!quiet) toast('Esa carpeta ya está en marcadores', { icon: 'bookmark' }); return; }
  S.bookmarks = await api.call('places:setBookmarks', [...S.bookmarks, { path, label: basename(path) }]);
  renderSidebar();
  if (!quiet) toast(`«${displayName(path)}» añadida a marcadores`, { icon: 'bookmark' });
}
async function removeBookmark(i) { const list = S.bookmarks.slice(); list.splice(i, 1); S.bookmarks = await api.call('places:setBookmarks', list); renderSidebar(); }
async function moveBookmark(i, d) { const list = S.bookmarks.slice(); const [b] = list.splice(i, 1); list.splice(i + d, 0, b); S.bookmarks = await api.call('places:setBookmarks', list); renderSidebar(); }
async function renameBookmark(i) {
  const b = S.bookmarks[i];
  const name = await promptDialog('Renombrar marcador', { label: 'Nombre', value: b.label, okLabel: 'Renombrar' });
  if (!name) return;
  const list = S.bookmarks.slice(); list[i] = Object.assign({}, b, { label: name });
  S.bookmarks = await api.call('places:setBookmarks', list); renderSidebar();
}

/* ---------- paneles redimensionables ---------- */
function initSidebarResize() {
  const handle = $('#sb-resize');
  handle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    const move = (ev) => { const w = Math.max(170, Math.min(420, ev.clientX)); document.documentElement.style.setProperty('--sidebar-w', w + 'px'); S.config.sidebarWidth = w; };
    const up = () => { document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up); document.body.classList.remove('resizing'); setConfig({ sidebarWidth: S.config.sidebarWidth }); };
    document.body.classList.add('resizing');
    document.addEventListener('mousemove', move); document.addEventListener('mouseup', up);
  });
}
function initPreviewResize() {
  const handle = $('#pv-resize');
  handle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    const move = (ev) => { const w = Math.max(220, Math.min(640, window.innerWidth - ev.clientX)); document.documentElement.style.setProperty('--preview-w', w + 'px'); S.config.previewWidth = w; };
    const up = () => { document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up); document.body.classList.remove('resizing'); setConfig({ previewWidth: S.config.previewWidth }); };
    document.body.classList.add('resizing');
    document.addEventListener('mousemove', move); document.addEventListener('mouseup', up);
  });
}
function toggleSidebar() { setConfig({ sidebar: !S.config.sidebar }); applyTheme(); updateChrome(); }
function togglePreview() { setConfig({ preview: !S.config.preview }); applyTheme(); updateChrome(); schedulePreview(true); }
function toggleHidden() {
  setConfig({ showHidden: !S.config.showHidden });
  allPanes().forEach((p) => { computeVisible(p); if (p.el) renderPane(p, { keepScroll: true }); });
  toast(S.config.showHidden ? 'Mostrando archivos ocultos' : 'Archivos ocultos escondidos', { icon: S.config.showHidden ? 'eye' : 'eyeOff', timeout: 1800 });
}

document.addEventListener('DOMContentLoaded', () => { init().catch((e) => { console.error(e); document.body.innerHTML = `<pre style="padding:20px">Error al iniciar Cajón:\n${esc(e.stack || e)}</pre>`; }); });
