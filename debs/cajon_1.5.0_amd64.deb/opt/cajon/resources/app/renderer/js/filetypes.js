'use strict';
/* Clasificación de archivos por extensión */
const FT = (() => {
  const groups = {
    image: ['jpg', 'jpeg', 'jfif', 'png', 'gif', 'webp', 'bmp', 'svg', 'ico', 'tif', 'tiff', 'heic', 'heif', 'avif', 'raw', 'cr2', 'nef', 'arw', 'dng', 'psd', 'xcf', 'apng'],
    video: ['mp4', 'mkv', 'webm', 'avi', 'mov', 'm4v', 'wmv', 'flv', 'mpg', 'mpeg', '3gp', 'ts', 'ogv', 'vob'],
    audio: ['mp3', 'wav', 'flac', 'ogg', 'oga', 'opus', 'm4a', 'aac', 'wma', 'aiff', 'mid', 'midi', 'ape'],
    pdf: ['pdf'],
    doc: ['doc', 'docx', 'odt', 'rtf', 'pages', 'wpd'],
    sheet: ['xls', 'xlsx', 'xlsm', 'ods', 'csv', 'tsv', 'numbers'],
    slides: ['ppt', 'pptx', 'odp', 'key'],
    archive: ['zip', 'rar', '7z', 'tar', 'gz', 'tgz', 'xz', 'txz', 'bz2', 'tbz2', 'zst', 'lz', 'lzma', 'cab', 'jar', 'apk'],
    code: ['js', 'mjs', 'cjs', 'ts', 'tsx', 'jsx', 'py', 'c', 'h', 'cpp', 'hpp', 'cc', 'cs', 'java', 'kt', 'rs', 'go', 'php', 'rb', 'sh', 'bash', 'zsh', 'fish', 'html', 'htm', 'css', 'scss', 'sass', 'less', 'json', 'xml', 'yml', 'yaml', 'toml', 'sql', 'lua', 'swift', 'dart', 'vue', 'svelte', 'pl', 'r', 'ipynb', 'gradle', 'makefile', 'cmake', 'desktop', 'service'],
    text: ['txt', 'md', 'markdown', 'log', 'ini', 'conf', 'cfg', 'nfo', 'srt', 'vtt', 'tex', 'rst', 'org', 'list'],
    package: ['deb', 'rpm', 'appimage', 'flatpak', 'flatpakref', 'snap'],
    exec: ['exe', 'msi', 'bin', 'run', 'bat', 'cmd', 'com'],
    font: ['ttf', 'otf', 'woff', 'woff2', 'pfb'],
    disk: ['iso', 'img', 'dmg', 'vdi', 'vmdk', 'qcow2'],
    ebook: ['epub', 'mobi', 'azw', 'azw3', 'fb2', 'djvu', 'cbz', 'cbr'],
    cert: ['p12', 'pfx', 'pem', 'crt', 'cer', 'key', 'der', 'csr'],
  };
  const extKind = new Map();
  for (const [k, list] of Object.entries(groups)) for (const e of list) extKind.set(e, k);

  const names = {
    image: 'Imagen', video: 'Vídeo', audio: 'Audio', pdf: 'Documento PDF', doc: 'Documento de texto', sheet: 'Hoja de cálculo',
    slides: 'Presentación', archive: 'Archivo comprimido', code: 'Código fuente', text: 'Texto', package: 'Paquete de software',
    exec: 'Ejecutable', font: 'Fuente', disk: 'Imagen de disco', ebook: 'Libro electrónico', cert: 'Certificado', file: 'Archivo',
  };
  const special = {
    md: 'Documento Markdown', txt: 'Texto sin formato', csv: 'Valores separados por comas', json: 'Datos JSON', deb: 'Paquete Debian',
    appimage: 'Aplicación AppImage', docx: 'Documento de Word', doc: 'Documento de Word', odt: 'Documento de texto ODF', xlsx: 'Hoja de Excel',
    xls: 'Hoja de Excel', ods: 'Hoja de cálculo ODF', pptx: 'Presentación de PowerPoint', ppt: 'Presentación de PowerPoint', odp: 'Presentación ODF',
    py: 'Script de Python', sh: 'Script de shell', js: 'Código JavaScript', ts: 'Código TypeScript', html: 'Página web', htm: 'Página web',
    css: 'Hoja de estilos', desktop: 'Lanzador de aplicación', iso: 'Imagen de disco ISO', svg: 'Imagen vectorial SVG', exe: 'Ejecutable de Windows',
    p12: 'Certificado digital', pfx: 'Certificado digital', torrent: 'Archivo torrent', log: 'Registro',
  };

  function ext(name) {
    const lower = name.toLowerCase();
    for (const m of ['tar.gz', 'tar.xz', 'tar.bz2', 'tar.zst']) if (lower.endsWith('.' + m)) return m;
    const i = lower.lastIndexOf('.');
    if (i <= 0) return lower === 'makefile' ? 'makefile' : '';
    return lower.slice(i + 1);
  }

  function kind(e) {
    if (e.isDir) return 'folder';
    const x = ext(e.name);
    if (x.startsWith('tar.')) return 'archive';
    const k = extKind.get(x);
    if (k) return k;
    if (e.exec && !x) return 'exec';
    return 'file';
  }

  function typeName(e) {
    if (e.isDir) return 'Carpeta';
    if (e.broken) return 'Enlace roto';
    const x = ext(e.name);
    if (special[x]) return special[x];
    const k = kind(e);
    if (k === 'file') return x ? `Archivo ${x.toUpperCase()}` : (e.exec ? 'Programa' : 'Archivo');
    if (['image', 'video', 'audio', 'archive'].includes(k) && x) return `${names[k]} ${x.toUpperCase()}`;
    return names[k];
  }

  const previewable = {
    image: new Set(['jpg', 'jpeg', 'jfif', 'png', 'gif', 'webp', 'bmp', 'svg', 'ico', 'avif', 'apng']),
    video: new Set(['mp4', 'webm', 'mkv', 'mov', 'm4v', 'ogv']),
    audio: new Set(['mp3', 'wav', 'flac', 'ogg', 'oga', 'opus', 'm4a', 'aac']),
  };
  function previewType(e) {
    if (e.isDir) return 'folder';
    const x = ext(e.name);
    const k = kind(e);
    if (previewable.image.has(x)) return 'image';
    if (previewable.video.has(x)) return 'video';
    if (previewable.audio.has(x)) return 'audio';
    if (x === 'pdf') return 'pdf';
    if (k === 'code' || k === 'text' || ['csv', 'tsv'].includes(x) || (!x && e.size < 2000000)) return 'text';
    return 'none';
  }
  function hasThumb(e) {
    if (e.isDir) return false;
    const x = ext(e.name);
    return previewable.image.has(x) || groups.video.includes(x) || x === 'pdf';
  }
  function isArchive(e) { return !e.isDir && kind(e) === 'archive'; }
  return { ext, kind, typeName, previewType, hasThumb, isArchive };
})();
