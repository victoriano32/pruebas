'use strict';
/* Iconos de interfaz (trazo) y de archivos (color) */
const ICONS = {
  back: '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  forward: '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  up: '<path d="m5 12 7-7 7 7"/><path d="M12 19V5"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/>',
  search: '<circle cx="11" cy="11" r="7.5"/><path d="m21 21-4.3-4.3"/>',
  grid: '<rect width="7" height="7" x="3" y="3" rx="1.6"/><rect width="7" height="7" x="14" y="3" rx="1.6"/><rect width="7" height="7" x="14" y="14" rx="1.6"/><rect width="7" height="7" x="3" y="14" rx="1.6"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
  split: '<rect width="18" height="18" x="3" y="3" rx="2.5"/><path d="M12 3v18"/>',
  sidebar: '<rect width="18" height="18" x="3" y="3" rx="2.5"/><path d="M9 3v18"/>',
  panelRight: '<rect width="18" height="18" x="3" y="3" rx="2.5"/><path d="M15 3v18"/>',
  plus: '<path d="M5 12h14M12 5v14"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  home: '<path d="m3 10 9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V13h6v9"/>',
  desktop: '<rect width="20" height="14" x="2" y="3" rx="2"/><path d="M8 21h8M12 17v4"/>',
  documents: '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/>',
  downloads: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5M12 15V3"/>',
  pictures: '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>',
  music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  videos: '<path d="m22 8-6 4 6 4V8z"/><rect width="14" height="12" x="2" y="6" rx="2"/>',
  templates: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18M9 21V9"/>',
  public: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  trash: '<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6M14 11v6"/>',
  trashFull: '<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M9 12h6M9 16h6"/>',
  recent: '<circle cx="12" cy="12" r="9.5"/><path d="M12 6.5V12l3.5 2"/>',
  disk: '<path d="M22 12H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/><path d="M6 16h.01M10 16h.01"/>',
  system: '<rect width="20" height="8" x="2" y="2" rx="2"/><rect width="20" height="8" x="2" y="14" rx="2"/><path d="M6 6h.01M6 18h.01"/>',
  usb: '<rect x="6.5" y="9" width="11" height="13" rx="2"/><path d="M9 9V3h6v6M10.5 6h.01M13.5 6h.01"/>',
  network: '<rect width="16" height="6" x="4" y="3" rx="1.5"/><path d="M12 9v5M5 18h14M12 14v4M5 18v3M19 18v3"/>',
  optical: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="2.5"/>',
  bookmark: '<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>',
  folder: '<path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"/>',
  folderOpen: '<path d="m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2"/>',
  eject: '<path d="M5 18h14"/><path d="m12 5-7 8h14z"/>',
  settings: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  more: '<circle cx="12" cy="5" r="1.2" fill="currentColor"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/><circle cx="12" cy="19" r="1.2" fill="currentColor"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>',
  moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
  copy: '<rect width="13" height="13" x="9" y="9" rx="2"/><path d="M5 15c-1.1 0-2-.9-2-2V5c0-1.1.9-2 2-2h8c1.1 0 2 .9 2 2"/>',
  cut: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4 8.12 15.88M14.47 14.48 20 20M8.12 8.12 12 12"/>',
  paste: '<rect width="8" height="4" x="8" y="2" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>',
  rename: '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>',
  newFolder: '<path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"/><path d="M12 10v6M9 13h6"/>',
  newFile: '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><path d="M14 2v6h6M12 18v-6M9 15h6"/>',
  terminal: '<rect width="20" height="18" x="2" y="3" rx="2.5"/><path d="m7 9 3 3-3 3M13 15h4"/>',
  archive: '<rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8M10 12h4"/>',
  extract: '<rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="m9 15 3 3 3-3M12 11v7"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
  external: '<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  chevronRight: '<path d="m9 18 6-6-6-6"/>',
  chevronDown: '<path d="m6 9 6 6 6-6"/>',
  sort: '<path d="m21 16-4 4-4-4M17 20V4M3 8l4-4 4 4M7 4v16"/>',
  eye: '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff: '<path d="M9.88 9.88a3 3 0 1 0 4.24 4.24M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68M6.61 6.61A13.53 13.53 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61M2 2l20 20"/>',
  minimize: '<path d="M6 12h12"/>',
  maximize: '<rect x="6" y="6" width="12" height="12" rx="1.5"/>',
  restore: '<rect x="8.5" y="5" width="10.5" height="10.5" rx="1.5"/><path d="M15.5 15.5v2A1.5 1.5 0 0 1 14 19H6.5A1.5 1.5 0 0 1 5 17.5V10A1.5 1.5 0 0 1 6.5 8.5h2"/>',
  close: '<path d="M7 7l10 10M17 7 7 17"/>',
  undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
  star: '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>',
  keyboard: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="M6 8h.01M10 8h.01M14 8h.01M18 8h.01M8 12h.01M12 12h.01M16 12h.01M7 16h10"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  selectAll: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><path d="m9 12 2 2 4-4"/>',
  rotateCcw: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
  lock: '<rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  window: '<rect width="18" height="18" x="3" y="3" rx="2.5"/><path d="M3 9h18"/>',
  tab: '<path d="M3 8a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  play: '<path d="m7 4 13 8-13 8z"/>',
  zoomIn: '<circle cx="11" cy="11" r="7.5"/><path d="m21 21-4.3-4.3M11 8v6M8 11h6"/>',
  zoomOut: '<circle cx="11" cy="11" r="7.5"/><path d="m21 21-4.3-4.3M8 11h6"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  alert: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4M12 17h.01"/>',
  palette: '<circle cx="13.5" cy="6.5" r="1.2" fill="currentColor"/><circle cx="17.5" cy="10.5" r="1.2" fill="currentColor"/><circle cx="8.5" cy="7.5" r="1.2" fill="currentColor"/><circle cx="6.5" cy="12.5" r="1.2" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.93 0 1.65-.75 1.65-1.69 0-.44-.18-.84-.44-1.13-.29-.29-.44-.65-.44-1.13a1.64 1.64 0 0 1 1.67-1.67h2c3.05 0 5.56-2.5 5.56-5.55C21.97 6.01 17.46 2 12 2z"/>',
  tiles: '<rect x="3" y="4" width="7" height="7" rx="1.6"/><path d="M13.5 6h7.5M13.5 9.2h4.5"/><rect x="3" y="13" width="7" height="7" rx="1.6"/><path d="M13.5 15h7.5M13.5 18.2h4.5"/>',
  compact: '<path d="M3 5.5h2M8 5.5h4M3 10.5h2M8 10.5h4M3 15.5h2M8 15.5h4M3 20.5h2M8 20.5h4M15 5.5h1.5M18.5 5.5h2.5M15 10.5h1.5M18.5 10.5h2.5M15 15.5h1.5M18.5 15.5h2.5"/>',
  columns: '<rect width="18" height="18" x="3" y="3" rx="2.5"/><path d="M9 3v18M15 3v18"/>',
  gallery: '<rect x="3" y="3" width="18" height="12.5" rx="2"/><path d="m3 13 4.5-4.5 4 4 2.5-2.5L21 16"/><rect x="3" y="18.5" width="4.5" height="2.5" rx="1"/><rect x="9.75" y="18.5" width="4.5" height="2.5" rx="1"/><rect x="16.5" y="18.5" width="4.5" height="2.5" rx="1"/>',
  group: '<path d="M12 3 2 8l10 5 10-5z"/><path d="m2 16 10 5 10-5M2 12l10 5 10-5"/>',
  table: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><path d="M3 9h18M9 9v12M15 9v12"/>',
  sortAsc: '<path d="m3 8 4-4 4 4M7 4v16M11 12h4M11 16h7M11 20h10"/>',
  sortDesc: '<path d="m3 16 4 4 4-4M7 20V4M11 4h10M11 8h7M11 12h4"/>',
  printer: '<path d="M6 9V3h12v6"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8" rx="1"/>',
  wallpaper: '<rect width="20" height="14" x="2" y="3" rx="2"/><path d="M8 21h8M12 17v4"/><path d="m6 14 3.5-3.5 2.5 2.5 2-2 4 3"/><circle cx="15.5" cy="7.5" r="1.2"/>',
  copyImage: '<rect width="13" height="13" x="9" y="9" rx="2"/><path d="M5 15c-1.1 0-2-.9-2-2V5c0-1.1.9-2 2-2h8c1.1 0 2 .9 2 2"/><path d="m9 19 3.5-3.5 2 2 2.5-2.5 5 4.5"/><circle cx="17.5" cy="12.5" r="1"/>',
  hash: '<path d="M4 9h16M4 15h16M10 3 8 21M16 3l-2 18"/>',
};

function ic(name, cls) {
  return `<svg class="ic${cls ? ' ' + cls : ''}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ''}</svg>`;
}

const FILE_COLORS = {
  image: '#a855f7', video: '#ec4899', audio: '#14b8a6', pdf: '#ef4444', doc: '#2563eb', sheet: '#16a34a', slides: '#f97316',
  archive: '#d4a106', code: '#6366f1', text: '#64748b', package: '#0ea5e9', exec: '#475569', font: '#d946ef', disk: '#78716c',
  ebook: '#b45309', cert: '#0d9488', file: '#94a3b8',
};
const FILE_GLYPHS = {
  image: '<path d="M22 44l7-9 5 6 4-4 6 7z" fill="currentColor" opacity=".9"/><circle cx="27" cy="30" r="3" fill="currentColor" opacity=".9"/>',
  video: '<path d="M27 26v16l13-8z" fill="currentColor"/>',
  audio: '<path d="M29 41V27l11-2v13" stroke="currentColor" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle cx="26.5" cy="41.5" r="3.2" fill="currentColor"/><circle cx="37.5" cy="38.5" r="3.2" fill="currentColor"/>',
  code: '<path d="M27 28l-6 6 6 6M37 28l6 6-6 6" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
  text: '<path d="M22 27h20M22 33h20M22 39h13" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>',
  doc: '<path d="M22 27h20M22 33h20M22 39h20M22 45h12" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
  sheet: '<rect x="21" y="25" width="22" height="20" rx="2" stroke="currentColor" stroke-width="2.2" fill="none"/><path d="M21 32h22M21 39h22M29 25v20" stroke="currentColor" stroke-width="2.2"/>',
  slides: '<rect x="20" y="26" width="24" height="16" rx="2" stroke="currentColor" stroke-width="2.4" fill="none"/><path d="M32 42v5M27 47h10" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
  pdf: '<path d="M24 44c3-6 6-14 7-18 1 5 4 11 9 14-5 0-11 1-16 4z" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linejoin="round"/>',
  archive: '<path d="M30 14h4M30 20h4M30 26h4M30 32h4" stroke="currentColor" stroke-width="3"/><rect x="28" y="35" width="8" height="9" rx="2" fill="currentColor"/>',
  package: '<path d="M32 23l11 5v12l-11 5-11-5V28z" stroke="currentColor" stroke-width="2.3" fill="none" stroke-linejoin="round"/><path d="M21 28l11 5 11-5M32 33v12" stroke="currentColor" stroke-width="2.3" fill="none"/>',
  exec: '<path d="M23 29l6 5-6 5M32 41h9" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
  font: '<text x="32" y="44" text-anchor="middle" font-family="Georgia,serif" font-size="22" font-weight="700" fill="currentColor">Aa</text>',
  disk: '<circle cx="32" cy="35" r="10" stroke="currentColor" stroke-width="2.4" fill="none"/><circle cx="32" cy="35" r="2.5" fill="currentColor"/>',
  ebook: '<path d="M21 27c4-2 8-2 11 1 3-3 7-3 11-1v16c-4-2-8-2-11 1-3-3-7-3-11-1z" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linejoin="round"/><path d="M32 28v16" stroke="currentColor" stroke-width="2.2"/>',
  cert: '<circle cx="32" cy="32" r="7" stroke="currentColor" stroke-width="2.4" fill="none"/><path d="M28 38l-2 9 6-3 6 3-2-9" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linejoin="round"/>',
  file: '',
};
const FOLDER_GLYPH = {
  home: ICONS.home, desktop: ICONS.desktop, documents: ICONS.documents, downloads: ICONS.downloads, pictures: ICONS.pictures,
  music: ICONS.music, videos: ICONS.videos, templates: ICONS.templates, public: ICONS.public, trash: ICONS.trash,
};

function folderSvg(glyph, opts = {}) {
  const g = glyph && FOLDER_GLYPH[glyph]
    ? `<svg x="22" y="28" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-opacity=".92" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round">${FOLDER_GLYPH[glyph]}</svg>`
    : '';
  const open = opts.open ? ' open' : '';
  return `<svg class="fi folder${open}" viewBox="0 0 64 64" aria-hidden="true">
<path d="M5 15.5A4.5 4.5 0 0 1 9.5 11h14.2a4.5 4.5 0 0 1 3.3 1.45L30.6 16.5H54.5A4.5 4.5 0 0 1 59 21v4H5z" class="fb"/>
<path d="M5 22.5A4.5 4.5 0 0 1 9.5 18h45a4.5 4.5 0 0 1 4.5 4.5v27A4.5 4.5 0 0 1 54.5 54h-45A4.5 4.5 0 0 1 5 49.5z" class="ff"/>
<path d="M5 22.5A4.5 4.5 0 0 1 9.5 18h45a4.5 4.5 0 0 1 4.5 4.5v1.5H5z" fill="#fff" opacity=".18"/>${g}</svg>`;
}

function fileSvg(kind, extLabel) {
  const color = FILE_COLORS[kind] || FILE_COLORS.file;
  const glyph = FILE_GLYPHS[kind] || '';
  const label = (extLabel || '').toUpperCase().slice(0, 5);
  const badge = label
    ? `<rect x="6" y="40" width="${Math.max(22, label.length * 6.6 + 10)}" height="14" rx="3.5" fill="${color}"/><text x="${6 + Math.max(22, label.length * 6.6 + 10) / 2}" y="50.2" text-anchor="middle" font-family="Inter,Ubuntu,'Noto Sans',sans-serif" font-size="8.6" font-weight="700" fill="#fff" letter-spacing=".3">${label}</text>`
    : '';
  return `<svg class="fi file" viewBox="0 0 64 64" aria-hidden="true">
<path d="M16 5h20.5L51 19.5V55a4 4 0 0 1-4 4H16a4 4 0 0 1-4-4V9a4 4 0 0 1 4-4z" class="pg"/>
<path d="M36.5 5v10.5a4 4 0 0 0 4 4H51z" fill="${color}" opacity=".35"/>
<g style="color:${color}" transform="translate(0,-3)">${glyph}</g>${badge}</svg>`;
}

function linkBadge() {
  return '<span class="link-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17 17 7M8 7h9v9"/></svg></span>';
}
