'use strict';
/* Cajón — vista previa, propiedades, abrir con, renombrado en lote, preferencias */

/* ---------- contenido de vista previa (compartido) ---------- */
function bigIcon(e) {
  if (e.isDir) return folderSvg(glyphFor(e.path));
  const x = FT.ext(e.name);
  return fileSvg(FT.kind(e), x.length <= 5 ? x.split('.').pop() : '');
}
async function buildMedia(e, { large, onMeta } = {}) {
  const type = FT.previewType(e);
  const wrap = h('div', { class: `pv-media type-${type}` });
  const iconBox = () => h('div', { class: 'pv-icon', html: bigIcon(e) });
  if (e.broken) { wrap.appendChild(iconBox()); return wrap; }
  if (type === 'image') {
    const img = h('img', { src: fileUrl(e.path) + '?m=' + Math.round(e.mtime), draggable: 'false', alt: '' });
    img.addEventListener('load', () => onMeta && onMeta({ dims: `${img.naturalWidth} × ${img.naturalHeight} píxeles` }));
    img.addEventListener('error', () => { img.replaceWith(iconBox()); });
    wrap.appendChild(img);
  } else if (type === 'video') {
    const v = h('video', { src: fileUrl(e.path), controls: true, preload: 'metadata', autoplay: large ? true : null });
    v.addEventListener('loadedmetadata', () => onMeta && onMeta({ duration: fmtDuration(v.duration), dims: v.videoWidth ? `${v.videoWidth} × ${v.videoHeight}` : null }));
    v.addEventListener('error', () => { v.replaceWith(iconBox()); });
    wrap.appendChild(v);
  } else if (type === 'audio') {
    wrap.appendChild(iconBox());
    const a = h('audio', { src: fileUrl(e.path), controls: true, preload: 'metadata', autoplay: large ? true : null });
    a.addEventListener('loadedmetadata', () => onMeta && onMeta({ duration: fmtDuration(a.duration) }));
    wrap.appendChild(a);
  } else if (type === 'pdf') {
    if (large) wrap.appendChild(h('iframe', { src: fileUrl(e.path) + '#toolbar=1&navpanes=0', class: 'pv-pdf' }));
    else {
      const img = h('img', { src: `thumb://t/?p=${encodeURIComponent(e.path)}&s=512&m=${Math.round(e.mtime)}`, class: 'pv-page', alt: '' });
      img.addEventListener('error', () => img.replaceWith(iconBox()));
      wrap.appendChild(img);
    }
  } else if (type === 'text') {
    try {
      const r = await api.call('fs:readText', e.path, large ? 400000 : 60000);
      if (r.binary) wrap.appendChild(iconBox());
      else {
        const pre = h('pre', { class: 'pv-text' });
        pre.textContent = r.text + (r.truncated ? '\n…' : '');
        wrap.appendChild(pre);
      }
    } catch (_) { wrap.appendChild(iconBox()); }
  } else if (type === 'folder') {
    wrap.appendChild(iconBox());
  } else {
    if (FT.hasThumb(e)) {
      const img = h('img', { src: `thumb://t/?p=${encodeURIComponent(e.path)}&s=512&m=${Math.round(e.mtime)}`, alt: '' });
      img.addEventListener('error', () => img.replaceWith(iconBox()));
      wrap.appendChild(img);
    } else wrap.appendChild(iconBox());
  }
  return wrap;
}
function fmtDuration(s) {
  if (!isFinite(s)) return null;
  s = Math.round(s);
  const hh = Math.floor(s / 3600); const mm = Math.floor((s % 3600) / 60); const ss = s % 60;
  return (hh ? hh + ':' + String(mm).padStart(2, '0') : mm) + ':' + String(ss).padStart(2, '0');
}

/* ---------- panel de vista previa ---------- */
let pvTimer = null; let pvToken = 0; let pvKey = '';
function initPreview() {
  $('#pv-close').innerHTML = ic('x');
  $('#pv-close').onclick = togglePreview;
}
function schedulePreview(force) {
  if (!S.config.preview) return;
  clearTimeout(pvTimer);
  pvTimer = setTimeout(() => renderPreview(force), force ? 0 : 110);
}
async function renderPreview(force) {
  const p = pane();
  if (!p || !p.path) return;
  const sel = selected(p);
  const key = p.path + '§' + sel.map((e) => e.path + e.mtime).join('|');
  if (key === pvKey && !force) return;
  pvKey = key;
  const token = ++pvToken;
  const host = $('#pv-content');
  const rows = [];
  let media;
  let title; let sub;
  if (sel.length === 1) {
    const e = sel[0];
    title = e.name; sub = FT.typeName(e);
    const meta = {};
    media = await buildMedia(e, { onMeta: (m) => { Object.assign(meta, m); if (m.dims) addRow('Dimensiones', m.dims); if (m.duration) addRow('Duración', m.duration); } });
    if (token !== pvToken) return;
    if (e.isDir) rows.push(['Contenido', e.children == null ? '—' : plural(e.children, 'elemento', 'elementos')]);
    else rows.push(['Tamaño', `${fmtSize(e.size)}${e.size >= 1000 ? ` <span class="dim">(${fmtNum(e.size)} bytes)</span>` : ''}`]);
    if (p.path === TRASH) {
      rows.push(['Ubicación original', esc(e.origPath ? prettyDir(dirname(e.origPath)) : '—')]);
      rows.push(['Eliminado', esc(fmtDateLong(e.deletedAt))]);
    } else rows.push(['Ubicación', `<a class="lnk" data-go="${esc(dirname(e.path))}">${esc(prettyDir(dirname(e.path)))}</a>`]);
    rows.push(['Modificado', esc(fmtDateLong(e.mtime))]);
    if (e.btime) rows.push(['Creado', esc(fmtDateLong(e.btime))]);
    rows.push(['Permisos', `<code>${permString(e.mode, e.isDir)}</code>`]);
    if (e.isLink) rows.push(['Enlace a', esc(e.target || '—')]);
  } else if (sel.length > 1) {
    title = `${fmtNum(sel.length)} elementos`;
    const dirs = sel.filter((e) => e.isDir).length;
    sub = `${plural(dirs, 'carpeta', 'carpetas')}, ${plural(sel.length - dirs, 'archivo', 'archivos')}`;
    media = h('div', { class: 'pv-media stack' }, ...sel.slice(0, 3).map((e, i) => h('div', { class: 'pv-icon st', style: { transform: `rotate(${(i - 1) * 8}deg) translateY(${Math.abs(i - 1) * 6}px)` }, html: bigIcon(e) })));
    const size = sel.filter((e) => !e.isDir).reduce((a, e) => a + e.size, 0);
    rows.push(['Tamaño de archivos', fmtSize(size)]);
    const latest = Math.max(...sel.map((e) => e.mtime || 0));
    rows.push(['Último cambio', esc(fmtDateLong(latest))]);
  } else {
    const isV = isVirtual(p.path);
    title = p.search ? `Búsqueda «${p.search.query}»` : displayName(p.path);
    sub = p.search ? `${plural(p.visible.length, 'resultado', 'resultados')}` : isV ? (p.path === TRASH ? 'Papelera' : 'Archivos usados recientemente') : 'Carpeta';
    media = h('div', { class: 'pv-media' }, h('div', { class: 'pv-icon', html: p.path === TRASH ? folderSvg('trash') : p.path === RECENT ? `<div class="pv-glyph">${ic('recent')}</div>` : folderSvg(glyphFor(p.path)) }));
    const dirs = p.visible.filter((e) => e.isDir).length;
    rows.push(['Contenido', `${plural(p.visible.length, 'elemento', 'elementos')}`]);
    rows.push(['', `<span class="dim">${plural(dirs, 'carpeta', 'carpetas')} · ${plural(p.visible.length - dirs, 'archivo', 'archivos')}</span>`]);
    if (!isV && !p.search) {
      const sz = p.visible.filter((e) => !e.isDir).reduce((a, e) => a + e.size, 0);
      rows.push(['Archivos sueltos', fmtSize(sz)]);
      rows.push(['Ruta', `<code class="wrap">${esc(p.path)}</code>`]);
      try {
        const d = await api.call('fs:statfs', p.path);
        if (token !== pvToken) return;
        if (d && d.total) rows.push(['Espacio libre', `${fmtSize(d.free)} de ${fmtSize(d.total)}<div class="usage big"><span style="width:${Math.round((1 - d.free / d.total) * 100)}%"></span></div>`]);
      } catch (_) { /* nada */ }
    }
  }
  if (token !== pvToken) return;
  host.innerHTML = '';
  const table = h('div', { class: 'pv-rows' });
  const addRowEl = (k, v) => table.appendChild(h('div', { class: 'pv-row' }, h('div', { class: 'pv-k', text: k }), h('div', { class: 'pv-v', html: v })));
  rows.forEach(([k, v]) => addRowEl(k, v));
  function addRow(k, v) { if (token === pvToken && !$$('.pv-k', table).some((el) => el.textContent === k)) addRowEl(k, esc(v)); }
  const actions = h('div', { class: 'pv-actions' });
  if (sel.length === 1 && p.path !== TRASH) {
    const e = sel[0];
    actions.appendChild(h('button', { class: 'btn small', onclick: () => openEntries([e]) }, h('span', { html: ic('folderOpen') }), 'Abrir'));
    if (!e.isDir) actions.appendChild(h('button', { class: 'btn small ghost', onclick: () => openWithDialog([e]) }, h('span', { html: ic('external') }), 'Abrir con…'));
    if (isCopyableImage(e)) actions.appendChild(h('button', { class: 'btn small ghost', title: 'Copiar imagen (Ctrl+Alt+C)', onclick: () => copyImage(e) }, h('span', { html: ic('copyImage') })));
    if (isWallpaperable(e)) actions.appendChild(h('button', { class: 'btn small ghost', title: 'Establecer como fondo de pantalla', onclick: (ev) => Menu.showAt(wallpaperMenu(e), ev.currentTarget) }, h('span', { html: ic('wallpaper') })));
    if (isPrintable(e)) actions.appendChild(h('button', { class: 'btn small ghost', title: 'Imprimir (Ctrl+P)', onclick: () => printDialog([e]) }, h('span', { html: ic('printer') })));
    actions.appendChild(h('button', { class: 'btn small ghost', title: 'Propiedades', onclick: () => showProperties([e.path]) }, h('span', { html: ic('info') })));
  }
  host.append(media, h('div', { class: 'pv-title', text: title }), h('div', { class: 'pv-sub', text: sub }), actions, table);
  $$('[data-go]', host).forEach((a) => { a.onclick = () => navigate(p, a.dataset.go, { select: sel.length === 1 ? [sel[0].path] : null }); });
}

/* ---------- vista rápida (Espacio) ---------- */
const QL = {
  open: false, p: null, list: [], idx: 0, el: null,
  async show(p) {
    const sel = selected(p);
    let list = sel.length > 1 ? sel : p.visible;
    let start = sel.length ? list.findIndex((e) => e.path === (p.focus && p.sel.has(p.focus) ? p.focus : sel[0].path)) : -1;
    if (start < 0) { if (!p.visible.length) return; list = p.visible; start = 0; }
    this.p = p; this.list = list; this.idx = start; this.open = true;
    this.el = $('#quicklook');
    this.el.classList.remove('hidden');
    requestAnimationFrame(() => this.el.classList.add('in'));
    $('#ql-close').innerHTML = ic('x'); $('#ql-prev').innerHTML = ic('back'); $('#ql-next').innerHTML = ic('forward'); $('#ql-open-ic').innerHTML = ic('external');
    $('#ql-close').onclick = () => this.close();
    $('#ql-prev').onclick = () => this.go(-1);
    $('#ql-next').onclick = () => this.go(1);
    $('#ql-open').onclick = () => { const e = this.list[this.idx]; this.close(); openEntries([e]); };
    this.el.onmousedown = (ev) => { if (ev.target === this.el || ev.target.id === 'ql-stage') this.close(); };
    await this.render();
  },
  async render() {
    const e = this.list[this.idx];
    if (!e) return;
    const token = (this.token = (this.token || 0) + 1);
    $('#ql-title').textContent = e.name;
    const info = $('#ql-info');
    const base = e.isDir ? (e.children != null ? plural(e.children, 'elemento', 'elementos') : 'Carpeta') : `${FT.typeName(e)} · ${fmtSize(e.size)}`;
    info.textContent = `${base} · ${fmtDate(e.mtime)}`;
    $('#ql-count').textContent = this.list.length > 1 ? `${this.idx + 1} / ${this.list.length}` : '';
    $('#ql-prev').disabled = this.idx === 0;
    $('#ql-next').disabled = this.idx >= this.list.length - 1;
    const media = await buildMedia(e, { large: true, onMeta: (m) => { if (token === this.token) info.textContent = [base, m.dims, m.duration, fmtDate(e.mtime)].filter(Boolean).join(' · '); } });
    if (token !== this.token) return;
    const stage = $('#ql-stage');
    stage.innerHTML = '';
    stage.appendChild(media);
    if (this.p && this.p === pane()) { selectOnly(this.p, e.path); scrollToItem(this.p, e.path); }
  },
  go(d) {
    const i = this.idx + d;
    if (i < 0 || i >= this.list.length) return;
    this.idx = i;
    this.render();
  },
  close() {
    if (!this.open) return;
    this.open = false;
    this.el.classList.remove('in');
    const stage = $('#ql-stage');
    $$('video,audio', stage).forEach((m) => m.pause());
    setTimeout(() => { this.el.classList.add('hidden'); stage.innerHTML = ''; }, 160);
    if (this.p) this.p.viewEl.focus({ preventScroll: true });
  },
  key(e) {
    if (e.key === 'Escape' || e.key === ' ') { if (e.target.tagName === 'VIDEO' && e.key === ' ') return false; this.close(); return true; }
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { this.go(1); return true; }
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { this.go(-1); return true; }
    if (e.key === 'Enter') { const en = this.list[this.idx]; this.close(); openEntries([en]); return true; }
    return true;
  },
};
function quickLook(p) { QL.show(p); }

/* ---------- propiedades ---------- */
const dirSizeHandlers = new Map();
let dirSizeListen = false;
function computeDirSize(path, onProgress) {
  if (!dirSizeListen) { dirSizeListen = true; api.on('dirsize:progress', (pr) => { const f = dirSizeHandlers.get(pr.id); if (f) f(pr); }); }
  const id = 'd' + S.nextId++;
  dirSizeHandlers.set(id, onProgress);
  const prom = api.call('fs:dirsize', id, path).finally(() => dirSizeHandlers.delete(id));
  return { id, promise: prom, cancel: () => api.call('fs:dirsize:cancel', id).catch(() => {}) };
}

async function showProperties(paths) {
  if (!paths.length) return;
  let details;
  try { details = await Promise.all(paths.map((p) => api.call('fs:details', p))); } catch (e) { errorToast(e); return; }
  const jobsRunning = [];
  const multi = details.length > 1;
  const e = details[0];
  const tabs = h('div', { class: 'tabs-seg' });
  const panes = h('div', { class: 'prop-panes' });
  const addTab = (id, label, content) => {
    const b = h('button', { class: 'tseg', 'data-t': id, text: label });
    b.onclick = () => { $$('.tseg', tabs).forEach((x) => x.classList.toggle('on', x === b)); $$('.prop-pane', panes).forEach((x) => x.classList.toggle('hidden', x.dataset.t !== id)); };
    tabs.appendChild(b);
    panes.appendChild(h('div', { class: 'prop-pane', 'data-t': id }, content));
  };
  const rowsEl = h('div', { class: 'prop-rows' });
  const row = (k, v, cls) => { const r = h('div', { class: `prop-row ${cls || ''}` }, h('div', { class: 'pk', text: k }), h('div', { class: 'pv', html: v })); rowsEl.appendChild(r); return r; };
  let nameInput = null;
  const head = h('div', { class: 'prop-head' });
  if (!multi) {
    head.appendChild(h('div', { class: 'prop-icon', html: bigIcon(e) }));
    nameInput = h('input', { class: 'input prop-name', value: e.name, spellcheck: 'false', disabled: e.path === '/' || !e.writable && !e.isOwner ? true : null });
    head.appendChild(h('div', { class: 'prop-hinfo' }, nameInput, h('div', { class: 'dim', text: FT.typeName(e) })));
    row('Tipo', esc(FT.typeName(e)) + (e.isLink ? ' <span class="dim">(enlace simbólico)</span>' : ''));
    if (e.isLink) row('Enlace a', `<code class="wrap">${esc(e.target)}</code>`);
    row('Ubicación', `<a class="lnk" data-go="${esc(dirname(e.path))}">${esc(dirname(e.path))}</a>`);
    if (e.isDir) {
      const r = row('Tamaño', '<span class="spinner small"></span> Calculando…');
      const c = row('Contenido', '—');
      const job = computeDirSize(e.path, (pr) => { $('.pv', r).innerHTML = `<span class="spinner small"></span> ${fmtSize(pr.size)}…`; $('.pv', c).textContent = `${plural(pr.files, 'archivo', 'archivos')}, ${plural(pr.dirs, 'carpeta', 'carpetas')}`; });
      jobsRunning.push(job);
      job.promise.then((res) => { $('.pv', r).innerHTML = `${fmtSize(res.size)} <span class="dim">(${fmtNum(res.size)} bytes)</span>`; $('.pv', c).textContent = `${plural(res.files, 'archivo', 'archivos')}, ${plural(res.dirs, 'carpeta', 'carpetas')}`; }).catch(() => { $('.pv', r).textContent = '—'; });
      const df = await api.call('fs:statfs', e.path).catch(() => null);
      if (df && df.total) row('Espacio libre', `${fmtSize(df.free)} de ${fmtSize(df.total)}<div class="usage big"><span style="width:${Math.round((1 - df.free / df.total) * 100)}%"></span></div>`);
    } else row('Tamaño', `${fmtSize(e.size)} <span class="dim">(${fmtNum(e.size)} bytes)</span>`);
    row('Modificado', esc(fmtDateLong(e.mtime)), 'sep-top');
    row('Último acceso', esc(fmtDateLong(e.atime)));
    if (e.btime) row('Creado', esc(fmtDateLong(e.btime)));
    if (!e.isDir) {
      api.call('open:apps', e.path).then((r) => {
        row('Tipo MIME', `<code>${esc(r.mime)}</code>`, 'sep-top');
        const def = r.apps.find((a) => a.id === r.defaultId) || r.apps[0];
        if (def) row('Se abre con', `${def.iconData ? `<img class="app-ic-inline" src="${def.iconData}">` : ''}${esc(def.name)}`);
      }).catch(() => {});
    }
  } else {
    const dirs = details.filter((x) => x.isDir).length;
    head.appendChild(h('div', { class: 'prop-icon', html: folderSvg(null) }));
    head.appendChild(h('div', { class: 'prop-hinfo' }, h('div', { class: 'prop-title', text: `${fmtNum(details.length)} elementos` }), h('div', { class: 'dim', text: `${plural(dirs, 'carpeta', 'carpetas')}, ${plural(details.length - dirs, 'archivo', 'archivos')}` })));
    const parents = new Set(details.map((x) => dirname(x.path)));
    if (parents.size === 1) row('Ubicación', `<a class="lnk" data-go="${esc([...parents][0])}">${esc([...parents][0])}</a>`);
    const r = row('Tamaño total', '<span class="spinner small"></span> Calculando…');
    let total = 0; let files = 0;
    (async () => {
      for (const d of details) {
        const job = computeDirSize(d.path, () => {});
        jobsRunning.push(job);
        try { const res = await job.promise; total += res.size; files += res.files; } catch (_) { /* nada */ }
        $('.pv', r).innerHTML = `${fmtSize(total)} <span class="dim">· ${plural(files, 'archivo', 'archivos')}</span>`;
      }
    })();
  }
  addTab('general', 'General', h('div', {}, head, rowsEl));

  // permisos
  if (!multi || details.every((x) => x.isOwner)) {
    const perm = h('div', { class: 'perm' });
    const canEdit = details.every((x) => x.isOwner);
    perm.appendChild(h('div', { class: 'prop-rows' },
      h('div', { class: 'prop-row' }, h('div', { class: 'pk', text: 'Propietario' }), h('div', { class: 'pv', text: multi ? '—' : e.owner + (e.isOwner ? ' (tú)' : '') })),
      h('div', { class: 'prop-row' }, h('div', { class: 'pk', text: 'Grupo' }), h('div', { class: 'pv', text: multi ? '—' : e.group }))));
    const grid = h('div', { class: 'perm-grid' }, h('div'), h('div', { class: 'ph', text: 'Leer' }), h('div', { class: 'ph', text: 'Escribir' }), h('div', { class: 'ph', text: e.isDir ? 'Entrar' : 'Ejecutar' }));
    const who = [['Propietario', 6], ['Grupo', 3], ['Otros', 0]];
    let mode = e.mode & 0o7777;
    const octal = h('code', { class: 'octal' });
    const boxes = [];
    for (const [label, shift] of who) {
      grid.appendChild(h('div', { class: 'pl', text: label }));
      for (const bit of [4, 2, 1]) {
        const mask = bit << shift;
        const cb = h('input', { type: 'checkbox', disabled: !canEdit ? true : null });
        cb.checked = !!(mode & mask);
        cb.onchange = async () => {
          const newMode = cb.checked ? mode | mask : mode & ~mask;
          try { for (const d of details) await api.call('fs:chmod', d.path, multi ? ((d.mode & 0o7777) & ~mask) | (newMode & mask) : newMode); mode = newMode; updOctal(); reloadDirs([...new Set(details.map((d) => dirname(d.path)))]); } catch (err) { cb.checked = !cb.checked; errorToast(err); }
        };
        boxes.push(cb);
        grid.appendChild(h('label', { class: 'pc' }, cb));
      }
    }
    function updOctal() { octal.textContent = (mode & 0o777).toString(8).padStart(3, '0') + '  ' + permString(mode, e.isDir); if (execToggle) execToggle.checked = !!(mode & 0o100); }
    let execToggle = null;
    perm.appendChild(grid);
    if (!multi && !e.isDir) {
      execToggle = h('input', { type: 'checkbox', disabled: !canEdit ? true : null });
      execToggle.onchange = async () => {
        const newMode = execToggle.checked ? mode | 0o111 & (mode >> 2 | 0o100) | 0o100 : mode & ~0o111;
        try { await api.call('fs:chmod', e.path, newMode); mode = newMode; boxes.forEach((b, i) => { const shift = [6, 6, 6, 3, 3, 3, 0, 0, 0][i]; const bit = [4, 2, 1][i % 3]; b.checked = !!(mode & (bit << shift)); }); updOctal(); reloadDirs([dirname(e.path)]); } catch (err) { execToggle.checked = !execToggle.checked; errorToast(err); }
      };
      perm.appendChild(h('label', { class: 'check big' }, execToggle, h('span', {}, h('b', { text: 'Permitir ejecutar como programa' }), h('small', { text: 'Necesario para scripts y AppImage' }))));
    }
    perm.appendChild(h('div', { class: 'octal-row' }, h('span', { class: 'dim', text: 'Modo:' }), octal));
    if (!canEdit) perm.appendChild(h('p', { class: 'dlg-hint', text: 'Solo el propietario puede cambiar los permisos.' }));
    updOctal();
    addTab('perms', 'Permisos', perm);
  }
  $$('.tseg', tabs)[0].classList.add('on');
  $$('.prop-pane', panes).forEach((x, i) => x.classList.toggle('hidden', i > 0));
  const body = h('div', { class: 'props' }, details.length && $$('.tseg', tabs).length > 1 ? tabs : null, panes);
  const res = await Dialog.open({
    title: multi ? 'Propiedades' : `Propiedades de «${e.name}»`, body, width: 500, className: 'props-dialog',
    buttons: [{ spacer: true }, { label: 'Cerrar', primary: true, value: 'ok' }],
    onOpen: (ctx) => {
      $$('[data-go]', ctx.dialog).forEach((a) => { a.onclick = () => { ctx.close(null); navigate(pane(), a.dataset.go, { select: multi ? paths : [e.path] }); }; });
      if (nameInput) setTimeout(() => { $('.btn.primary', ctx.dialog).focus(); }, 50);
    },
  });
  jobsRunning.forEach((j) => j.cancel());
  if (nameInput && res !== undefined) {
    const v = nameInput.value.trim();
    if (v && v !== e.name) {
      const p = allPanes().find((pp) => pp.path === dirname(e.path)) || pane();
      doRename(p, e, v);
    }
  }
}

/* ---------- abrir con ---------- */
async function openWithSubmenu(sel) {
  let r;
  try { r = await api.call('open:apps', sel[0].path); } catch (e) { return [{ label: 'Error: ' + e.message, disabled: true }]; }
  const items = r.apps.slice(0, 10).map((a) => ({
    label: a.name + (a.id === r.defaultId ? '  (predeterminada)' : ''),
    iconHtml: a.iconData ? `<img class="app-ic" src="${a.iconData}">` : ic('external'),
    action: () => launchWith(a.id, sel),
  }));
  if (!items.length) items.push({ label: 'No hay aplicaciones sugeridas', disabled: true });
  items.push('-', { label: 'Otra aplicación…', icon: 'more', action: () => openWithDialog(sel) });
  return items;
}
async function launchWith(id, sel) {
  try { const r = await api.call('open:with', id, sel.map((e) => e.path)); if (r && r.ok === false) toast(r.error, { type: 'error' }); } catch (e) { errorToast(e); }
}
async function openWithDialog(sel) {
  let r;
  try { r = await api.call('open:apps', sel[0].path); } catch (e) { errorToast(e); return; }
  let chosen = r.apps.length ? (r.apps.find((a) => a.id === r.defaultId) || r.apps[0]).id : null;
  const list = h('div', { class: 'app-list' });
  const filter = h('input', { class: 'input', placeholder: 'Buscar aplicación…', spellcheck: 'false' });
  const showAll = h('input', { type: 'checkbox' });
  const setDef = h('input', { type: 'checkbox' });
  let mode = r.apps.length ? 'rec' : 'all';
  showAll.checked = mode === 'all';
  const iconLoad = new IntersectionObserver((entries) => {
    for (const en of entries) {
      if (!en.isIntersecting) continue;
      const el = en.target; iconLoad.unobserve(el);
      api.call('open:appIcon', el.dataset.id).then((d) => { if (d) el.innerHTML = `<img src="${d}">`; }).catch(() => {});
    }
  }, { root: list });
  function render() {
    const q = normalize(filter.value);
    const src = mode === 'all' ? r.all : r.apps;
    list.innerHTML = '';
    const items = src.filter((a) => !q || normalize(a.name).includes(q) || normalize(a.comment || '').includes(q));
    if (!items.length) list.appendChild(h('div', { class: 'sb-hint', text: 'No hay aplicaciones' }));
    for (const a of items) {
      const icEl = h('span', { class: 'app-ic-box', 'data-id': a.id, html: a.iconData ? `<img src="${a.iconData}">` : ic('window') });
      const el = h('div', { class: `app-row${a.id === chosen ? ' on' : ''}`, onclick: () => { chosen = a.id; $$('.app-row', list).forEach((x) => x.classList.toggle('on', x === el)); }, ondblclick: () => { chosen = a.id; ctxRef.close('open'); } },
        icEl, h('div', { class: 'app-txt' }, h('div', { text: a.name + (a.id === r.defaultId ? ' · predeterminada' : '') }), a.comment ? h('small', { text: a.comment }) : null));
      list.appendChild(el);
      if (!a.iconData) iconLoad.observe(icEl);
    }
  }
  let ctxRef = null;
  filter.addEventListener('input', render);
  showAll.onchange = () => { mode = showAll.checked ? 'all' : 'rec'; render(); };
  const body = h('div', { class: 'openwith' },
    h('p', { class: 'dlg-hint', text: `Tipo: ${r.mime}` }), filter, list,
    h('label', { class: 'check' }, showAll, h('span', { text: 'Mostrar todas las aplicaciones' })),
    h('label', { class: 'check' }, setDef, h('span', { text: `Usar siempre para los archivos de este tipo` })));
  render();
  const res = await Dialog.open({ title: sel.length === 1 ? `Abrir «${sel[0].name}» con…` : `Abrir ${sel.length} archivos con…`, body, width: 520, buttons: [{ spacer: true }, { label: 'Cancelar', value: null }, { label: 'Abrir', primary: true, value: 'open' }], onOpen: (ctx) => { ctxRef = ctx; } });
  iconLoad.disconnect();
  if (res !== 'open' || !chosen) return;
  if (setDef.checked) { try { await api.call('open:setDefault', chosen, r.mime); } catch (e) { errorToast(e); } }
  launchWith(chosen, sel);
}

/* ---------- renombrado en lote ---------- */
async function batchRenameDialog(sel) {
  let mode = 'replace';
  const find = h('input', { class: 'input', placeholder: 'Texto a buscar', spellcheck: 'false' });
  const repl = h('input', { class: 'input', placeholder: 'Reemplazar por', spellcheck: 'false' });
  const cs = h('input', { type: 'checkbox' });
  const tpl = h('input', { class: 'input', value: '{nombre}', spellcheck: 'false' });
  const start = h('input', { class: 'input', type: 'number', value: '1', min: '0', style: { width: '90px' } });
  const pad = h('input', { class: 'input', type: 'number', value: '2', min: '1', max: '6', style: { width: '90px' } });
  let caseMode = 'lower';
  const preview = h('div', { class: 'br-preview' });
  const seg = h('div', { class: 'segmented small' });
  const panels = {};
  const caseSeg = h('div', { class: 'segmented small' }, ...[['lower', 'minúsculas'], ['upper', 'MAYÚSCULAS'], ['title', 'Tipo Título'], ['sentence', 'Tipo oración']].map(([v, l]) => h('button', { class: `seg${v === caseMode ? ' on' : ''}`, onclick: (ev) => { caseMode = v; $$('.seg', caseSeg).forEach((b) => b.classList.toggle('on', b === ev.currentTarget)); update(); } }, h('b', { text: l }))));
  panels.replace = h('div', { class: 'br-panel' }, h('div', { class: 'field-row' }, find, repl), h('label', { class: 'check' }, cs, h('span', { text: 'Distinguir mayúsculas' })));
  panels.template = h('div', { class: 'br-panel hidden' }, h('div', { class: 'field' }, h('label', { text: 'Plantilla — usa {nombre}, {n}, {ext}, {fecha}' }), tpl), h('div', { class: 'field-row' }, h('div', { class: 'field' }, h('label', { text: 'Empezar en' }), start), h('div', { class: 'field' }, h('label', { text: 'Dígitos' }), pad)));
  panels.case = h('div', { class: 'br-panel hidden' }, caseSeg, h('p', { class: 'dlg-hint', text: 'La extensión se mantiene en minúsculas.' }));
  for (const [v, l] of [['replace', 'Buscar y reemplazar'], ['template', 'Plantilla numerada'], ['case', 'Mayúsculas/minúsculas']]) {
    seg.appendChild(h('button', { class: `seg${v === mode ? ' on' : ''}`, onclick: (ev) => { mode = v; $$('.seg', seg).forEach((b) => b.classList.toggle('on', b === ev.currentTarget)); Object.entries(panels).forEach(([k, el]) => el.classList.toggle('hidden', k !== v)); update(); } }, h('b', { text: l })));
  }
  const sorted = sel.slice().sort((a, b) => collator.compare(a.name, b.name));
  const DF = new Intl.DateTimeFormat('sv-SE');
  function compute() {
    const out = [];
    sorted.forEach((e, i) => {
      const dot = e.isDir ? -1 : e.name.lastIndexOf('.');
      const base = dot > 0 ? e.name.slice(0, dot) : e.name;
      const ext = dot > 0 ? e.name.slice(dot) : '';
      let nn = e.name;
      if (mode === 'replace' && find.value) {
        const re = new RegExp(find.value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), cs.checked ? 'g' : 'gi');
        nn = base.replace(re, repl.value) + ext;
      } else if (mode === 'template') {
        const n = String(Number(start.value || 1) + i).padStart(Number(pad.value || 1), '0');
        nn = tpl.value.replace(/\{nombre\}/g, base).replace(/\{n\}/g, n).replace(/\{ext\}/g, ext.replace('.', '')).replace(/\{fecha\}/g, DF.format(new Date(e.mtime)));
        if (!/\{ext\}/.test(tpl.value)) nn += ext;
      } else if (mode === 'case') {
        let b = base;
        if (caseMode === 'lower') b = b.toLocaleLowerCase('es');
        else if (caseMode === 'upper') b = b.toLocaleUpperCase('es');
        else if (caseMode === 'title') b = b.toLocaleLowerCase('es').replace(/(^|[\s_\-.])(\p{L})/gu, (m, s, c) => s + c.toLocaleUpperCase('es'));
        else b = b.charAt(0).toLocaleUpperCase('es') + b.slice(1).toLocaleLowerCase('es');
        nn = b + ext.toLowerCase();
      }
      out.push({ e, newName: nn.trim() });
    });
    const names = new Map();
    for (const o of out) names.set(o.newName, (names.get(o.newName) || 0) + 1);
    const others = new Set(pane().entries.filter((x) => !sel.some((s) => s.path === x.path)).map((x) => x.name));
    for (const o of out) o.conflict = !o.newName || o.newName.includes('/') || names.get(o.newName) > 1 || others.has(o.newName);
    return out;
  }
  let ctxRef = null;
  function update() {
    const out = compute();
    preview.innerHTML = '';
    out.slice(0, 200).forEach((o) => preview.appendChild(h('div', { class: `br-row${o.conflict ? ' bad' : o.newName !== o.e.name ? ' changed' : ''}` }, h('span', { text: o.e.name }), h('span', { class: 'arrow', html: ic('forward') }), h('span', { text: o.newName || '(vacío)' }))));
    const bad = out.filter((o) => o.conflict).length;
    const changed = out.filter((o) => o.newName !== o.e.name && !o.conflict).length;
    if (ctxRef) { ctxRef.buttons.apply.disabled = !!bad || !changed; ctxRef.buttons.apply.textContent = bad ? `${bad} conflictos` : `Renombrar ${changed}`; }
  }
  [find, repl, tpl, start, pad].forEach((x) => x.addEventListener('input', update));
  cs.addEventListener('change', update);
  const body = h('div', { class: 'batch' }, seg, panels.replace, panels.template, panels.case, h('div', { class: 'br-label', text: 'Vista previa' }), preview);
  const res = await Dialog.open({ title: `Renombrar ${sel.length} elementos`, icon: ic('rename'), body, width: 620, buttons: [{ spacer: true }, { label: 'Cancelar', value: null }, { label: 'Renombrar', primary: true, id: 'apply', value: 'apply' }], onOpen: (ctx) => { ctxRef = ctx; update(); setTimeout(() => find.focus(), 50); } });
  if (res !== 'apply') return;
  const out = compute().filter((o) => o.newName !== o.e.name && !o.conflict);
  const done = [];
  // dos pasos para evitar colisiones entre los propios elementos
  const tmp = [];
  try {
    for (const o of out) { const t = await api.call('fs:rename', o.e.path, `.cajon-ren-${S.nextId++}-${o.e.name}`); tmp.push({ t, o }); }
    for (const { t, o } of tmp) { const d = await api.call('fs:rename', t, o.newName); done.push({ path: d, oldName: o.e.name }); }
  } catch (e) { errorToast(e, 'Error al renombrar'); }
  if (done.length) pushUndo({ type: 'renames', list: done }, `${done.length} elementos renombrados`);
  const p = pane();
  await reload(p, { keep: false });
  p.sel = new Set(done.map((d) => d.path)); refreshSelectionClasses(p);
}

/* ---------- preferencias ---------- */
function toggleRow(label, hint, key, onChange) {
  const cb = h('input', { type: 'checkbox', class: 'switch' });
  cb.checked = !!S.config[key];
  cb.onchange = () => { setConfig({ [key]: cb.checked }); if (onChange) onChange(cb.checked); };
  return h('label', { class: 'set-row' }, h('div', { class: 'set-txt' }, h('div', { text: label }), hint ? h('small', { text: hint }) : null), cb);
}
function rerenderAll() { allPanes().forEach((p) => { computeVisible(p); if (p.el) renderPane(p, { keepScroll: true }); }); }
function showSettings() {
  const accents = ['#3b82f6', '#22a861', '#8b5cf6', '#ef4444', '#f59e0b', '#ec4899', '#14b8a6', '#64748b'];
  const accRow = h('div', { class: 'swatches' }, ...accents.map((c) => h('button', { class: `swatch${S.config.accent === c ? ' on' : ''}`, style: { background: c }, title: c, onclick: (ev) => { setConfig({ accent: c }); applyTheme(); $$('.swatch', accRow).forEach((b) => b.classList.toggle('on', b === ev.currentTarget)); } })));
  const themeSeg = h('div', { class: 'segmented small' }, ...[['system', 'Sistema'], ['light', 'Claro'], ['dark', 'Oscuro']].map(([v, l]) => h('button', { class: `seg${S.config.theme === v ? ' on' : ''}`, onclick: (ev) => { setConfig({ theme: v }); applyTheme(); $$('.seg', themeSeg).forEach((b) => b.classList.toggle('on', b === ev.currentTarget)); } }, h('b', { text: l }))));
  const viewSeg = h('div', { class: 'segmented small wrap' }, ...VIEWS.map((x) => [x.id, x.label]).map(([v, l]) => h('button', { class: `seg${S.config.view === v ? ' on' : ''}`, onclick: (ev) => { setConfig({ view: v }); $$('.seg', viewSeg).forEach((b) => b.classList.toggle('on', b === ev.currentTarget)); } }, h('b', { text: l }))));
  const body = h('div', { class: 'settings' },
    h('div', { class: 'set-group' }, h('div', { class: 'set-title', text: 'Apariencia' }),
      h('div', { class: 'set-row' }, h('div', { class: 'set-txt' }, h('div', { text: 'Tema' })), themeSeg),
      h('div', { class: 'set-row' }, h('div', { class: 'set-txt' }, h('div', { text: 'Color de acento' })), accRow),
      toggleRow('Barra de título del sistema', 'Usa los bordes de ventana de Cinnamon (requiere reiniciar Cajón)', 'nativeFrame'),
      toggleRow('Miniaturas', 'Imágenes, vídeos y PDF', 'thumbnails', rerenderAll),
      toggleRow('Mostrar extensiones', null, 'showExtensions', rerenderAll)),
    h('div', { class: 'set-group' }, h('div', { class: 'set-title', text: 'Comportamiento' }),
      h('div', { class: 'set-row' }, h('div', { class: 'set-txt' }, h('div', { text: 'Vista para carpetas nuevas' })), viewSeg),
      toggleRow('Recordar la vista de cada carpeta', 'Cada carpeta guarda su vista, orden y agrupación', 'rememberViews'),
      toggleRow('Abrir con un solo clic', null, 'singleClick'),
      toggleRow('Carpetas primero', null, 'foldersFirst', rerenderAll),
      toggleRow('Mostrar archivos ocultos', null, 'showHidden', rerenderAll),
      toggleRow('Confirmar antes de enviar a la papelera', null, 'confirmTrash'),
      toggleRow('Restaurar pestañas al iniciar', null, 'restoreSession')),
    h('div', { class: 'set-group' }, h('div', { class: 'set-title', text: 'Mantenimiento' }),
      h('div', { class: 'set-row' }, h('div', { class: 'set-txt' }, h('div', { text: 'Caché de miniaturas' }), h('small', { text: 'Libera espacio y regenera las miniaturas' })),
        h('button', { class: 'btn small', text: 'Borrar caché', onclick: async () => { await api.call('thumbs:clear'); toast('Caché de miniaturas borrada', { icon: 'check' }); rerenderAll(); } }))));
  Dialog.open({ title: 'Preferencias', icon: ic('settings'), body, width: 560, buttons: [{ spacer: true }, { label: 'Cerrar', primary: true, value: true }] });
}

function showShortcuts() {
  const groups = [
    ['Navegación', [['Alt+←  /  Alt+→', 'Atrás / Adelante'], ['Alt+↑  /  Retroceso', 'Carpeta superior'], ['Alt+Inicio', 'Carpeta personal'], ['Ctrl+L', 'Escribir una ruta'], ['Ctrl+F', 'Buscar (Intro: en subcarpetas)'], ['F5  /  Ctrl+R', 'Actualizar']]],
    ['Pestañas y paneles', [['Ctrl+T', 'Nueva pestaña'], ['Ctrl+W', 'Cerrar pestaña'], ['Ctrl+Tab', 'Pestaña siguiente'], ['Alt+1…9', 'Ir a la pestaña'], ['F3', 'Vista dividida'], ['F5 / F6', 'Copiar / mover al otro panel'], ['F9', 'Panel lateral'], ['Alt+P', 'Panel de vista previa'], ['Ctrl+N', 'Nueva ventana']]],
    ['Archivos', [['Intro', 'Abrir'], ['Espacio', 'Vista rápida'], ['F2', 'Renombrar (lote si hay varios)'], ['Ctrl+C / X / V', 'Copiar / cortar / pegar'], ['Supr', 'Mover a la papelera'], ['Mayús+Supr', 'Eliminar definitivamente'], ['Ctrl+Z', 'Deshacer'], ['Ctrl+Mayús+N', 'Nueva carpeta'], ['Alt+Intro', 'Propiedades'], ['Ctrl+Mayús+C', 'Copiar ruta'], ['Ctrl+P', 'Imprimir'], ['Ctrl+Alt+C', 'Copiar imagen']]],
    ['Selección y vista', [['Ctrl+A', 'Seleccionar todo'], ['Ctrl+Mayús+I', 'Invertir selección'], ['Ctrl+1 / Ctrl+2 / Ctrl+3', 'Cuadrícula / lista / mosaico'], ['Ctrl+4 / Ctrl+5 / Ctrl+6', 'Compacta / columnas / galería'], ['Ctrl + / Ctrl −', 'Ampliar / reducir'], ['Ctrl+H', 'Archivos ocultos'], ['Ctrl+D', 'Añadir a marcadores'], ['F4', 'Abrir terminal aquí'], ['Ctrl+,', 'Preferencias']]],
  ];
  const body = h('div', { class: 'shortcuts' }, ...groups.map(([title, list]) => h('div', { class: 'sc-group' }, h('div', { class: 'set-title', text: title }),
    ...list.map(([k, d]) => h('div', { class: 'sc-row' }, h('span', { text: d }), h('span', { class: 'keys' }, ...k.split(/\s+\/\s+|\s{2}\/\s{2}/).map((x, i) => [i ? h('span', { class: 'dim', text: ' / ' }) : null, h('kbd', { text: x })])))))));
  Dialog.open({ title: 'Atajos de teclado', icon: ic('keyboard'), body, width: 760, buttons: [{ spacer: true }, { label: 'Cerrar', primary: true, value: true }] });
}

function showAbout() {
  const body = h('div', { class: 'about' }, h('div', { class: 'about-ic', html: '<img src="assets/cajon.png" alt="">' }), h('div', { class: 'about-name', text: 'Cajón' }), h('div', { class: 'dim', text: 'Versión 1.5.0' }),
    h('p', { text: 'Gestor de archivos moderno para Linux Mint, con pestañas, vista dividida, vista previa, miniaturas, papelera, unidades y compresión.' }));
  Dialog.open({ title: 'Acerca de Cajón', body, width: 400, buttons: [{ spacer: true }, { label: 'Cerrar', primary: true, value: true }] });
}

/* ---------- imprimir ---------- */
const PRINT_OFFICE = ['doc', 'docx', 'odt', 'rtf', 'xls', 'xlsx', 'xlsm', 'ods', 'ppt', 'pptx', 'odp', 'odg', 'wpd'];
const PRINT_NO = ['psd', 'xcf', 'raw', 'cr2', 'nef', 'arw', 'dng'];
function printKind(e) {
  if (!e || e.isDir || e.broken) return null;
  const x = FT.ext(e.name);
  const k = FT.kind(e);
  if (x === 'pdf' || x === 'ps' || x === 'eps') return 'pdf';
  if (PRINT_OFFICE.includes(x)) return 'office';
  if (k === 'image' && !PRINT_NO.includes(x)) return 'image';
  if (k === 'text' || k === 'code' || x === 'csv' || x === 'tsv') return 'text';
  return null;
}
function isPrintable(e) { return !!printKind(e); }

async function printDialog(entries) {
  const files = entries.filter(isPrintable);
  const skipped = entries.length - files.length;
  if (!files.length) { toast('Ninguno de los elementos seleccionados se puede imprimir', { type: 'error' }); return; }
  let info;
  try { info = await api.call('print:printers'); } catch (e) { errorToast(e); return; }
  if (!info.available || !info.printers.length) {
    const r = await Dialog.open({
      title: 'No hay impresoras', icon: ic('printer'), width: 460,
      body: h('p', { class: 'dlg-text', text: info.available ? 'No hay ninguna impresora configurada en este equipo. Añade una desde la configuración de impresoras de Linux Mint y vuelve a intentarlo.' : 'El sistema de impresión (CUPS) no está instalado. Instálalo con «sudo apt install cups» y añade una impresora.' }),
      buttons: [{ spacer: true }, { label: 'Cerrar', value: null }, { label: 'Configurar impresoras', primary: true, value: 'cfg' }],
    });
    if (r === 'cfg') { const s = await api.call('print:settings').catch((e) => ({ ok: false, error: e.message })); if (!s.ok) toast(s.error, { type: 'error' }); }
    return;
  }
  const saved = Object.assign({ copies: 1, sides: 'one-sided', orientation: 'portrait', mono: false, media: 'A4', fit: true, perSheet: 1, collate: true }, S.config.printOpts || {});
  const o = Object.assign({}, saved, { copies: 1, pages: '' });
  if (!info.printers.some((x) => x.name === o.printer)) o.printer = info.defaultName || info.printers[0].name;
  const anyImage = files.some((f) => printKind(f) === 'image');

  // lista de archivos
  const list = h('div', { class: 'pr-files' }, ...files.slice(0, 50).map((f) => {
    const k = printKind(f);
    const note = k === 'office' ? 'Se convertirá a PDF con LibreOffice' : k === 'text' && FT.ext(f.name) !== 'txt' ? 'Se imprimirá como texto' : '';
    return h('div', { class: 'pr-file' }, h('span', { class: 'pr-ic', html: bigIcon(f) }), h('div', { class: 'pr-ftxt' }, h('div', { class: 'pr-fname', text: f.name }), h('small', { text: [FT.typeName(f), fmtSize(f.size), note].filter(Boolean).join(' · ') })));
  }));
  if (files.length > 50) list.appendChild(h('div', { class: 'sb-hint', text: `y ${files.length - 50} más…` }));

  // impresora
  const sel = h('select', { class: 'input' }, ...info.printers.map((pr) => h('option', { value: pr.name, selected: pr.name === o.printer ? true : null, text: `${pr.description || pr.name}${pr.isDefault ? '  (predeterminada)' : ''}` })));
  const state = h('div', { class: 'pr-state' });
  const showState = () => {
    const pr = info.printers.find((x) => x.name === sel.value);
    const st = pr ? pr.state : 'idle';
    const txt = { idle: 'Preparada', processing: 'Imprimiendo otros trabajos', printing: 'Imprimiendo otros trabajos', stopped: 'Detenida', disabled: 'Desactivada' }[st] || st;
    state.className = `pr-state ${st === 'idle' ? 'ok' : st === 'stopped' || st === 'disabled' ? 'bad' : 'busy'}`;
    state.textContent = txt + (pr && pr.location ? ` · ${pr.location}` : '');
  };
  sel.onchange = () => { o.printer = sel.value; showState(); };
  showState();

  // opciones
  const copies = h('input', { class: 'input', type: 'number', min: '1', max: '999', value: String(o.copies) });
  copies.oninput = () => { o.copies = Math.max(1, Math.min(999, Number(copies.value) || 1)); collateRow.classList.toggle('hidden', o.copies < 2); };
  const collate = h('input', { type: 'checkbox' }); collate.checked = o.collate !== false; collate.onchange = () => { o.collate = collate.checked; };
  const collateRow = h('label', { class: 'check hidden' }, collate, h('span', { text: 'Intercalar copias' }));
  const pagesIn = h('input', { class: 'input hidden', placeholder: 'Ej.: 1-3, 5, 8', spellcheck: 'false' });
  const pageErr = h('div', { class: 'field-error' });
  let pagesMode = 'all';
  const pagesSeg = h('div', { class: 'segmented small' }, ...[['all', 'Todas'], ['range', 'Páginas…']].map(([v, l]) => h('button', {
    class: `seg${v === pagesMode ? ' on' : ''}`,
    onclick: (ev) => { pagesMode = v; $$('.seg', pagesSeg).forEach((b) => b.classList.toggle('on', b === ev.currentTarget)); pagesIn.classList.toggle('hidden', v === 'all'); if (v === 'range') pagesIn.focus(); },
  }, h('b', { text: l }))));
  const seg = (options, key) => {
    const el = h('div', { class: 'segmented small' });
    options.forEach(([v, l]) => el.appendChild(h('button', { class: `seg${o[key] === v ? ' on' : ''}`, onclick: (ev) => { o[key] = v; $$('.seg', el).forEach((b) => b.classList.toggle('on', b === ev.currentTarget)); } }, h('b', { text: l }))));
    return el;
  };
  const media = h('select', { class: 'input' }, ...[['A4', 'A4'], ['A3', 'A3'], ['A5', 'A5'], ['Letter', 'Carta (EE. UU.)'], ['Legal', 'Legal']].map(([v, l]) => h('option', { value: v, selected: o.media === v ? true : null, text: l })));
  media.onchange = () => { o.media = media.value; };
  const perSheet = h('select', { class: 'input' }, ...[1, 2, 4, 6, 9].map((n) => h('option', { value: String(n), selected: o.perSheet === n ? true : null, text: n === 1 ? '1 por hoja' : `${n} por hoja` })));
  perSheet.onchange = () => { o.perSheet = Number(perSheet.value); };
  const fit = h('input', { type: 'checkbox' }); fit.checked = !!o.fit; fit.onchange = () => { o.fit = fit.checked; };

  const row = (label, ctl) => h('div', { class: 'pr-row' }, h('label', { class: 'pr-label', text: label }), ctl);
  const body = h('div', { class: 'print' },
    h('div', { class: 'pr-cols' },
      h('div', { class: 'pr-left' },
        h('div', { class: 'br-label', text: files.length === 1 ? 'Archivo' : `${files.length} archivos` }), list,
        skipped ? h('p', { class: 'dlg-hint', text: `${plural(skipped, 'elemento no se puede imprimir y se omitirá', 'elementos no se pueden imprimir y se omitirán')} (carpetas u otros tipos).` }) : null),
      h('div', { class: 'pr-right' },
        row('Impresora', h('div', {}, sel, state)),
        row('Copias', h('div', { class: 'pr-inline' }, copies, collateRow)),
        row('Páginas', h('div', {}, pagesSeg, pagesIn, pageErr)),
        row('Doble cara', seg([['one-sided', 'No'], ['two-sided-long-edge', 'Borde largo'], ['two-sided-short-edge', 'Borde corto']], 'sides')),
        row('Orientación', seg([['portrait', 'Vertical'], ['landscape', 'Horizontal']], 'orientation')),
        row('Color', seg([[false, 'Color'], [true, 'Blanco y negro']], 'mono')),
        row('Papel', h('div', { class: 'pr-inline' }, media, perSheet)),
        anyImage ? h('label', { class: 'check' }, fit, h('span', { text: 'Ajustar las imágenes a la página' })) : null)));
  const res = await Dialog.open({
    title: files.length === 1 ? `Imprimir «${files[0].name}»` : `Imprimir ${files.length} archivos`, icon: ic('printer'), body, width: 820, className: 'print-dialog',
    buttons: [
      { label: 'Impresoras…', ghost: true, onClick: async () => { await api.call('print:settings').catch(() => {}); return false; } },
      { spacer: true }, { label: 'Cancelar', value: null },
      {
        label: 'Imprimir', primary: true,
        onClick: () => {
          if (pagesMode === 'range') {
            const v = pagesIn.value.replace(/\s+/g, '');
            if (!/^\d+(-\d+)?(,\d+(-\d+)?)*$/.test(v)) { pageErr.textContent = 'Escribe páginas como 1-3,5'; pagesIn.focus(); return false; }
            o.pages = v;
          } else o.pages = '';
          return true;
        },
        value: 'print',
      },
    ],
  });
  if (res !== 'print') return;
  const pr = info.printers.find((x) => x.name === o.printer);
  setConfig({ printOpts: { printer: o.printer, sides: o.sides, orientation: o.orientation, mono: o.mono, media: o.media, fit: o.fit, perSheet: o.perSheet, collate: o.collate } });
  try {
    await api.call('job:print', files.map((f) => f.path), Object.assign({}, o, { printerLabel: pr ? pr.description || pr.name : o.printer, sides: o.sides === 'one-sided' ? '' : o.sides, fit: anyImage && o.fit }));
  } catch (e) { errorToast(e); }
}
function printSelected(p) {
  const sel = selected(p || pane());
  if (!sel.length) { toast('Selecciona los archivos que quieras imprimir'); return; }
  printDialog(sel);
}

/* ---------- fondo de pantalla ---------- */
const WALL_EXT = ['jpg', 'jpeg', 'jfif', 'png', 'webp', 'bmp', 'gif', 'svg', 'tif', 'tiff', 'avif'];
function isWallpaperable(e) { return !!e && !e.isDir && !e.broken && WALL_EXT.includes(FT.ext(e.name)); }
const WALL_MODES_UI = [
  ['zoom', 'Rellenar la pantalla', 'Recomendado: cubre todo sin deformar'],
  ['scaled', 'Ajustar', 'Imagen completa, con bandas si no encaja'],
  ['stretched', 'Estirar', 'Deforma la imagen para ocupar todo'],
  ['centered', 'Centrar', 'Tamaño original en el centro'],
  ['wallpaper', 'Mosaico', 'Repetir la imagen'],
  ['spanned', 'Abarcar todas las pantallas', 'Una sola imagen para varios monitores'],
];
function wallpaperMenu(e) {
  return [
    { header: 'Cómo colocarla' },
    ...WALL_MODES_UI.map(([mode, label], i) => ({ label: i === 0 ? `${label}  (recomendado)` : label, icon: i === 0 ? 'wallpaper' : null, iconHtml: i === 0 ? null : '', action: () => setWallpaper(e, mode) })),
    '-',
    { label: 'Configuración de fondos…', icon: 'settings', action: async () => { const r = await api.call('wallpaper:settings').catch((x) => ({ ok: false, error: x.message })); if (!r.ok) toast(r.error, { type: 'error' }); } },
  ];
}
async function setWallpaper(e, mode) {
  try {
    const r = await api.call('wallpaper:set', e.path, mode || 'zoom');
    const prev = r.previous;
    toast(`«${e.name}» es ahora tu fondo de pantalla`, {
      icon: 'wallpaper',
      action: prev && (prev.uri || prev.file) ? { label: 'Deshacer', fn: async () => { try { const u = await api.call('wallpaper:restore', prev); toast(u.ok ? 'Fondo anterior restaurado' : 'No se pudo restaurar el fondo anterior', { icon: 'undo', type: u.ok ? '' : 'error' }); } catch (x) { errorToast(x); } } } : null,
    });
  } catch (x) { errorToast(x, 'No se pudo cambiar el fondo de pantalla'); }
}

/* ---------- copiar imagen ---------- */
const CLIP_IMG_EXT = ['jpg', 'jpeg', 'jfif', 'png', 'webp', 'bmp', 'gif', 'svg', 'ico', 'avif', 'apng'];
function isCopyableImage(e) { return !!e && !e.isDir && !e.broken && CLIP_IMG_EXT.includes(FT.ext(e.name)); }
function decodeWithCanvas(path) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let w = img.naturalWidth; let h = img.naturalHeight;
      if (!w || !h) { w = 1024; h = 1024; }
      // los SVG pequeños se dibujan a buen tamaño para que no salgan borrosos
      if (/\.svgz?$/i.test(path) && Math.max(w, h) < 1600) { const k = 1600 / Math.max(w, h); w = Math.round(w * k); h = Math.round(h * k); }
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      c.getContext('2d').drawImage(img, 0, 0, w, h);
      try { resolve(c.toDataURL('image/png')); } catch (x) { reject(x); }
    };
    img.onerror = () => reject(new Error('no se pudo abrir la imagen'));
    img.src = fileUrl(path) + '?t=' + Date.now();
  });
}
async function copyImage(e) {
  try {
    let r = await api.call('clipboard:image', e.path);
    if (!r.ok && r.unsupported) r = await api.call('clipboard:imageData', await decodeWithCanvas(e.path));
    toast(`Imagen copiada (${r.width} × ${r.height}). Pégala con Ctrl+V en Word, LibreOffice o donde quieras`, { icon: 'copyImage' });
  } catch (x) { errorToast(x, 'No se pudo copiar la imagen'); }
}
