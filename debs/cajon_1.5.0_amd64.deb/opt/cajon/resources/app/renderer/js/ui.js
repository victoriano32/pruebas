'use strict';
/* Utilidades de interfaz: formato, menús, diálogos, avisos */
const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'text') el.textContent = v;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return el;
}

const NF1 = new Intl.NumberFormat('es-ES', { maximumFractionDigits: 1 });
const NF0 = new Intl.NumberFormat('es-ES', { maximumFractionDigits: 0 });
function fmtSize(n) {
  if (n == null || isNaN(n)) return '—';
  if (n < 1000) return `${n} ${n === 1 ? 'byte' : 'bytes'}`;
  const u = ['kB', 'MB', 'GB', 'TB', 'PB'];
  let i = -1;
  do { n /= 1000; i++; } while (n >= 1000 && i < u.length - 1);
  return `${n < 100 ? NF1.format(n) : NF0.format(n)} ${u[i]}`;
}
function fmtNum(n) { return NF0.format(n); }

const DF_TIME = new Intl.DateTimeFormat('es-ES', { hour: '2-digit', minute: '2-digit' });
const DF_DAY = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short' });
const DF_FULL = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', year: 'numeric' });
const DF_LONG = new Intl.DateTimeFormat('es-ES', { dateStyle: 'full', timeStyle: 'short' });
function fmtDate(ms) {
  if (!ms) return '—';
  const d = new Date(ms);
  const now = new Date();
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  if (ms >= startToday) return `Hoy, ${DF_TIME.format(d)}`;
  if (ms >= startToday - 86400000) return `Ayer, ${DF_TIME.format(d)}`;
  if (d.getFullYear() === now.getFullYear()) return `${DF_DAY.format(d)}, ${DF_TIME.format(d)}`;
  return DF_FULL.format(d);
}
function fmtDateLong(ms) { if (!ms) return '—'; const s = DF_LONG.format(new Date(ms)); return s.charAt(0).toUpperCase() + s.slice(1); }
function plural(n, one, many) { return `${fmtNum(n)} ${n === 1 ? one : many}`; }

function normalize(s) { return s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(); }
function fileUrl(p) { return 'file://' + p.split('/').map(encodeURIComponent).join('/'); }
function basename(p) { if (p === '/') return '/'; const s = p.replace(/\/+$/, ''); return s.slice(s.lastIndexOf('/') + 1); }
function dirname(p) { const s = p.replace(/\/+$/, ''); const i = s.lastIndexOf('/'); return i <= 0 ? '/' : s.slice(0, i); }
function joinPath(a, b) { return a === '/' ? '/' + b : a + '/' + b; }
function permString(mode, isDir) {
  const chars = 'rwxrwxrwx';
  let s = isDir ? 'd' : '-';
  for (let i = 0; i < 9; i++) s += (mode & (1 << (8 - i))) ? chars[i] : '-';
  return s;
}

/* ---------- avisos ---------- */
function toast(msg, opts = {}) {
  const host = $('#toasts');
  const el = h('div', { class: `toast ${opts.type || ''}` },
    h('span', { class: 'toast-ic', html: ic(opts.type === 'error' ? 'alert' : opts.icon || 'info') }),
    h('span', { class: 'toast-msg', text: msg }));
  if (opts.action) {
    el.appendChild(h('button', { class: 'btn small ghost', text: opts.action.label, onclick: () => { opts.action.fn(); close(); } }));
  }
  el.appendChild(h('button', { class: 'icon-btn tiny', title: 'Cerrar', html: ic('x'), onclick: () => close() }));
  host.appendChild(el);
  const live = $$('.toast', host);
  if (live.length > 3) live.slice(0, live.length - 3).forEach((t) => t.remove());
  requestAnimationFrame(() => el.classList.add('in'));
  let t = setTimeout(close, opts.timeout || (opts.action ? 7000 : opts.type === 'error' ? 7000 : 3500));
  el.addEventListener('mouseenter', () => clearTimeout(t));
  el.addEventListener('mouseleave', () => { t = setTimeout(close, 2500); });
  function close() { el.classList.remove('in'); setTimeout(() => el.remove(), 220); }
  return close;
}
function errorToast(e, prefix) { toast((prefix ? prefix + ': ' : '') + (e && e.message ? e.message : String(e)), { type: 'error' }); }

/* ---------- menús contextuales ---------- */
const Menu = (() => {
  let stack = [];
  function closeAll() { stack.forEach((m) => m.el.remove()); stack = []; document.removeEventListener('mousedown', outside, true); }
  function closeFrom(level) { while (stack.length > level) stack.pop().el.remove(); }
  function outside(e) { if (!stack.some((m) => m.el.contains(e.target))) closeAll(); }

  async function build(items, level) {
    if (typeof items === 'function') items = await items();
    const el = h('div', { class: 'menu', role: 'menu' });
    const entries = [];
    for (const it of items) {
      if (!it) continue;
      if (it === '-') { if (entries.length && el.lastChild && !el.lastChild.classList.contains('sep')) el.appendChild(h('div', { class: 'sep' })); continue; }
      if (it.header) { el.appendChild(h('div', { class: 'menu-header', text: it.header })); continue; }
      const row = h('div', { class: `menu-item${it.disabled ? ' disabled' : ''}${it.danger ? ' danger' : ''}`, role: 'menuitem' },
        h('span', { class: 'mi-ic', html: it.checked != null ? (it.checked ? ic('check') : '') : it.iconHtml || (it.icon ? ic(it.icon) : '') }),
        h('span', { class: 'mi-label', text: it.label }),
        it.accel ? h('span', { class: 'mi-accel', text: it.accel }) : null,
        it.submenu ? h('span', { class: 'mi-sub', html: ic('chevronRight') }) : null);
      const entry = { row, it };
      entries.push(entry);
      row.addEventListener('mouseenter', () => { setActive(level, entries.indexOf(entry)); if (it.submenu && !it.disabled) openSub(entry, level); else closeFrom(level + 1); });
      row.addEventListener('click', (e) => {
        e.stopPropagation();
        if (it.disabled) return;
        if (it.submenu) { openSub(entry, level); return; }
        closeAll();
        if (it.action) setTimeout(() => it.action(), 0);
      });
      el.appendChild(row);
    }
    if (el.lastChild && el.lastChild.classList.contains('sep')) el.lastChild.remove();
    return { el, entries, active: -1 };
  }
  function setActive(level, idx) {
    const m = stack[level];
    if (!m) return;
    m.entries.forEach((e, i) => e.row.classList.toggle('active', i === idx));
    m.active = idx;
  }
  async function openSub(entry, level) {
    if (stack[level + 1] && stack[level + 1].parent === entry) return;
    closeFrom(level + 1);
    const r = entry.row.getBoundingClientRect();
    const sub = await build(entry.it.submenu, level + 1);
    sub.parent = entry;
    if (stack.length !== level + 1) return;
    place(sub, r.right - 4, r.top - 6, r.left + 4);
    stack.push(sub);
  }
  function place(m, x, y, altX) {
    document.body.appendChild(m.el);
    const w = m.el.offsetWidth; const hgt = m.el.offsetHeight;
    const W = window.innerWidth; const H = window.innerHeight;
    if (x + w > W - 6) x = altX != null ? altX - w : W - w - 6;
    if (y + hgt > H - 6) y = Math.max(6, H - hgt - 6);
    m.el.style.left = Math.max(6, x) + 'px';
    m.el.style.top = Math.max(6, y) + 'px';
    requestAnimationFrame(() => m.el.classList.add('in'));
  }
  async function show(items, x, y) {
    closeAll();
    const m = await build(items, 0);
    if (!m.entries.length) return;
    place(m, x, y);
    stack.push(m);
    setTimeout(() => document.addEventListener('mousedown', outside, true), 0);
  }
  function showAt(items, anchor) {
    const r = anchor.getBoundingClientRect();
    return show(items, r.left, r.bottom + 4);
  }
  function isOpen() { return stack.length > 0; }
  function key(e) {
    if (!stack.length) return false;
    const level = stack.length - 1;
    const m = stack[level];
    const enabled = m.entries.map((en, i) => (en.it.disabled ? -1 : i)).filter((i) => i >= 0);
    if (e.key === 'Escape') { if (level > 0) closeFrom(level); else closeAll(); return true; }
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      if (!enabled.length) return true;
      const pos = enabled.indexOf(m.active);
      const next = e.key === 'ArrowDown' ? enabled[(pos + 1) % enabled.length] : enabled[(pos - 1 + enabled.length) % enabled.length];
      setActive(level, next == null ? enabled[0] : next);
      return true;
    }
    if (e.key === 'ArrowRight') { const en = m.entries[m.active]; if (en && en.it.submenu) openSub(en, level).then(() => { const s = stack[level + 1]; if (s) setActive(level + 1, 0); }); return true; }
    if (e.key === 'ArrowLeft') { if (level > 0) closeFrom(level); return true; }
    if (e.key === 'Enter' || e.key === ' ') { const en = m.entries[m.active]; if (en) en.row.click(); return true; }
    return true;
  }
  return { show, showAt, closeAll, isOpen, key };
})();

/* ---------- diálogos ---------- */
const Dialog = (() => {
  const openDialogs = [];
  function open({ title, body, buttons = [], width, className, onOpen, icon, subtitle }) {
    return new Promise((resolve) => {
      const backdrop = h('div', { class: 'backdrop' });
      const dlg = h('div', { class: `dialog ${className || ''}`, role: 'dialog', style: width ? { width: width + 'px' } : null });
      const head = h('div', { class: 'dlg-head' },
        icon ? h('span', { class: 'dlg-icon', html: icon }) : null,
        h('div', { class: 'dlg-titles' }, h('div', { class: 'dlg-title', text: title || '' }), subtitle ? h('div', { class: 'dlg-sub', text: subtitle }) : null),
        h('button', { class: 'icon-btn', title: 'Cerrar', html: ic('x'), onclick: () => done(null) }));
      const content = h('div', { class: 'dlg-body' });
      if (body) content.appendChild(body);
      const foot = h('div', { class: 'dlg-foot' });
      const ctx = { close: done, dialog: dlg, body: content, buttons: {} };
      for (const b of buttons) {
        if (b.spacer) { foot.appendChild(h('div', { class: 'spacer' })); continue; }
        const btn = h('button', { class: `btn${b.primary ? ' primary' : ''}${b.danger ? ' danger' : ''}${b.ghost ? ' ghost' : ''}`, text: b.label });
        btn.addEventListener('click', async () => {
          if (b.onClick) { const r = await b.onClick(ctx); if (r === false) return; }
          if (b.value !== undefined) done(typeof b.value === 'function' ? b.value(ctx) : b.value);
        });
        if (b.id) ctx.buttons[b.id] = btn;
        foot.appendChild(btn);
      }
      dlg.append(head, content);
      if (buttons.length) dlg.appendChild(foot);
      backdrop.appendChild(dlg);
      document.body.appendChild(backdrop);
      const record = { done, buttons, ctx, dlg };
      openDialogs.push(record);
      requestAnimationFrame(() => backdrop.classList.add('in'));
      backdrop.addEventListener('mousedown', (e) => { if (e.target === backdrop) done(null); });
      function done(v) {
        const i = openDialogs.indexOf(record);
        if (i < 0) return;
        openDialogs.splice(i, 1);
        backdrop.classList.remove('in');
        setTimeout(() => backdrop.remove(), 160);
        resolve(v);
      }
      if (onOpen) onOpen(ctx);
      setTimeout(() => {
        if (dlg.contains(document.activeElement)) return;
        const f = dlg.querySelector('[autofocus], input, textarea, select') || dlg.querySelector('.btn.primary');
        if (f) { f.focus(); }
      }, 30);
    });
  }
  function isOpen() { return openDialogs.length > 0; }
  function key(e) {
    const d = openDialogs[openDialogs.length - 1];
    if (!d) return false;
    if (e.key === 'Escape') { d.done(null); return true; }
    if (e.key === 'Enter' && !e.shiftKey && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'BUTTON') {
      const primaryIdx = d.buttons.findIndex((b) => b.primary);
      if (primaryIdx >= 0) {
        const btns = $$('.dlg-foot .btn', d.dlg);
        const visible = d.buttons.filter((b) => !b.spacer);
        const btn = btns[visible.indexOf(d.buttons[primaryIdx])];
        if (btn && !btn.disabled) { e.preventDefault(); btn.click(); return true; }
      }
    }
    return false;
  }
  return { open, isOpen, key };
})();

async function promptDialog(title, { label, value = '', selectBase = false, okLabel = 'Aceptar', validate, subtitle } = {}) {
  const input = h('input', { class: 'input', type: 'text', value, spellcheck: 'false' });
  const err = h('div', { class: 'field-error' });
  const body = h('div', { class: 'field' }, label ? h('label', { text: label }) : null, input, err);
  return Dialog.open({
    title, subtitle, body, width: 440,
    buttons: [{ spacer: true }, { label: 'Cancelar', value: null }, {
      label: okLabel, primary: true,
      onClick: () => {
        const v = input.value.trim();
        const msg = validate ? validate(v) : (!v ? 'Escribe un nombre' : null);
        if (msg) { err.textContent = msg; input.focus(); return false; }
        return true;
      },
      value: () => input.value.trim(),
    }],
    onOpen: () => setTimeout(() => {
      input.focus();
      if (selectBase) { const dot = value.lastIndexOf('.'); input.setSelectionRange(0, dot > 0 ? dot : value.length); } else input.select();
    }, 40),
  });
}

function confirmDialog(title, message, { okLabel = 'Aceptar', danger = false, icon } = {}) {
  return Dialog.open({
    title, width: 440, icon: icon ? ic(icon) : null,
    body: h('p', { class: 'dlg-text', text: message }),
    buttons: [{ spacer: true }, { label: 'Cancelar', value: false }, { label: okLabel, primary: !danger, danger, value: true }],
    onOpen: (ctx) => setTimeout(() => { const b = ctx.dialog.querySelector('.btn.primary, .btn.danger'); if (b) b.focus(); }, 40),
  }).then((v) => !!v);
}

/* ---------- panel emergente ---------- */
const Popover = (() => {
  let cur = null;
  function outside(e) { if (cur && !cur.el.contains(e.target) && !cur.anchor.contains(e.target) && !e.target.closest('.menu')) close(); }
  function close() {
    if (!cur) return;
    const c = cur; cur = null;
    if (c.el.contains(document.activeElement)) document.activeElement.blur();
    c.el.classList.remove('in');
    setTimeout(() => c.el.remove(), 120);
    document.removeEventListener('mousedown', outside, true);
    c.anchor.classList.remove('open');
    if (c.onClose) c.onClose();
  }
  function place() {
    if (!cur) return;
    const r = cur.anchor.getBoundingClientRect();
    const w = cur.el.offsetWidth;
    const x = Math.max(6, Math.min(window.innerWidth - w - 6, r.right - w));
    cur.el.style.left = x + 'px';
    cur.el.style.top = (r.bottom + 6) + 'px';
    cur.el.style.maxHeight = (window.innerHeight - r.bottom - 16) + 'px';
  }
  function show(content, anchor, opts = {}) {
    if (cur && cur.anchor === anchor) { close(); return; }
    close();
    const el = h('div', { class: `popover ${opts.className || ''}` }, content);
    document.body.appendChild(el);
    cur = { el, anchor, onClose: opts.onClose };
    anchor.classList.add('open');
    place();
    requestAnimationFrame(() => el.classList.add('in'));
    setTimeout(() => document.addEventListener('mousedown', outside, true), 0);
  }
  function refresh(content) {
    if (!cur) return;
    const st = cur.el.scrollTop;
    cur.el.innerHTML = '';
    cur.el.appendChild(content);
    cur.el.scrollTop = st;
    place();
  }
  return { show, close, refresh, isOpen: () => !!cur };
})();
