'use strict';
/* Cajón — modos de vista, columnas de lista, agrupación, vista de columnas, galería y panel de opciones */

const VIEWS = [
  { id: 'grid', label: 'Cuadrícula', icon: 'grid', key: '1' },
  { id: 'list', label: 'Lista', icon: 'list', key: '2' },
  { id: 'tiles', label: 'Mosaico', icon: 'tiles', key: '3' },
  { id: 'compact', label: 'Compacta', icon: 'compact', key: '4' },
  { id: 'columns', label: 'Columnas', icon: 'columns', key: '5' },
  { id: 'gallery', label: 'Galería', icon: 'gallery', key: '6' },
];
const VIEW_IDS = VIEWS.map((v) => v.id);
const TILE_SIZES = [{ icon: 32, w: 210 }, { icon: 40, w: 240 }, { icon: 52, w: 280 }, { icon: 68, w: 330 }, { icon: 88, w: 380 }, { icon: 112, w: 440 }];
const COMPACT_SIZES = [{ row: 22, icon: 14, w: 180 }, { row: 26, icon: 16, w: 210 }, { row: 30, icon: 20, w: 250 }, { row: 38, icon: 28, w: 290 }, { row: 46, icon: 34, w: 330 }];
const GALLERY_SIZES = [48, 64, 88, 120, 160, 200];

function zoomSpec(view) {
  if (view === 'grid') return { key: 'zoom', max: GRID_SIZES.length - 1, def: 4 };
  if (view === 'tiles') return { key: 'tileZoom', max: TILE_SIZES.length - 1, def: 2 };
  if (view === 'gallery') return { key: 'galleryZoom', max: GALLERY_SIZES.length - 1, def: 2 };
  if (view === 'compact') return { key: 'compactZoom', max: COMPACT_SIZES.length - 1, def: 2 };
  return { key: 'listZoom', max: LIST_SIZES.length - 1, def: 2 };
}
function zoomVal(view) {
  const z = zoomSpec(view);
  const v = S.config[z.key];
  return v == null || isNaN(v) ? z.def : Math.max(0, Math.min(z.max, v));
}

/* ---------- columnas de la vista de lista ---------- */
function ownerName(uid) { return (S.users && S.users[uid]) || String(uid == null ? '—' : uid); }
function dateOf(p, e) {
  if (p.path === TRASH && !p.search) return e.deletedAt;
  if (p.path === RECENT && !p.search) return e.recentTime || e.mtime;
  return e.mtime;
}
const COLS = {
  size: { label: 'Tamaño', w: 110, align: 'right', sort: 'size', html: (e) => sizeText(e) },
  type: { label: 'Tipo', w: 170, sort: 'type', html: (e) => esc(FT.typeName(e)) },
  ext: { label: 'Extensión', w: 90, sort: 'ext', html: (e) => (e.isDir ? '—' : esc(FT.ext(e.name) || '—')) },
  mtime: { label: 'Modificado', w: 150, sort: 'mtime', html: (e) => fmtDate(e.mtime) },
  btime: { label: 'Creado', w: 150, sort: 'btime', html: (e) => fmtDate(e.btime) },
  atime: { label: 'Último acceso', w: 150, sort: 'atime', html: (e) => fmtDate(e.atime) },
  perms: { label: 'Permisos', w: 112, sort: 'perms', html: (e) => `<code>${permString(e.mode || 0, e.isDir)}</code>` },
  owner: { label: 'Propietario', w: 110, sort: 'owner', html: (e) => esc(ownerName(e.uid)) },
  location: {
    label: 'Ubicación', w: 230, sort: 'location',
    html: (e) => { const d = e.origPath ? dirname(e.origPath) : dirname(e.path); return `<span title="${esc(d)}">${esc(prettyDir(d))}</span>`; },
  },
  deleted: { label: 'Eliminado', w: 150, sort: 'deleted', html: (e) => fmtDate(e.deletedAt) },
  used: { label: 'Usado', w: 150, sort: 'recent', html: (e) => fmtDate(e.recentTime || e.mtime) },
};
const OPTIONAL_COLS = ['size', 'type', 'ext', 'mtime', 'btime', 'atime', 'perms', 'owner'];
function columnsFor(p) {
  if (p.path === TRASH && !p.search) return ['location', 'size', 'deleted'];
  const chosen = S.config.listCols && S.config.listCols.length ? S.config.listCols : ['size', 'type', 'mtime'];
  const ordered = OPTIONAL_COLS.filter((c) => chosen.includes(c));
  if (p.search || p.path === RECENT) return ['location', ...ordered.map((c) => (c === 'mtime' && p.path === RECENT && !p.search ? 'used' : c))];
  return ordered;
}
function colTemplate(cols) {
  const W = S.config.colWidths || {};
  return ['minmax(180px, 1fr)', ...cols.map((c) => (W[c] || COLS[c].w) + 'px')].join(' ');
}
function renderListHeader(p) {
  const cols = columnsFor(p);
  const all = ['name', ...cols];
  p.headerEl.innerHTML = all.map((c, idx) => {
    const def = c === 'name' ? { label: 'Nombre', sort: 'name' } : COLS[c];
    const recentDefault = p.path === RECENT && p.sort.recentDefault !== false;
    const active = !recentDefault ? p.sort.key === def.sort : c === 'used';
    return `<div class="c c-${c}${def.align === 'right' ? ' r' : ''} sortable${active ? ' active' : ''}" data-sort="${def.sort}" data-col="${c}">` +
      `${idx > 0 ? `<span class="col-resize" data-col="${c}" title="Arrastra para cambiar el ancho"></span>` : ''}` +
      `<span class="hlabel">${esc(def.label)}</span>${active ? `<span class="sort-dir">${ic(p.sort.dir > 0 ? 'chevronDown' : 'up')}</span>` : ''}</div>`;
  }).join('');
  p.viewEl.style.setProperty('--cols', colTemplate(cols));
}
function applyColTemplates() {
  for (const p of allPanes()) if (p.viewEl && p.view === 'list') p.viewEl.style.setProperty('--cols', colTemplate(columnsFor(p)));
}
function startColResize(p, e, col) {
  e.preventDefault(); e.stopPropagation();
  const cols = columnsFor(p);
  const idx = cols.indexOf(col);
  const leftCol = idx <= 0 ? 'name' : cols[idx - 1];
  const W = Object.assign({}, S.config.colWidths || {});
  const startX = e.clientX;
  const startRight = W[col] || COLS[col].w;
  const startLeft = leftCol === 'name' ? 0 : (W[leftCol] || COLS[leftCol].w);
  const clamp = (x) => Math.max(60, Math.min(640, Math.round(x)));
  document.body.classList.add('resizing');
  const move = (ev) => {
    const dx = ev.clientX - startX;
    if (leftCol === 'name') W[col] = clamp(startRight - dx); else W[leftCol] = clamp(startLeft + dx);
    S.config.colWidths = W;
    applyColTemplates();
  };
  const up = () => {
    document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up);
    document.body.classList.remove('resizing');
    p.justResized = true; setTimeout(() => { p.justResized = false; }, 50);
    setConfig({ colWidths: W });
  };
  document.addEventListener('mousemove', move); document.addEventListener('mouseup', up);
}
function toggleListCol(c) {
  const cur = (S.config.listCols && S.config.listCols.length ? S.config.listCols : ['size', 'type', 'mtime']).slice();
  const i = cur.indexOf(c);
  if (i >= 0) cur.splice(i, 1); else cur.push(c);
  setConfig({ listCols: cur.length ? cur : ['size'] });
  allPanes().forEach((pp) => pp.el && pp.view === 'list' && renderPane(pp, { keepScroll: true }));
}
function columnMenu(p) {
  if (p.path === TRASH && !p.search) return [{ header: 'Columnas fijas en la papelera' }];
  const cur = columnsFor(p);
  return [
    { header: 'Columnas visibles' },
    ...OPTIONAL_COLS.map((c) => ({ label: COLS[c].label, checked: cur.includes(c) || (c === 'mtime' && cur.includes('used')), action: () => toggleListCol(c) })),
    '-',
    { label: 'Restablecer anchos de columna', icon: 'rotateCcw', action: () => { setConfig({ colWidths: {} }); applyColTemplates(); } },
  ];
}

/* ---------- agrupación ---------- */
const GROUP_BY = [['none', 'Nada'], ['kind', 'Tipo'], ['date', 'Fecha'], ['size', 'Tamaño'], ['letter', 'Inicial']];
const KIND_GROUPS = {
  folder: [0, 'Carpetas'], image: [1, 'Imágenes'], video: [2, 'Vídeos'], audio: [3, 'Música y audio'],
  pdf: [4, 'Documentos'], doc: [4, 'Documentos'], sheet: [4, 'Documentos'], slides: [4, 'Documentos'], text: [4, 'Documentos'], ebook: [4, 'Documentos'],
  archive: [5, 'Archivos comprimidos'], code: [6, 'Código'], package: [7, 'Programas y paquetes'], exec: [7, 'Programas y paquetes'],
  font: [8, 'Otros'], disk: [8, 'Otros'], cert: [8, 'Otros'], file: [8, 'Otros'],
};
function groupOf(p, e, by) {
  if (by === 'kind') { const [o, l] = KIND_GROUPS[FT.kind(e)] || KIND_GROUPS.file; return { key: l, label: l, order: o }; }
  if (by === 'date') {
    const t = dateOf(p, e) || 0;
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    if (t >= today) return { key: 'd0', label: 'Hoy', order: 0 };
    if (t >= today - 86400000) return { key: 'd1', label: 'Ayer', order: 1 };
    if (t >= today - 6 * 86400000) return { key: 'd2', label: 'Últimos 7 días', order: 2 };
    if (t >= today - 29 * 86400000) return { key: 'd3', label: 'Últimos 30 días', order: 3 };
    const y = new Date(t).getFullYear();
    if (y === now.getFullYear()) return { key: 'd4', label: 'Este año', order: 4 };
    return { key: 'y' + y, label: String(y), order: 5 + (now.getFullYear() - y) };
  }
  if (by === 'size') {
    if (e.isDir) return { key: 's0', label: 'Carpetas', order: 0 };
    const s = e.size || 0;
    if (s === 0) return { key: 's1', label: 'Vacíos', order: 1 };
    if (s < 100e3) return { key: 's2', label: 'Diminutos (menos de 100 kB)', order: 2 };
    if (s < 10e6) return { key: 's3', label: 'Pequeños (hasta 10 MB)', order: 3 };
    if (s < 100e6) return { key: 's4', label: 'Medianos (hasta 100 MB)', order: 4 };
    if (s < 1e9) return { key: 's5', label: 'Grandes (hasta 1 GB)', order: 5 };
    return { key: 's6', label: 'Enormes (más de 1 GB)', order: 6 };
  }
  const c = normalize(e.name.replace(/^\.+/, '')).charAt(0).toUpperCase();
  if (/[0-9]/.test(c)) return { key: '0', label: '0–9', order: 0 };
  if (/[A-Z]/.test(c)) return { key: c, label: c, order: c.charCodeAt(0) };
  return { key: '#', label: 'Otros caracteres', order: 999 };
}
function groupingOf(p) {
  if (p.view === 'columns' || p.view === 'gallery') return 'none';
  return p.groupBy || 'none';
}
function applyGrouping(p, list) {
  p.groups = null;
  const by = groupingOf(p);
  if (by === 'none' || !list.length) return list;
  const map = new Map();
  for (const e of list) {
    const g = groupOf(p, e, by);
    let G = map.get(g.key);
    if (!G) { G = { key: g.key, label: g.label, order: g.order, items: [] }; map.set(g.key, G); }
    G.items.push(e);
  }
  const groups = [...map.values()].sort((a, b) => a.order - b.order);
  const out = [];
  p.groups = groups.map((g) => {
    const collapsed = !!(p.collapsed && p.collapsed.has(by + ':' + g.key));
    const start = out.length;
    if (!collapsed) out.push(...g.items);
    return { key: g.key, label: g.label, count: g.items.length, collapsed, start, shown: out.length - start };
  });
  return out;
}
function groupHeadHtml(g) {
  return `<div class="ghead${g.collapsed ? ' collapsed' : ''}" data-g="${esc(g.key)}"><span class="gchev">${ic('chevronDown')}</span><span class="glabel">${esc(g.label)}</span><span class="gcount">${fmtNum(g.count)}</span><span class="gline"></span></div>`;
}
function toggleGroup(p, key) {
  const by = groupingOf(p);
  if (!p.collapsed) p.collapsed = new Set();
  const k = by + ':' + key;
  if (p.collapsed.has(k)) p.collapsed.delete(k); else p.collapsed.add(k);
  computeVisible(p);
  renderPane(p, { keepScroll: true });
}
function buildSeq(p) {
  const seq = [];
  if (!p.groups) { for (let i = 0; i < p.visible.length; i++) seq.push(i); return seq; }
  p.groups.forEach((g, gi) => { seq.push(-1 - gi); for (let i = g.start; i < g.start + g.shown; i++) seq.push(i); });
  return seq;
}

/* ---------- memoria de vista por carpeta ---------- */
function saveFolderView(p) {
  if (!S.config.rememberViews || !p.path || p.search) return;
  const fv = Object.assign({}, S.config.folderViews || {});
  delete fv[p.path];
  fv[p.path] = { view: p.view, sortKey: p.sort.key, sortDir: p.sort.dir, groupBy: p.groupBy || 'none' };
  const keys = Object.keys(fv);
  if (keys.length > 400) keys.slice(0, keys.length - 400).forEach((k) => delete fv[k]);
  setConfig({ folderViews: fv });
}
function loadFolderView(p, path) {
  if (!S.config.rememberViews) return;
  const v = (S.config.folderViews || {})[path];
  if (v && VIEW_IDS.includes(v.view)) { p.view = v.view; p.sort = { key: v.sortKey || 'name', dir: v.sortDir || 1 }; p.groupBy = v.groupBy || 'none'; }
  else { p.view = VIEW_IDS.includes(S.config.view) ? S.config.view : 'grid'; p.sort = { key: S.config.sortKey || 'name', dir: S.config.sortDir || 1 }; p.groupBy = S.config.groupBy || 'none'; }
}
function setGroupBy(p, by) {
  p.groupBy = by;
  if (!S.config.rememberViews) setConfig({ groupBy: by });
  saveFolderView(p);
  computeVisible(p);
  renderPane(p, { keepScroll: true });
}

/* ---------- vista de columnas (estilo Finder) ---------- */
const colCache = new Map();
async function colEntries(path) {
  const c = colCache.get(path);
  if (c && Date.now() - c.t < 4000) return c.entries;
  const entries = await api.call('fs:list', path);
  colCache.set(path, { t: Date.now(), entries });
  if (colCache.size > 60) colCache.delete(colCache.keys().next().value);
  return entries;
}
function sortForColumn(list) {
  if (!S.config.showHidden) list = list.filter((e) => !e.hidden);
  return list.slice().sort((a, b) => (S.config.foldersFirst && a.isDir !== b.isDir ? (a.isDir ? -1 : 1) : collator.compare(a.name, b.name)));
}
function columnChain(p) {
  if (!p.path || isVirtual(p.path) || p.search) return [];
  const root = p.path === S.home || p.path.startsWith(S.home + '/') ? S.home : mountOf(p.path);
  const chain = [];
  let cur = p.path;
  while (cur !== root && cur !== '/') { cur = dirname(cur); chain.unshift(cur); }
  return chain;
}
function acolHtml(list, hl) {
  const ls = LIST_SIZES[zoomVal('columns')];
  if (!list.length) return '<div class="mcol-empty">Carpeta vacía</div>';
  return list.map((e) => `<div class="acol-item${e.path === hl ? ' hl' : ''}${e.hidden ? ' hidden-file' : ''}" data-path="${esc(e.path)}" data-isdir="${e.isDir ? 1 : 0}" title="${esc(e.name)}"><span class="ico" style="width:${ls.icon}px;height:${ls.icon}px">${iconHtml(e, ls.icon)}</span><span class="name">${esc(e.name)}</span>${e.isDir ? `<span class="mchev">${ic('chevronRight')}</span>` : ''}</div>`).join('');
}
function renderAncestorColumns(p, token) {
  const wrap = $('.mcols', p.itemsEl);
  const chain = columnChain(p);
  chain.forEach((dir, i) => {
    const col = h('div', { class: 'mcol anc', 'data-dir': dir, html: '<div class="mcol-empty"><span class="spinner"></span></div>' });
    wrap.insertBefore(col, p.listEl);
    const hl = chain[i + 1] || p.path;
    colEntries(dir).then((ents) => {
      if (token !== p.renderToken) return;
      col.innerHTML = acolHtml(sortForColumn(ents), hl);
      const el = $('.acol-item.hl', col);
      if (el) col.scrollTop = Math.max(0, el.offsetTop - col.clientHeight / 2);
    }).catch(() => { col.innerHTML = ''; });
  });
  requestAnimationFrame(() => { wrap.scrollLeft = wrap.scrollWidth; });
}
function scheduleNextColumn(p) { clearTimeout(p.nextTimer); p.nextTimer = setTimeout(() => updateNextColumn(p), 70); }
async function updateNextColumn(p) {
  if (p.view !== 'columns' || !p.itemsEl) return;
  const next = $('.mnext', p.itemsEl);
  if (!next) return;
  const sel = selected(p);
  const token = (p.nextToken = (p.nextToken || 0) + 1);
  const key = sel.length === 1 ? sel[0].path + sel[0].mtime : '';
  if (next.dataset.key === key && key) return;
  next.dataset.key = key;
  const wrap = $('.mcols', p.itemsEl);
  if (sel.length !== 1) { next.className = 'mcol mnext hidden'; next.innerHTML = ''; return; }
  const e = sel[0];
  if (e.isDir) {
    next.className = 'mcol mnext';
    next.dataset.dir = e.path;
    next.innerHTML = '<div class="mcol-empty"><span class="spinner"></span></div>';
    try {
      const ents = await colEntries(e.path);
      if (token !== p.nextToken) return;
      next.innerHTML = acolHtml(sortForColumn(ents), null);
    } catch (err) { if (token === p.nextToken) next.innerHTML = `<div class="mcol-empty">${esc(err.message)}</div>`; }
  } else {
    next.className = 'mcol mnext mprev';
    delete next.dataset.dir;
    const media = await buildMedia(e, {});
    if (token !== p.nextToken) return;
    next.innerHTML = '';
    next.append(media, h('div', { class: 'pv-title', text: e.name }), h('div', { class: 'pv-sub', text: FT.typeName(e) }),
      h('div', { class: 'pv-rows' },
        h('div', { class: 'pv-row' }, h('div', { class: 'pv-k', text: 'Tamaño' }), h('div', { class: 'pv-v', text: fmtSize(e.size) })),
        h('div', { class: 'pv-row' }, h('div', { class: 'pv-k', text: 'Modificado' }), h('div', { class: 'pv-v', text: fmtDateLong(e.mtime) })),
        h('div', { class: 'pv-row' }, h('div', { class: 'pv-k', text: 'Permisos' }), h('div', { class: 'pv-v', html: `<code>${permString(e.mode, false)}</code>` }))));
  }
  requestAnimationFrame(() => { wrap.scrollLeft = wrap.scrollWidth; });
}
async function acolMouse(p, e, ac) {
  const col = ac.closest('.mcol');
  const dir = col && col.dataset.dir;
  const path = ac.dataset.path;
  if (!dir) return;
  await navigate(p, dir, { select: [path] });
  focusView(p);
  return path;
}

/* ---------- galería ---------- */
function scheduleStage(p) { clearTimeout(p.stageTimer); p.stageTimer = setTimeout(() => renderStage(p), 60); }
async function renderStage(p) {
  if (p.view !== 'gallery' || !p.stageEl || !p.stageEl.isConnected) return;
  const st = p.stageEl;
  const e = p.visible.find((x) => x.path === p.focus && p.sel.has(x.path)) || selected(p)[0];
  if (!e) { st.innerHTML = ''; st.dataset.key = ''; return; }
  const key = e.path + e.mtime;
  if (st.dataset.key === key) return;
  st.dataset.key = key;
  const token = (p.stageToken = (p.stageToken || 0) + 1);
  const meta = h('div', { class: 'gal-meta', text: [FT.typeName(e), sizeText(e), fmtDate(e.mtime)].join(' · ') });
  const media = await buildMedia(e, { onMeta: (m) => { if (token === p.stageToken) meta.textContent = [FT.typeName(e), sizeText(e), m.dims, m.duration, fmtDate(e.mtime)].filter(Boolean).join(' · '); } });
  if (token !== p.stageToken) return;
  st.innerHTML = '';
  const idx = p.visible.indexOf(e);
  st.append(
    h('button', { class: 'gal-nav prev', title: 'Anterior (←)', html: ic('back'), disabled: idx <= 0 ? true : null, onclick: () => moveFocus(p, 'ArrowLeft') }),
    h('div', { class: 'gal-media', ondblclick: () => openEntries([e]) }, media),
    h('button', { class: 'gal-nav next', title: 'Siguiente (→)', html: ic('forward'), disabled: idx >= p.visible.length - 1 ? true : null, onclick: () => moveFocus(p, 'ArrowRight') }),
    h('div', { class: 'gal-info' }, h('div', { class: 'gal-name', text: e.name }), meta));
}

/* ---------- panel de opciones de vista ---------- */
function vpSeg(options, current, onPick, opts = {}) {
  return h('div', { class: `segmented small${opts.disabled ? ' disabled' : ''}` }, ...options.map(([v, l]) => h('button', {
    class: `seg${v === current ? ' on' : ''}`, disabled: opts.disabled ? true : null,
    onclick: () => { onPick(v); refreshViewPopover(); },
  }, h('b', { text: l }))));
}
function vpSwitch(label, key, after) {
  const cb = h('input', { type: 'checkbox', class: 'switch' });
  cb.checked = key === 'striped' ? S.config.striped !== false : !!S.config[key];
  cb.onchange = () => { setConfig({ [key]: cb.checked }); if (after) after(cb.checked); else rerenderAll(); };
  return h('label', { class: 'vp-switch' }, h('span', { text: label }), cb);
}
function viewPopover() {
  const p = pane();
  const real = p.path && !isVirtual(p.path);
  const box = h('div', { class: 'vp' });
  const committed = p.viewPreview ? p.viewPreview.view : p.view;
  const views = h('div', { class: 'vp-views', onmouseleave: () => endViewPreview(p) }, ...VIEWS.map((v) => h('button', {
    class: `vp-view${committed === v.id ? ' on' : ''}${p.viewPreview && p.view === v.id && committed !== v.id ? ' previewing' : ''}`, title: `${v.label} (Ctrl+${v.key})`,
    onmouseenter: () => startViewPreview(p, v.id),
    onclick: () => { commitViewPreview(p); setView(p, v.id); refreshViewPopover(); },
  }, h('span', { html: ic(v.icon) }), h('small', { text: v.label }))));
  box.appendChild(views);
  box.appendChild(h('div', { class: 'vp-hint center', text: 'Pasa el ratón para previsualizar · clic para aplicar' }));

  const z = zoomSpec(p.view);
  const range = h('input', { type: 'range', min: '0', max: String(z.max), step: '1', value: String(zoomVal(p.view)) });
  range.oninput = () => setZoom(Number(range.value));
  box.appendChild(h('div', { class: 'vp-row' }, h('span', { class: 'vp-label', text: 'Tamaño' }),
    h('button', { class: 'icon-btn tiny', html: ic('zoomOut'), onclick: () => { zoom(-1); range.value = zoomVal(p.view); } }), range,
    h('button', { class: 'icon-btn tiny', html: ic('zoomIn'), onclick: () => { zoom(1); range.value = zoomVal(p.view); } })));

  const noGroup = p.view === 'columns' || p.view === 'gallery';
  box.appendChild(h('div', { class: 'vp-sec', text: 'Agrupar por' }));
  box.appendChild(vpSeg(GROUP_BY, noGroup ? 'none' : p.groupBy || 'none', (v) => setGroupBy(p, v), { disabled: noGroup }));
  if (noGroup) box.appendChild(h('div', { class: 'vp-hint', text: 'No disponible en la vista de columnas ni en la galería.' }));

  const sortKeys = p.path === TRASH ? [['name', 'Nombre'], ['size', 'Tamaño'], ['deleted', 'Eliminado']] : [['name', 'Nombre'], ['size', 'Tamaño'], ['type', 'Tipo'], ['mtime', 'Fecha']];
  box.appendChild(h('div', { class: 'vp-sec', text: 'Ordenar por' }));
  const recentDefault = p.path === RECENT && p.sort.recentDefault !== false;
  box.appendChild(h('div', { class: 'vp-sortrow' },
    vpSeg(sortKeys, recentDefault ? '' : p.sort.key, (k) => { if (p.sort.key !== k || recentDefault) { p.sort.key = k; p.sort.dir = k === 'mtime' || k === 'size' || k === 'deleted' ? -1 : 1; p.sort.recentDefault = false; persistSort(p); } }),
    h('button', { class: 'icon-btn vp-dir', title: p.sort.dir > 0 ? 'Ascendente' : 'Descendente', html: ic(p.sort.dir > 0 ? 'sortAsc' : 'sortDesc'), onclick: () => { p.sort.dir = -p.sort.dir; p.sort.recentDefault = false; persistSort(p); refreshViewPopover(); } })));

  if (p.view === 'grid') {
    box.appendChild(h('div', { class: 'vp-sec', text: 'Debajo del nombre' }));
    box.appendChild(vpSeg([['none', 'Nada'], ['size', 'Tamaño'], ['mtime', 'Fecha'], ['type', 'Tipo']], S.config.gridInfo || 'none', (v) => { setConfig({ gridInfo: v }); rerenderAll(); }));
  }
  if (p.view === 'list') {
    box.appendChild(h('div', { class: 'vp-sec', text: 'Columnas' }));
    const cur = columnsFor(p);
    const fixed = p.path === TRASH && !p.search;
    box.appendChild(h('div', { class: 'chips' }, ...OPTIONAL_COLS.map((c) => h('button', {
      class: `chip${cur.includes(c) || (c === 'mtime' && cur.includes('used')) ? ' on' : ''}`, disabled: fixed ? true : null,
      onclick: () => { toggleListCol(c); refreshViewPopover(); },
    }, h('span', { html: ic('check') }), COLS[c].label))));
  }

  box.appendChild(h('div', { class: 'vp-sec', text: 'Opciones' }));
  box.appendChild(h('div', { class: 'vp-switches' },
    vpSwitch('Carpetas primero', 'foldersFirst'),
    vpSwitch('Archivos ocultos', 'showHidden'),
    vpSwitch('Miniaturas', 'thumbnails'),
    vpSwitch('Miniaturas recortadas en cuadrado', 'thumbCrop'),
    vpSwitch('Casillas de selección', 'checkboxes'),
    vpSwitch('Filas alternas en la lista', 'striped'),
    vpSwitch('Recordar la vista de cada carpeta', 'rememberViews', (on) => { if (on) saveFolderView(p); })));
  if (!real) box.appendChild(h('div', { class: 'vp-hint', text: 'Algunas opciones no se aplican a la papelera ni a Recientes.' }));
  return box;
}
function persistSort(p) {
  if (!S.config.rememberViews) setConfig({ sortKey: p.sort.key, sortDir: p.sort.dir });
  saveFolderView(p);
  computeVisible(p);
  renderPane(p, { keepScroll: true });
}
function showViewPopover(anchor) { Popover.show(viewPopover(), anchor, { className: 'view-popover', onClose: () => endViewPreview(pane(), true) }); }

/* previsualización de vistas al pasar el ratón */
function startViewPreview(p, id) {
  clearTimeout(p.previewTimer);
  p.previewTimer = setTimeout(() => {
    const orig = p.viewPreview ? p.viewPreview.view : p.view;
    if (id === p.view) return;
    if (id === orig) { endViewPreview(p); return; }
    if (!p.viewPreview) p.viewPreview = { view: p.view, sel: new Set(p.sel), focus: p.focus, anchor: p.anchor, scroll: p.viewEl.scrollTop };
    p.view = id;
    computeVisible(p);
    renderPane(p, { scrollTo: p.focus });
    p.viewEl.classList.add('previewing');
    let b = $('.preview-badge', p.el);
    if (!b) { b = h('div', { class: 'preview-badge' }); p.el.appendChild(b); }
    const v = VIEWS.find((x) => x.id === id);
    b.innerHTML = `${ic('eye')}<span>Vista previa: ${esc(v.label)}</span>`;
    b.classList.add('show');
    markPreviewButtons(p);
  }, 90);
}
function endViewPreview(p, immediate) {
  if (!p) return;
  clearTimeout(p.previewTimer);
  const st = p.viewPreview;
  hidePreviewBadge(p);
  if (!st) return;
  p.viewPreview = null;
  p.view = st.view; p.sel = st.sel; p.focus = st.focus; p.anchor = st.anchor;
  computeVisible(p);
  renderPane(p, { scrollTop: st.scroll });
  if (!['columns', 'gallery'].includes(p.view)) p.viewEl.scrollTop = st.scroll;
  if (!immediate) markPreviewButtons(p);
}
function hidePreviewBadge(p) { const b = p.el && $('.preview-badge', p.el); if (b) b.classList.remove('show'); }
function commitViewPreview(p) {
  clearTimeout(p.previewTimer);
  hidePreviewBadge(p);
  if (!p.viewPreview) return;
  const st = p.viewPreview;
  p.viewPreview = null;
  if (st.view === 'gallery' || p.view === 'gallery') { p.sel = st.sel; p.focus = st.focus; p.anchor = st.anchor; }
}
function markPreviewButtons(p) {
  const committed = p.viewPreview ? p.viewPreview.view : p.view;
  $$('.vp-view').forEach((b, i) => {
    b.classList.toggle('on', VIEWS[i].id === committed);
    b.classList.toggle('previewing', !!p.viewPreview && VIEWS[i].id === p.view);
  });
  const sub = $('.popover .vp-row input[type="range"]');
  if (sub) { const z = zoomSpec(committed); sub.max = String(z.max); sub.value = String(zoomVal(committed)); }
}
function refreshViewPopover() { if (Popover.isOpen()) Popover.refresh(viewPopover()); updateChrome(); }
