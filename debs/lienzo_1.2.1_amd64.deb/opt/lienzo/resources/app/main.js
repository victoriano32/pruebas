'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, clipboard, nativeImage, Menu, protocol, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const { execFile } = require('child_process');

const IMAGE_EXT = new Set(['.jpg', '.jpeg', '.jpe', '.jfif', '.png', '.gif', '.webp', '.bmp', '.svg', '.ico', '.avif', '.apng']);
const isImage = (p) => IMAGE_EXT.has(path.extname(p).toLowerCase());

let win = null;
let pendingOpen = null;

// Protocolo propio para servir imágenes locales con CORS (permite editarlas en canvas).
const MIME = {
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.jpe': 'image/jpeg', '.jfif': 'image/jpeg', '.png': 'image/png',
  '.apng': 'image/apng', '.gif': 'image/gif', '.webp': 'image/webp', '.bmp': 'image/bmp', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.avif': 'image/avif',
};
protocol.registerSchemesAsPrivileged([
  { scheme: 'limg', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } },
]);
function registerImageProtocol() {
  protocol.handle('limg', async (req) => {
    try {
      const u = new URL(req.url);
      const p = decodeURIComponent(u.pathname);
      if (!isImage(p)) return new Response('no', { status: 403 });
      const data = await fsp.readFile(p);
      return new Response(data, {
        headers: {
          'content-type': MIME[path.extname(p).toLowerCase()] || 'application/octet-stream',
          'access-control-allow-origin': '*',
          'cache-control': 'no-store',
        },
      });
    } catch (e) {
      return new Response('not found', { status: 404 });
    }
  });
}

function argFile(argv) {
  const args = argv.slice(app.isPackaged ? 1 : 2);
  for (const a of args) {
    if (!a || a.startsWith('-')) continue;
    let p = a.startsWith('file://') ? decodeURI(a.slice(7)) : a;
    p = path.resolve(p);
    if (p === app.getAppPath()) continue;
    try {
      const st = fs.statSync(p);
      if (st.isFile() && isImage(p)) return p;
      if (st.isDirectory()) return p;
    } catch (_) { /* ignore */ }
  }
  return null;
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', (_e, argv) => {
    const f = argFile(argv);
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
      if (f) win.webContents.send('open-path', f);
    }
  });
}

// --- settings ---------------------------------------------------------------
const settingsFile = () => path.join(app.getPath('userData'), 'ajustes.json');
function loadSettings() {
  try { return JSON.parse(fs.readFileSync(settingsFile(), 'utf8')); } catch (_) { return {}; }
}
function saveSettings(s) {
  try { fs.mkdirSync(path.dirname(settingsFile()), { recursive: true }); fs.writeFileSync(settingsFile(), JSON.stringify(s, null, 2)); } catch (_) { /* ignore */ }
}

// Calcula un tamaño de ventana que quepa siempre en la pantalla.
function initialBounds(saved) {
  const disp = saved && saved.x != null
    ? screen.getDisplayMatching({ x: saved.x, y: saved.y, width: saved.width || 100, height: saved.height || 100 })
    : screen.getPrimaryDisplay();
  const wa = disp.workArea;
  let width = Math.round(wa.width * 0.86), height = Math.round(wa.height * 0.88);
  let x, y;
  if (saved && saved.width && saved.height) {
    width = saved.width; height = saved.height; x = saved.x; y = saved.y;
  }
  width = Math.min(width, wa.width);
  height = Math.min(height, wa.height);
  const inside = x != null && y != null && x >= wa.x - 40 && y >= wa.y - 10 && x + width <= wa.x + wa.width + 40 && y + height <= wa.y + wa.height + 40;
  if (!inside) {
    x = Math.round(wa.x + (wa.width - width) / 2);
    y = Math.round(wa.y + (wa.height - height) / 2);
  }
  // En pantallas pequeñas (portátiles de 1366×768, etc.) es mejor arrancar maximizada.
  const small = wa.width < 1500 || wa.height < 860;
  return { x, y, width, height, small, minW: Math.min(720, wa.width), minH: Math.min(480, wa.height) };
}

function createWindow() {
  const s = loadSettings();
  const nativeFrame = !(s.prefs && s.prefs.customFrame);
  const ib = initialBounds(s.bounds);
  win = new BrowserWindow({
    width: ib.width,
    height: ib.height,
    x: ib.x, y: ib.y,
    minWidth: ib.minW,
    minHeight: ib.minH,
    frame: !nativeFrame ? false : true,
    autoHideMenuBar: true,
    backgroundColor: '#1f2125',
    title: 'Lienzo',
    icon: path.join(__dirname, 'icon.png'),
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      additionalArguments: [nativeFrame ? '--lienzo-frame=native' : '--lienzo-frame=custom'],
    },
  });
  if (s.maximized || (!s.bounds && ib.small)) win.maximize();
  // Si la pantalla cambia (otro monitor, otra resolución) recoloca la ventana.
  screen.on('display-removed', () => { if (win && !win.isMaximized()) { const nb = initialBounds(null); win.setBounds({ x: nb.x, y: nb.y, width: nb.width, height: nb.height }); } });
  screen.on('display-metrics-changed', () => {
    if (!win || win.isMaximized() || win.isFullScreen()) return;
    const nb = initialBounds(win.getBounds());
    const cur = win.getBounds();
    if (cur.width !== nb.width || cur.height !== nb.height || cur.x !== nb.x || cur.y !== nb.y) win.setBounds({ x: nb.x, y: nb.y, width: nb.width, height: nb.height });
  });
  if (s.maximized) win.maximize();
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());

  const persist = () => {
    const cur = loadSettings();
    cur.maximized = win.isMaximized();
    if (!win.isMaximized() && !win.isFullScreen()) cur.bounds = win.getBounds();
    saveSettings(cur);
  };
  win.on('close', persist);
  for (const ev of ['maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen']) {
    win.on(ev, () => win.webContents.send('window-state', { maximized: win.isMaximized(), fullscreen: win.isFullScreen() }));
  }
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
}

app.whenReady().then(() => {
  pendingOpen = argFile(process.argv);
  registerImageProtocol();
  createWindow();
});
app.on('window-all-closed', () => app.quit());

// --- IPC ----------------------------------------------------------------------
ipcMain.handle('initial-path', () => { const p = pendingOpen; pendingOpen = null; return p; });
ipcMain.handle('settings:get', () => loadSettings().prefs || {});
ipcMain.handle('settings:set', (_e, prefs) => { const s = loadSettings(); s.prefs = Object.assign(s.prefs || {}, prefs); saveSettings(s); });

ipcMain.on('win:minimize', () => win && win.minimize());
ipcMain.on('win:maximize', () => { if (!win) return; win.isMaximized() ? win.unmaximize() : win.maximize(); });
ipcMain.on('win:close', () => win && win.close());
ipcMain.on('win:fullscreen', (_e, v) => { if (win) win.setFullScreen(typeof v === 'boolean' ? v : !win.isFullScreen()); });
ipcMain.handle('win:state', () => ({ maximized: win.isMaximized(), fullscreen: win.isFullScreen() }));
ipcMain.handle('app:version', () => app.getVersion());
ipcMain.on('app:relaunch', () => { app.relaunch(); win.close(); });

ipcMain.handle('dialog:open', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Abrir imagen',
    properties: ['openFile'],
    filters: [
      { name: 'Imágenes', extensions: [...IMAGE_EXT].map((e) => e.slice(1)) },
      { name: 'Todos los archivos', extensions: ['*'] },
    ],
  });
  return r.canceled ? null : r.filePaths[0];
});

ipcMain.handle('dialog:openFolder', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Abrir carpeta', properties: ['openDirectory'] });
  return r.canceled ? null : r.filePaths[0];
});

ipcMain.handle('dialog:save', async (_e, defaultPath) => {
  const r = await dialog.showSaveDialog(win, {
    title: 'Guardar copia',
    defaultPath,
    filters: [
      { name: 'JPEG', extensions: ['jpg', 'jpeg'] },
      { name: 'PNG', extensions: ['png'] },
      { name: 'WebP', extensions: ['webp'] },
    ],
  });
  return r.canceled ? null : r.filePath;
});

ipcMain.handle('fs:list', async (_e, target) => {
  let dir = target;
  let st = await fsp.stat(target);
  if (st.isFile()) dir = path.dirname(target);
  const names = await fsp.readdir(dir);
  const out = [];
  await Promise.all(names.map(async (n) => {
    if (n.startsWith('.') || !isImage(n)) return;
    const full = path.join(dir, n);
    try {
      const s = await fsp.stat(full);
      if (s.isFile()) out.push({ path: full, name: n, size: s.size, mtime: s.mtimeMs });
    } catch (_) { /* ignore */ }
  }));
  return { dir, files: out };
});

ipcMain.handle('fs:stat', async (_e, p) => {
  const s = await fsp.stat(p);
  return { size: s.size, mtime: s.mtimeMs, birthtime: s.birthtimeMs };
});

ipcMain.handle('fs:readHead', async (_e, p, bytes) => {
  const fh = await fsp.open(p, 'r');
  try {
    const buf = Buffer.alloc(bytes);
    const { bytesRead } = await fh.read(buf, 0, bytes, 0);
    return buf.subarray(0, bytesRead);
  } finally { await fh.close(); }
});

ipcMain.handle('fs:write', async (_e, p, data) => {
  const tmp = p + '.lienzo-tmp';
  await fsp.writeFile(tmp, Buffer.from(data));
  await fsp.rename(tmp, p);
  return true;
});

ipcMain.handle('fs:exists', async (_e, p) => { try { await fsp.access(p); return true; } catch (_) { return false; } });

ipcMain.handle('fs:trash', async (_e, p) => { await shell.trashItem(p); return true; });

ipcMain.handle('fs:rename', async (_e, from, newName) => {
  if (!newName || /[\\/]/.test(newName)) throw new Error('Nombre no válido');
  const to = path.join(path.dirname(from), newName);
  try { await fsp.access(to); throw new Error('Ya existe un archivo con ese nombre'); } catch (e) { if (e.code !== 'ENOENT') throw e; }
  await fsp.rename(from, to);
  return to;
});

ipcMain.on('shell:showInFolder', (_e, p) => shell.showItemInFolder(p));
ipcMain.on('shell:openExternal', (_e, u) => { if (/^https:\/\//.test(u)) shell.openExternal(u); });

ipcMain.handle('clipboard:copyImage', async (_e, p, dataUrl) => {
  let img = dataUrl ? nativeImage.createFromDataURL(dataUrl) : nativeImage.createFromPath(p);
  if (img.isEmpty()) return false;
  clipboard.writeImage(img);
  return true;
});

ipcMain.handle('clipboard:copyText', (_e, t) => { clipboard.writeText(t); return true; });

ipcMain.handle('wallpaper:set', async (_e, p) => {
  const uri = require('url').pathToFileURL(p).href;
  const run = (args) => new Promise((res) => execFile('gsettings', args, (err) => res(!err)));
  const results = await Promise.all([
    run(['set', 'org.cinnamon.desktop.background', 'picture-uri', uri]),
    run(['set', 'org.gnome.desktop.background', 'picture-uri', uri]),
    run(['set', 'org.gnome.desktop.background', 'picture-uri-dark', uri]),
    run(['set', 'org.mate.background', 'picture-filename', p]),
  ]);
  return results.some(Boolean);
});

// Impresión: abre una página oculta solo con la imagen y lanza el diálogo de impresión del sistema.
ipcMain.handle('print', async (_e, opts) => {
  const os = require('os');
  let imgPath = opts.path;
  let tmpImg = null;
  if (opts.data) {
    tmpImg = path.join(os.tmpdir(), `lienzo-imprimir-${Date.now()}.png`);
    await fsp.writeFile(tmpImg, Buffer.from(opts.data));
    imgPath = tmpImg;
  }
  const src = 'limg://local' + imgPath.split('/').map(encodeURIComponent).join('/');
  const fill = opts.fit === 'fill';
  const margin = opts.margins === 'none' ? '0' : '10mm';
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${(opts.title || 'Lienzo').replace(/[<&]/g, '')}</title>
<style>
@page { margin: ${margin}; }
html, body { margin: 0; padding: 0; width: 100%; height: 100%; background: #fff; }
.page { width: 100vw; height: 100vh; display: flex; align-items: center; justify-content: center; overflow: hidden; }
img { display: block; width: 100%; height: 100%; object-fit: ${fill ? 'cover' : 'contain'}; }
</style></head><body><div class="page"><img src="${src}"></div></body></html>`;
  const tmpHtml = path.join(os.tmpdir(), `lienzo-imprimir-${Date.now()}.html`);
  await fsp.writeFile(tmpHtml, html);
  const pw = new BrowserWindow({ show: false, webPreferences: { sandbox: true, contextIsolation: true } });
  try {
    await pw.loadFile(tmpHtml);
    await pw.webContents.executeJavaScript('Promise.all([...document.images].map((i) => i.decode().catch(() => {}))).then(() => true)');
    if (process.env.LIENZO_PRINT_TEST) {
      const pdf = await pw.webContents.printToPDF({ landscape: !!opts.landscape, printBackground: true, pageSize: 'A4', margins: { marginType: 'default' } });
      await fsp.writeFile(process.env.LIENZO_PRINT_TEST, pdf);
      return { ok: true };
    }
    const result = await new Promise((res) => {
      pw.webContents.print({ silent: false, printBackground: true, landscape: !!opts.landscape }, (ok, reason) => res({ ok, reason }));
    });
    return result;
  } finally {
    pw.destroy();
    fsp.unlink(tmpHtml).catch(() => {});
    if (tmpImg) setTimeout(() => fsp.unlink(tmpImg).catch(() => {}), 60000);
  }
});
