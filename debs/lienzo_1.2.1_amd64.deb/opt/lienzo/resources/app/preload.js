'use strict';
const { contextBridge, ipcRenderer, webUtils } = require('electron');

const frameArg = process.argv.find((a) => a.startsWith('--lienzo-frame='));
contextBridge.exposeInMainWorld('lienzo', {
  nativeFrame: !frameArg || frameArg.endsWith('native'),
  version: () => ipcRenderer.invoke('app:version'),
  relaunch: () => ipcRenderer.send('app:relaunch'),
  initialPath: () => ipcRenderer.invoke('initial-path'),
  getPrefs: () => ipcRenderer.invoke('settings:get'),
  setPrefs: (p) => ipcRenderer.invoke('settings:set', p),
  openDialog: () => ipcRenderer.invoke('dialog:open'),
  openFolderDialog: () => ipcRenderer.invoke('dialog:openFolder'),
  saveDialog: (p) => ipcRenderer.invoke('dialog:save', p),
  list: (p) => ipcRenderer.invoke('fs:list', p),
  stat: (p) => ipcRenderer.invoke('fs:stat', p),
  readHead: (p, n) => ipcRenderer.invoke('fs:readHead', p, n),
  write: (p, data) => ipcRenderer.invoke('fs:write', p, data),
  exists: (p) => ipcRenderer.invoke('fs:exists', p),
  trash: (p) => ipcRenderer.invoke('fs:trash', p),
  rename: (p, n) => ipcRenderer.invoke('fs:rename', p, n),
  showInFolder: (p) => ipcRenderer.send('shell:showInFolder', p),
  openExternal: (u) => ipcRenderer.send('shell:openExternal', u),
  copyImage: (p, dataUrl) => ipcRenderer.invoke('clipboard:copyImage', p, dataUrl),
  copyText: (t) => ipcRenderer.invoke('clipboard:copyText', t),
  setWallpaper: (p) => ipcRenderer.invoke('wallpaper:set', p),
  print: (opts) => ipcRenderer.invoke('print', opts),
  pathForFile: (f) => { try { return webUtils.getPathForFile(f); } catch (_) { return f.path || null; } },
  win: {
    minimize: () => ipcRenderer.send('win:minimize'),
    maximize: () => ipcRenderer.send('win:maximize'),
    close: () => ipcRenderer.send('win:close'),
    fullscreen: (v) => ipcRenderer.send('win:fullscreen', v),
    state: () => ipcRenderer.invoke('win:state'),
  },
  on: (ch, fn) => {
    const allowed = ['open-path', 'window-state'];
    if (allowed.includes(ch)) ipcRenderer.on(ch, (_e, ...a) => fn(...a));
  },
});
