'use strict';
/* global ICONS, icon, hydrateIcons, Exif, ImageOps */
const api = window.lienzo;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const body = document.body;

const el = {
  stage: $('#stage'), content: $('#content'), img: $('#view-img'), canvas: $('#edit-canvas'), draw: $('#draw-layer'),
  crop: $('#crop-box'), cropSize: $('#crop-size'), empty: $('#empty'), title: $('#doc-title'), meta: $('#doc-meta'),
  film: $('#film-track'), zval: $('#z-val'), loading: $('#loading'), info: $('#info-body'), menu: $('#menu'),
  veil: $('#modal-veil'), modal: $('#modal'), toasts: $('#toasts'), prev: $('#nav-prev'), next: $('#nav-next'),
  textEntry: $('#text-entry'), foot: $('#pending-foot'), footLabel: $('#pending-label'),
};

const LOSSY = new Set(['jpg', 'jpeg', 'jpe', 'jfif', 'webp']);
const WRITABLE = new Set(['jpg', 'jpeg', 'jpe', 'jfif', 'png', 'webp']);

const state = {
  dir: null, files: [], index: -1,
  nat: { w: 0, h: 0 },
  view: { s: 1, cx: 0, cy: 0, rot: 0, mode: 'fit' },
  prefs: { bg: 'dark', film: true, info: false, sortKey: 'name', sortDir: 1, quality: 92, slideSec: 4 },
  loadToken: 0,
  slideshow: null,
  fullscreen: false,
};

// ------------------------------------------------------------------ utilidades
function imgUrl(p, bust) {
  const enc = p.split('/').map(encodeURIComponent).join('/');
  return 'limg://local' + enc + (bust ? `?v=${bust}` : '');
}
function extOf(p) { const m = /\.([^.\/]+)$/.exec(p); return m ? m[1].toLowerCase() : ''; }
function baseName(p) { return p.split('/').pop(); }
function dirName(p) { return p.slice(0, p.lastIndexOf('/')) || '/'; }
function fmtBytes(n) {
  if (n == null) return '';
  const u = ['B', 'KB', 'MB', 'GB']; let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n.toLocaleString('es-ES', { maximumFractionDigits: i ? 1 : 0 })} ${u[i]}`;
}
function fmtNum(n) { return Math.round(n).toLocaleString('es-ES'); }
const collator = new Intl.Collator('es', { numeric: true, sensitivity: 'base' });
function formatName(ext) {
  return ({ jpg: 'JPEG', jpeg: 'JPEG', jpe: 'JPEG', jfif: 'JPEG', png: 'PNG', apng: 'APNG', gif: 'GIF', webp: 'WebP', bmp: 'BMP', svg: 'SVG', ico: 'ICO', avif: 'AVIF' })[ext] || ext.toUpperCase();
}
function current() { return state.files[state.index] || null; }
function savePrefs() { api.setPrefs(state.prefs); }

function toast(msg, action) {
  if (!action) $$('.toast.plain', el.toasts).forEach((x) => x.remove());
  const t = document.createElement('div');
  if (!action) t.classList.add('plain');
  t.classList.add('toast');
  t.textContent = msg;
  if (action) {
    const b = document.createElement('button');
    b.textContent = action.label;
    b.onclick = () => { action.run(); close(); };
    t.appendChild(b);
  }
  el.toasts.appendChild(t);
  const close = () => { t.classList.add('out'); setTimeout(() => t.remove(), 220); };
  setTimeout(close, action ? 5000 : 2600);
}

function setLoading(on) { el.loading.classList.toggle('on', !!on); }

// ------------------------------------------------------------------ diálogos
function modal(html, { wide } = {}) {
  el.modal.className = 'modal' + (wide ? ' wide' : '');
  el.modal.innerHTML = html;
  hydrateIcons(el.modal);
  el.veil.classList.add('on');
  return new Promise((resolve) => {
    const done = (v) => { el.veil.classList.remove('on'); el.veil.onclick = null; document.removeEventListener('keydown', onKey, true); resolve(v); };
    el.modal.querySelectorAll('[data-res]').forEach((b) => b.addEventListener('click', () => done(b.dataset.res)));
    el.veil.onclick = (e) => { if (e.target === el.veil) done(null); };
    const onKey = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); done(null); }
      if (e.key === 'Enter' && !e.shiftKey) {
        const def = el.modal.querySelector('[data-default]');
        if (def) { e.preventDefault(); e.stopPropagation(); done(def.dataset.res); }
      }
    };
    document.addEventListener('keydown', onKey, true);
    const f = el.modal.querySelector('input[type=text], [data-default]');
    if (f) setTimeout(() => { f.focus(); if (f.select) f.select(); }, 30);
  });
}

function confirmModal(title, text, okLabel, danger) {
  return modal(`<h2>${title}</h2><p>${text}</p><div class="actions">
    <button class="btn ghost" data-res="no">Cancelar</button>
    <button class="btn ${danger ? 'danger' : 'accent'}" data-res="yes" data-default>${okLabel}</button></div>`).then((r) => r === 'yes');
}

// ------------------------------------------------------------------ menú
function openMenu(items, x, y) {
  el.menu.innerHTML = '';
  for (const it of items) {
    if (it === '-') { el.menu.appendChild(document.createElement('hr')); continue; }
    if (it.label && it.header) { const d = document.createElement('div'); d.className = 'menu-label'; d.textContent = it.label; el.menu.appendChild(d); continue; }
    const b = document.createElement('button');
    b.className = (it.danger ? 'danger ' : '') + (it.checked ? 'checked' : '');
    b.innerHTML = (it.icon ? icon(it.icon) : '<span style="width:17px"></span>') + `<span>${it.label}</span>` + (it.kbd ? `<span class="kbd">${it.kbd}</span>` : '');
    if (it.disabled) { b.disabled = true; b.style.opacity = '.4'; }
    b.onclick = () => { closeMenu(); it.run(); };
    el.menu.appendChild(b);
  }
  el.menu.classList.add('on');
  const r = el.menu.getBoundingClientRect();
  el.menu.style.left = Math.max(8, Math.min(x, innerWidth - r.width - 8)) + 'px';
  el.menu.style.top = Math.max(8, Math.min(y, innerHeight - r.height - 8)) + 'px';
}
function closeMenu() { el.menu.classList.remove('on'); }
document.addEventListener('pointerdown', (e) => { if (!el.menu.contains(e.target)) closeMenu(); }, true);

// ------------------------------------------------------------------ apertura
async function openPath(p) {
  try {
    setLoading(true);
    const { dir, files } = await api.list(p);
    state.dir = dir;
    state.files = files;
    sortFiles();
    let idx = state.files.findIndex((f) => f.path === p);
    if (idx < 0) idx = 0;
    buildFilmstrip();
    if (!state.files.length) { showEmpty(true); toast('No hay imágenes en esa carpeta'); return; }
    await show(idx);
  } catch (e) {
    toast('No se pudo abrir: ' + (e.message || e));
  } finally { setLoading(false); }
}

function sortFiles() {
  const cur = current();
  const { sortKey, sortDir } = state.prefs;
  state.files.sort((a, b) => {
    let r = 0;
    if (sortKey === 'date') r = a.mtime - b.mtime;
    else if (sortKey === 'size') r = a.size - b.size;
    if (!r) r = collator.compare(a.name, b.name);
    return r * sortDir;
  });
  if (cur) state.index = state.files.findIndex((f) => f.path === cur.path);
}

function showEmpty(on) {
  el.empty.classList.toggle('hidden', !on);
  el.content.classList.toggle('show', !on);
  $('#zoom-pill').classList.toggle('hidden', on);
  body.classList.toggle('no-files', on && !state.files.length);
  if (on) { el.title.textContent = ''; el.meta.innerHTML = ''; state.index = -1; updateNav(); }
}

async function show(i, opts = {}) {
  if (!state.files.length) return showEmpty(true);
  i = clamp(i, 0, state.files.length - 1);
  const f = state.files[i];
  const token = ++state.loadToken;
  state.index = i;
  updateNav();
  markThumb();
  const url = imgUrl(f.path, f.mtime);
  let probe = preloadCache.get(url);
  preloadCache.delete(url);
  if (!probe || probe === el.img) {
    probe = new Image();
    probe.crossOrigin = 'anonymous';
    probe.decoding = 'async';
    probe.src = url;
  }
  const slow = setTimeout(() => setLoading(true), 120);
  try {
    await probe.decode();
  } catch (e) {
    clearTimeout(slow); setLoading(false);
    if (token !== state.loadToken) return;
    showEmpty(false);
    el.img.removeAttribute('src');
    el.title.textContent = f.name;
    el.meta.innerHTML = '<span>No se puede mostrar este archivo</span>';
    return;
  }
  clearTimeout(slow); setLoading(false);
  if (token !== state.loadToken) return;
  showEmpty(false);
  let w = probe.naturalWidth, h = probe.naturalHeight;
  if (!w || !h) { w = 1024; h = 768; }
  const fade = opts.fade !== false && el.img.getAttribute('src');
  if (fade) el.img.classList.add('fading');
  const swap = () => {
    probe.id = 'view-img';
    probe.alt = '';
    probe.draggable = false;
    if (fade) probe.classList.add('fading');
    el.img.replaceWith(probe);
    el.img = probe;
    if (fade) requestAnimationFrame(() => requestAnimationFrame(() => probe.classList.remove('fading')));
    state.nat = { w, h };
    state.view.rot = 0;
    setContentSize(w, h);
    fitView(false);
    updateTitle();
    if (body.classList.contains('info-open')) renderInfo();
  };
  if (fade && !body.classList.contains('slideshow')) setTimeout(swap, 90); else swap();
  preloadNeighbours();
}

const preloadCache = new Map();
function preloadNeighbours() {
  const want = new Set();
  for (const d of [1, -1, 2]) {
    const f = state.files[state.index + d];
    if (f) want.add(imgUrl(f.path, f.mtime));
  }
  for (const k of [...preloadCache.keys()]) if (!want.has(k)) preloadCache.delete(k);
  for (const u of want) {
    if (preloadCache.has(u)) continue;
    const im = new Image(); im.crossOrigin = 'anonymous'; im.decoding = 'async'; im.src = u;
    im.decode().catch(() => {});
    preloadCache.set(u, im);
  }
}

function updateTitle() {
  const f = current();
  if (!f) return;
  el.title.textContent = f.name;
  const parts = [
    `${state.index + 1} de ${state.files.length}`,
    `${fmtNum(state.nat.w)} × ${fmtNum(state.nat.h)}`,
    fmtBytes(f.size),
  ];
  el.meta.innerHTML = parts.map((p) => `<span>${p}</span>`).join('<span class="gap"></span>');
  document.title = `${f.name} — Lienzo`;
}

function updateNav() {
  el.prev.disabled = state.index <= 0;
  el.next.disabled = state.index < 0 || state.index >= state.files.length - 1;
}

function go(delta) {
  if (body.classList.contains('editing') || !state.files.length) return;
  const n = state.index + delta;
  if (n < 0 || n >= state.files.length) return;
  show(n);
}

// ------------------------------------------------------------------ vista / zoom
function setContentSize(w, h) {
  el.content.style.width = w + 'px';
  el.content.style.height = h + 'px';
  el.draw.setAttribute('viewBox', `0 0 ${w} ${h}`);
}

function stageSize() { return { W: el.stage.clientWidth, H: el.stage.clientHeight }; }
function rotated() { return state.view.rot % 180 !== 0; }
function effSize() { const { w, h } = state.nat; return rotated() ? { w: h, h: w } : { w, h }; }

function fitScale() {
  const { W, H } = stageSize();
  const { w, h } = effSize();
  const pad = body.classList.contains('fullscreen') || body.classList.contains('slideshow') ? 0 : (body.classList.contains('editing') ? 48 : 28);
  const s = Math.min((W - pad * 2) / w, (H - pad * 2 - (body.classList.contains('editing') ? 40 : 0)) / h);
  return body.classList.contains('editing') ? s : Math.min(1, s);
}

function fitView(animate = true) {
  const { W, H } = stageSize();
  state.view.mode = 'fit';
  state.view.s = fitScale();
  state.view.cx = W / 2;
  state.view.cy = H / 2 - (body.classList.contains('editing') ? 16 : 0);
  applyView(animate);
}

function clampView() {
  const v = state.view;
  const { W, H } = stageSize();
  const { w, h } = effSize();
  const sw = w * v.s, sh = h * v.s;
  if (sw <= W) v.cx = W / 2; else v.cx = clamp(v.cx, W - sw / 2, sw / 2);
  if (sh <= H) v.cy = H / 2; else v.cy = clamp(v.cy, H - sh / 2, sh / 2);
}

function applyView(animate) {
  const v = state.view;
  const { w, h } = state.nat;
  if (animate) {
    el.content.classList.add('animate');
    clearTimeout(applyView.t);
    applyView.t = setTimeout(() => el.content.classList.remove('animate'), 240);
  }
  el.content.style.transform = `translate(${v.cx}px, ${v.cy}px) rotate(${v.rot}deg) scale(${v.s}) translate(${-w / 2}px, ${-h / 2}px)`;
  el.content.style.setProperty('--inv', String(1 / v.s));
  el.content.classList.toggle('pixelated', v.s >= 3);
  if (document.activeElement !== el.zval.querySelector('input')) el.zval.textContent = `${Math.round(v.s * 100)} %`;
  const { W, H } = stageSize();
  const { w: ew, h: eh } = effSize();
  const big = ew * v.s > W + 1 || eh * v.s > H + 1;
  el.stage.classList.toggle('grab', big && !toolCursor());
  positionTextEntry();
}

function zoomAt(ns, px, py, animate) {
  const v = state.view;
  ns = clamp(ns, 0.02, 32);
  if (px == null) { const { W, H } = stageSize(); px = W / 2; py = H / 2; }
  v.cx = px - (px - v.cx) * (ns / v.s);
  v.cy = py - (py - v.cy) * (ns / v.s);
  v.s = ns;
  v.mode = 'free';
  clampView();
  applyView(animate);
}

const ZOOM_STEPS = [0.05, 0.1, 0.15, 0.25, 0.33, 0.5, 0.67, 0.75, 1, 1.25, 1.5, 2, 3, 4, 6, 8, 12, 16, 24, 32];
function zoomStep(dir) {
  const s = state.view.s;
  let ns = dir > 0 ? ZOOM_STEPS.find((z) => z > s * 1.01) : [...ZOOM_STEPS].reverse().find((z) => z < s * 0.99);
  if (!ns) ns = dir > 0 ? 32 : 0.02;
  zoomAt(ns, null, null, true);
}
function zoomActual() { zoomAt(1, null, null, true); }

function rotateView(dir) {
  if (body.classList.contains('editing')) return;
  state.view.rot = (state.view.rot + (dir > 0 ? 90 : 270)) % 360;
  fitView(true);
}

function stageToImage(clientX, clientY) {
  const r = el.content.getBoundingClientRect();
  return { x: ((clientX - r.left) / r.width) * state.nat.w, y: ((clientY - r.top) / r.height) * state.nat.h };
}

new ResizeObserver(() => {
  if (!state.nat.w) return;
  if (state.view.mode === 'fit') fitView(false); else { clampView(); applyView(false); }
}).observe(el.stage);

// rueda: zoom en el punto
el.stage.addEventListener('wheel', (e) => {
  if (!state.nat.w || el.empty && !el.empty.classList.contains('hidden')) return;
  e.preventDefault();
  const r = el.stage.getBoundingClientRect();
  const k = Math.exp(-e.deltaY * (e.ctrlKey ? 0.004 : 0.0018));
  zoomAt(state.view.s * k, e.clientX - r.left, e.clientY - r.top, false);
}, { passive: false });

// arrastre para desplazar
let pan = null;
el.stage.addEventListener('pointerdown', (e) => {
  if (e.target.closest('button, .zoom-pill, input, .crop-box')) return;
  if (!state.nat.w) return;
  if (e.button === 0 && editorPointerDown(e)) return;
  if (e.button !== 0 && e.button !== 1) return;
  pan = { id: e.pointerId, x: e.clientX, y: e.clientY, cx: state.view.cx, cy: state.view.cy, moved: false };
  el.stage.setPointerCapture(e.pointerId);
  el.stage.classList.add('grabbing');
});
el.stage.addEventListener('pointermove', (e) => {
  if (editorPointerMove(e)) return;
  if (!pan || pan.id !== e.pointerId) return;
  const dx = e.clientX - pan.x, dy = e.clientY - pan.y;
  if (Math.abs(dx) + Math.abs(dy) > 3) pan.moved = true;
  state.view.cx = pan.cx + dx; state.view.cy = pan.cy + dy;
  state.view.mode = 'free';
  clampView(); applyView(false);
});
const endPan = (e) => {
  if (editorPointerUp(e)) return;
  if (!pan) return;
  el.stage.classList.remove('grabbing');
  pan = null;
};
el.stage.addEventListener('pointerup', endPan);
el.stage.addEventListener('pointercancel', endPan);

el.stage.addEventListener('dblclick', (e) => {
  if (e.target.closest('button, .zoom-pill, input')) return;
  if (!state.nat.w || (body.classList.contains('editing') && (edit.tab === 'draw' || edit.tab === 'crop'))) return;
  const r = el.stage.getBoundingClientRect();
  if (state.view.mode === 'fit' && Math.abs(state.view.s - 1) > 0.01) zoomAt(1, e.clientX - r.left, e.clientY - r.top, true);
  else fitView(true);
});

el.stage.addEventListener('contextmenu', (e) => {
  e.preventDefault();
  if (!current() || body.classList.contains('editing')) return;
  openMenu(fileMenuItems(), e.clientX, e.clientY);
});

// píldora de zoom
$('#z-in').onclick = () => zoomStep(1);
$('#z-out').onclick = () => zoomStep(-1);
$('#z-fit').onclick = () => fitView(true);
$('#z-100').onclick = zoomActual;
$('#z-rot').onclick = () => rotateView(1);
$('#z-bg').onclick = cycleBg;
el.zval.onclick = () => {
  if (el.zval.querySelector('input')) return;
  const inp = document.createElement('input');
  inp.className = 'zoom-input';
  inp.value = Math.round(state.view.s * 100);
  el.zval.replaceWith(inp);
  inp.focus(); inp.select();
  const done = (apply) => {
    if (apply) { const v = parseFloat(inp.value); if (v > 0) zoomAt(v / 100, null, null, true); }
    inp.replaceWith(el.zval);
    el.zval.textContent = `${Math.round(state.view.s * 100)} %`;
  };
  inp.onkeydown = (e) => { e.stopPropagation(); if (e.key === 'Enter') done(true); if (e.key === 'Escape') done(false); };
  inp.onblur = () => done(false);
};

// ------------------------------------------------------------------ fondo / tira / info
const BGS = ['dark', 'grey', 'check', 'light'];
function applyBg() { BGS.forEach((b) => body.classList.toggle('bg-' + b, state.prefs.bg === b)); }
function cycleBg() {
  state.prefs.bg = BGS[(BGS.indexOf(state.prefs.bg) + 1) % BGS.length];
  applyBg(); savePrefs();
  toast({ dark: 'Fondo oscuro', grey: 'Fondo gris neutro', check: 'Fondo de cuadros', light: 'Fondo claro' }[state.prefs.bg]);
}
function toggleFilm(v) {
  state.prefs.film = v == null ? !state.prefs.film : v;
  body.classList.toggle('film-hidden', !state.prefs.film);
  savePrefs();
}
function toggleInfo(v) {
  state.prefs.info = v == null ? !state.prefs.info : v;
  body.classList.toggle('info-open', state.prefs.info);
  $('#btn-info').classList.toggle('on', state.prefs.info);
  if (state.prefs.info) renderInfo();
  savePrefs();
}

// ------------------------------------------------------------------ tira de película
let thumbObserver = null;
const thumbQueue = [];
let thumbActive = 0;

function buildFilmstrip() {
  if (!el.film) return;
  el.film.innerHTML = '';
  if (thumbObserver) thumbObserver.disconnect();
  thumbQueue.length = 0;
  thumbObserver = new IntersectionObserver((entries) => {
    for (const en of entries) {
      if (en.isIntersecting && !en.target.dataset.loaded) {
        en.target.dataset.loaded = '1';
        thumbQueue.push(en.target);
        pumpThumbs();
      }
    }
  }, { root: el.film, rootMargin: '0px 400px' });
  const frag = document.createDocumentFragment();
  state.files.forEach((f, i) => {
    const b = document.createElement('button');
    b.className = 'thumb';
    b.title = f.name;
    b.dataset.i = i;
    b.innerHTML = '<canvas width="172" height="124"></canvas>';
    b.onclick = () => { if (!body.classList.contains('editing')) show(i); };
    frag.appendChild(b);
  });
  el.film.appendChild(frag);
  $$('.thumb', el.film).forEach((t) => thumbObserver.observe(t));
  markThumb();
}

function pumpThumbs() {
  while (thumbActive < 4 && thumbQueue.length) {
    const t = thumbQueue.shift();
    const f = state.files[+t.dataset.i];
    if (!f) continue;
    thumbActive++;
    loadThumb(t, f).finally(() => { thumbActive--; pumpThumbs(); });
  }
}

async function loadThumb(t, f) {
  const im = new Image();
  im.decoding = 'async';
  im.src = imgUrl(f.path, f.mtime);
  try { await im.decode(); } catch (_) { t.classList.add('broken'); return; }
  const c = t.querySelector('canvas');
  const x = c.getContext('2d');
  const iw = im.naturalWidth || 172, ih = im.naturalHeight || 124;
  const s = Math.max(c.width / iw, c.height / ih);
  const dw = iw * s, dh = ih * s;
  x.imageSmoothingQuality = 'high';
  x.drawImage(im, (c.width - dw) / 2, (c.height - dh) / 2, dw, dh);
  im.src = '';
}

function markThumb() {
  if (!el.film) return;
  $$('.thumb.on', el.film).forEach((t) => t.classList.remove('on'));
  const t = el.film.children[state.index];
  if (t) {
    t.classList.add('on');
    const fr = el.film.getBoundingClientRect(), tr = t.getBoundingClientRect();
    const target = el.film.scrollLeft + (tr.left - fr.left) - fr.width / 2 + tr.width / 2;
    el.film.scrollTo({ left: target, behavior: Math.abs(tr.left - fr.left) > fr.width * 2 ? 'auto' : 'smooth' });
  }
}

if (el.film) el.film.addEventListener('wheel', (e) => {
  if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { e.preventDefault(); el.film.scrollLeft += e.deltaY; }
}, { passive: false });

// ------------------------------------------------------------------ panel de información
async function renderInfo() {
  const f = current();
  if (!f) { el.info.innerHTML = '<p class="note">Abre una imagen para ver sus datos.</p>'; return; }
  const ext = extOf(f.path);
  const mp = (state.nat.w * state.nat.h) / 1e6;
  const mdate = new Date(f.mtime).toLocaleString('es-ES', { dateStyle: 'long', timeStyle: 'short' });
  let html = `<div class="info-sec"><div class="info-hero">${esc(f.name)}</div><div class="info-path">${esc(dirName(f.path))}</div>
    <div class="chip-stats"><span>${fmtNum(state.nat.w)} × ${fmtNum(state.nat.h)}</span><span>${mp.toLocaleString('es-ES', { maximumFractionDigits: 1 })} MP</span><span>${fmtBytes(f.size)}</span><span>${formatName(ext)}</span></div>
    <canvas class="hist" id="hist"></canvas></div>`;
  html += `<div class="info-sec"><h4>Fechas</h4><dl class="kv"><dt>Modificada</dt><dd>${mdate}</dd><dt id="taken-dt" hidden>Tomada</dt><dd id="taken-dd" hidden></dd></dl></div>`;
  html += '<div id="exif-slot"></div>';
  el.info.innerHTML = html;
  const token = state.loadToken;
  // histograma
  requestAnimationFrame(() => {
    try {
      if (!el.img.complete || !el.img.naturalWidth) return;
      const hs = Math.min(1, 320 / Math.max(state.nat.w, state.nat.h));
      const src = ImageOps.makeCanvas(state.nat.w * hs, state.nat.h * hs);
      src.getContext('2d').drawImage(el.img, 0, 0, src.width, src.height);
      ImageOps.drawHistogram($('#hist'), ImageOps.histogram(src));
    } catch (_) { /* svg sin dimensiones */ }
  });
  if (!['jpg', 'jpeg', 'jpe', 'jfif', 'webp'].includes(ext)) return;
  try {
    const head = await api.readHead(f.path, 256 * 1024);
    if (token !== state.loadToken) return;
    const ex = Exif.parse(head);
    if (!ex) return;
    const taken = Exif.fmtDate(ex.dateTimeOriginal || ex.dateTime);
    if (taken) { $('#taken-dt').hidden = false; const dd = $('#taken-dd'); dd.hidden = false; dd.textContent = taken; }
    const rows = [];
    const cam = [ex.make, ex.model].filter(Boolean).join(' ').replace(/^(\w+)\s+\1\s/i, '$1 ');
    if (cam) rows.push(['Cámara', cam]);
    if (ex.lensModel) rows.push(['Objetivo', ex.lensModel]);
    if (ex.focalLength) rows.push(['Focal', `${+ex.focalLength.toFixed(1)} mm` + (ex.focalLength35 ? ` (${ex.focalLength35} mm eq.)` : '')]);
    if (ex.fNumber) rows.push(['Apertura', `ƒ/${+ex.fNumber.toFixed(1)}`]);
    if (ex.exposureTime) rows.push(['Exposición', Exif.fmtExposure(ex.exposureTime)]);
    if (ex.iso) rows.push(['ISO', Array.isArray(ex.iso) ? ex.iso[0] : ex.iso]);
    if (ex.exposureBias) rows.push(['Compensación', `${ex.exposureBias > 0 ? '+' : ''}${+ex.exposureBias.toFixed(1)} EV`]);
    if (ex.flash != null) rows.push(['Flash', ex.flash & 1 ? 'Disparado' : 'No disparado']);
    if (ex.software) rows.push(['Software', ex.software]);
    if (ex.artist) rows.push(['Autor', ex.artist]);
    if (ex.copyright) rows.push(['Copyright', ex.copyright]);
    let out = '';
    if (rows.length) out += `<div class="info-sec"><h4>Cámara</h4><dl class="kv">${rows.map(([k, v]) => `<dt>${k}</dt><dd>${esc(String(v))}</dd>`).join('')}</dl></div>`;
    if (ex.gps) {
      const { lat, lon } = ex.gps;
      out += `<div class="info-sec"><h4>Ubicación</h4><dl class="kv"><dt>Coordenadas</dt><dd>${lat.toFixed(5)}, ${lon.toFixed(5)}</dd></dl>
        <button class="link-btn" id="open-map" data-icon="map">Ver en el mapa</button></div>`;
    }
    $('#exif-slot').innerHTML = out;
    hydrateIcons($('#exif-slot'));
    const mb = $('#open-map');
    if (mb) mb.onclick = () => api.openExternal(`https://www.openstreetmap.org/?mlat=${ex.gps.lat}&mlon=${ex.gps.lon}#map=15/${ex.gps.lat}/${ex.gps.lon}`);
  } catch (_) { /* sin EXIF */ }
}
function esc(s) { return s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]); }

// ------------------------------------------------------------------ acciones de archivo
function fileMenuItems() {
  const f = current();
  return [
    { label: 'Editar', icon: 'edit', kbd: 'E', run: enterEdit },
    { label: 'Imprimir…', icon: 'printer', kbd: 'Ctrl+P', run: printFlow },
    '-',
    { label: 'Copiar imagen', icon: 'copy', kbd: 'Ctrl+C', run: copyImage },
    { label: 'Copiar ruta', icon: 'link', run: () => api.copyText(f.path).then(() => toast('Ruta copiada')) },
    { label: 'Renombrar…', icon: 'rename', kbd: 'F2', run: renameCurrent },
    '-',
    { label: 'Usar como fondo de escritorio', icon: 'monitor', run: setWallpaper },
    { label: 'Mostrar en la carpeta', icon: 'folder', run: () => api.showInFolder(f.path) },
    '-',
    { label: 'Mover a la papelera', icon: 'trash', kbd: 'Supr', danger: true, run: trashCurrent },
  ];
}

function moreMenuItems() {
  const p = state.prefs;
  const has = !!current();
  const sortItem = (key, label) => ({ label, checked: p.sortKey === key, run: () => { p.sortKey = key; resort(); } });
  return [
    { label: 'Abrir imagen…', icon: 'image', kbd: 'Ctrl+O', run: openDialog },
    { label: 'Abrir carpeta…', icon: 'folder', kbd: 'Ctrl+Mayús+O', run: openFolderDialog },
    { label: 'Imprimir…', icon: 'printer', kbd: 'Ctrl+P', disabled: !has, run: printFlow },
    '-',
    { label: 'Ordenar por', header: true },
    sortItem('name', 'Nombre'), sortItem('date', 'Fecha de modificación'), sortItem('size', 'Tamaño'),
    { label: p.sortDir > 0 ? 'Orden descendente' : 'Orden ascendente', icon: 'sort', run: () => { p.sortDir *= -1; resort(); } },
    '-',
    { label: 'Cambiar fondo', icon: 'contrast', kbd: 'B', run: cycleBg },
    { label: 'Pantalla completa', icon: 'fullscreen', kbd: 'F11', run: () => api.win.fullscreen() },
    { label: api.nativeFrame ? 'Usar la barra de título de Lienzo' : 'Usar la barra de título del sistema', icon: 'max', run: toggleFrame },
    '-',
    ...(has ? fileMenuItems().filter((it) => it === '-' || (it.label !== 'Editar' && it.label !== 'Imprimir…')).slice(1) : []),
    ...(has ? ['-'] : []),
    { label: 'Atajos de teclado', icon: 'keyboard', kbd: '?', run: showShortcuts },
    { label: 'Acerca de Lienzo', icon: 'info', run: showAbout },
  ];
}

async function toggleFrame() {
  const ok = await confirmModal('Cambiar la barra de título', 'Lienzo se cerrará y se volverá a abrir para aplicar el cambio.', 'Reiniciar Lienzo');
  if (!ok) return;
  state.prefs.customFrame = !!api.nativeFrame;
  await api.setPrefs(state.prefs);
  api.relaunch();
}

async function printFlow() {
  const f = current();
  if (!f) return toast('Abre una imagen para imprimirla');
  const editing = body.classList.contains('editing');
  if (editing && hasPending()) commitPending();
  const w = editing ? edit.base.width : state.nat.w, h = editing ? edit.base.height : state.nat.h;
  const land = w > h;
  const r = await modal(`<h2>Imprimir</h2><p>${esc(f.name)}${editing ? ' (con tus cambios)' : ''}</p>
    <h3 class="modal-h">Tamaño en la hoja</h3>
    <div class="radio-cards">
      <label class="radio-card"><input type="radio" name="fit" value="contain" checked><span class="dot"></span><span><b>Ajustar a la página</b><small>Se ve la imagen entera</small></span></label>
      <label class="radio-card"><input type="radio" name="fit" value="fill"><span class="dot"></span><span><b>Llenar la página</b><small>Ocupa toda la hoja y recorta los bordes que sobren</small></span></label>
    </div>
    <h3 class="modal-h">Orientación</h3>
    <div class="chips" id="print-orient">
      <button data-o="portrait" class="${land ? '' : 'on'}">Vertical</button>
      <button data-o="landscape" class="${land ? 'on' : ''}">Horizontal</button>
    </div>
    <label class="toggle" style="margin-top:16px"><input type="checkbox" id="print-margins" checked><span class="track"></span>Dejar márgenes</label>
    <div class="actions"><button class="btn ghost" data-res="no">Cancelar</button><button class="btn accent" data-res="ok" data-default data-icon="printer"><span>Imprimir…</span></button></div>`);
  if (r !== 'ok') return;
  const fit = (el.modal.querySelector('input[name=fit]:checked') || {}).value || 'contain';
  const landscape = (el.modal.querySelector('#print-orient .on') || {}).dataset?.o === 'landscape';
  const margins = el.modal.querySelector('#print-margins').checked ? 'normal' : 'none';
  const opts = { fit, landscape, margins, title: f.name };
  try {
    setLoading(true);
    if (editing) {
      const blob = await new Promise((res) => edit.base.toBlob(res, 'image/png'));
      opts.data = new Uint8Array(await blob.arrayBuffer());
    } else if (['svg', 'gif', 'ico', 'bmp', 'avif', 'apng'].includes(extOf(f.path))) {
      // Formatos que se imprimen mejor como PNG plano
      const c = ImageOps.makeCanvas(w, h);
      c.getContext('2d').drawImage(el.img, 0, 0, w, h);
      const blob = await new Promise((res) => c.toBlob(res, 'image/png'));
      opts.data = new Uint8Array(await blob.arrayBuffer());
    } else opts.path = f.path;
    setLoading(false);
    const res = await api.print(opts);
    if (res && res.ok) toast('Enviado a la impresora');
    else if (res && res.reason && !/cancel/i.test(res.reason)) toast('No se pudo imprimir: ' + res.reason);
  } catch (e) {
    toast('No se pudo imprimir: ' + (e.message || e));
  } finally { setLoading(false); }
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('#print-orient button');
  if (!b) return;
  $$('#print-orient button').forEach((x) => x.classList.toggle('on', x === b));
});

function resort() {
  sortFiles(); savePrefs(); buildFilmstrip(); updateTitle(); updateNav();
}

async function openDialog() { const p = await api.openDialog(); if (p) openPath(p); }
async function openFolderDialog() { const p = await api.openFolderDialog(); if (p) openPath(p); }

async function copyImage() {
  const f = current(); if (!f) return;
  let ok = false;
  if (['png', 'jpg', 'jpeg', 'jpe', 'jfif'].includes(extOf(f.path))) ok = await api.copyImage(f.path);
  if (!ok) {
    try {
      const c = ImageOps.makeCanvas(state.nat.w, state.nat.h);
      c.getContext('2d').drawImage(el.img, 0, 0, c.width, c.height);
      ok = await api.copyImage(null, c.toDataURL('image/png'));
    } catch (_) { ok = false; }
  }
  toast(ok ? 'Imagen copiada al portapapeles' : 'No se pudo copiar la imagen');
}

async function setWallpaper() {
  const f = current(); if (!f) return;
  const ok = await api.setWallpaper(f.path);
  toast(ok ? 'Fondo de escritorio cambiado' : 'No se pudo cambiar el fondo de escritorio');
}

async function trashCurrent() {
  const f = current(); if (!f) return;
  const ok = await confirmModal('¿Mover a la papelera?', `«${esc(f.name)}» irá a la papelera. Podrás recuperarla desde allí.`, 'Mover a la papelera', true);
  if (!ok) return;
  try {
    await api.trash(f.path);
    const i = state.index;
    state.files.splice(i, 1);
    buildFilmstrip();
    toast('Imagen movida a la papelera');
    if (!state.files.length) { el.img.removeAttribute('src'); showEmpty(true); return; }
    state.index = -1;
    show(Math.min(i, state.files.length - 1), { fade: false });
  } catch (e) { toast('No se pudo mover a la papelera'); }
}

async function renameCurrent() {
  const f = current(); if (!f) return;
  const r = await modal(`<h2>Renombrar</h2><p>Nuevo nombre para el archivo.</p>
    <input type="text" id="rename-in" value="${esc(f.name)}" spellcheck="false">
    <div class="actions"><button class="btn ghost" data-res="no">Cancelar</button><button class="btn accent" data-res="ok" data-default>Renombrar</button></div>`);
  if (r !== 'ok') return;
  const name = $('#rename-in').value.trim();
  if (!name || name === f.name) return;
  try {
    const np = await api.rename(f.path, name);
    f.path = np; f.name = name;
    sortFiles(); buildFilmstrip(); updateTitle();
    if (body.classList.contains('info-open')) renderInfo();
    toast('Archivo renombrado');
  } catch (e) { toast(String(e.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '')); }
}
// Seleccionar sólo el nombre sin extensión al renombrar
document.addEventListener('focusin', (e) => {
  if (e.target.id === 'rename-in') {
    const v = e.target.value, dot = v.lastIndexOf('.');
    setTimeout(() => e.target.setSelectionRange(0, dot > 0 ? dot : v.length), 0);
  }
});

async function showAbout() {
  const v = await api.version();
  modal(`<h2>Lienzo ${esc(v)}</h2><p>Visor y editor de imágenes para Linux.</p>
    <div class="actions"><button class="btn accent" data-res="ok" data-default>Cerrar</button></div>`);
}

function showShortcuts() {
  const rows = [
    ['Imagen anterior / siguiente', '← →'], ['Primera / última', 'Inicio Fin'], ['Acercar / alejar', '+ −'],
    ['Ajustar a la ventana', '0'], ['Tamaño real', '1'], ['Girar vista', 'R'], ['Información', 'I'],
    ['Editar', 'E'], ['Presentación', 'F5'], ['Pantalla completa', 'F11'],
    ['Cambiar fondo', 'B'], ['Copiar imagen', 'Ctrl+C'], ['Renombrar', 'F2'], ['Papelera', 'Supr'],
    ['Abrir', 'Ctrl+O'], ['Imprimir', 'Ctrl+P'], ['Deshacer / rehacer (editor)', 'Ctrl+Z  Ctrl+Y'], ['Guardar (editor)', 'Ctrl+S'],
    ['Ver original (editor)', '\\'], ['Aplicar cambios (editor)', 'Intro'],
  ];
  modal(`<h2>Atajos de teclado</h2><p>Para moverte por Lienzo sin soltar el teclado.</p>
    <div class="shortcuts">${rows.map(([a, k]) => `<div><span>${a}</span><kbd>${k}</kbd></div>`).join('')}</div>
    <div class="actions"><button class="btn accent" data-res="ok" data-default>Entendido</button></div>`, { wide: true });
}

// ------------------------------------------------------------------ presentación y pantalla completa
function startSlideshow() {
  if (!state.files.length || body.classList.contains('editing')) return;
  body.classList.add('slideshow');
  $('#btn-slideshow').innerHTML = icon('pause');
  $('#btn-slideshow').title = 'Detener presentación (Esc)';
  api.win.fullscreen(true);
  const dur = state.prefs.slideSec * 1000;
  const bar = $('#slide-progress span');
  let t0 = performance.now(), paused = false, pausedAt = 0;
  const tick = (now) => {
    if (!state.slideshow) return;
    if (!paused) {
      const p = (now - t0) / dur;
      bar.style.width = Math.min(100, p * 100) + '%';
      if (p >= 1) {
        t0 = now;
        show(state.index + 1 >= state.files.length ? 0 : state.index + 1, { fade: true });
      }
    }
    state.slideshow.raf = requestAnimationFrame(tick);
  };
  state.slideshow = {
    raf: requestAnimationFrame(tick),
    toggle() { paused = !paused; if (paused) pausedAt = performance.now(); else t0 += performance.now() - pausedAt; toast(paused ? 'Presentación en pausa' : 'Presentación reanudada'); },
    restart() { t0 = performance.now(); },
  };
}
function stopSlideshow() {
  if (!state.slideshow) return;
  cancelAnimationFrame(state.slideshow.raf);
  state.slideshow = null;
  body.classList.remove('slideshow');
  $('#btn-slideshow').innerHTML = icon('play');
  $('#btn-slideshow').title = 'Presentación (F5)';
  api.win.fullscreen(false);
}

let chromeTimer = null;
document.addEventListener('mousemove', (e) => {
  if (!state.fullscreen) return;
  body.classList.add('chrome');
  clearTimeout(chromeTimer);
  const overUi = e.target.closest && e.target.closest('.titlebar, .filmstrip, .zoom-pill, .menu');
  if (!overUi) chromeTimer = setTimeout(() => body.classList.remove('chrome'), 2200);
});

api.on('window-state', (s) => {
  const wasFs = state.fullscreen;
  state.fullscreen = s.fullscreen;
  body.classList.toggle('fullscreen', s.fullscreen);
  body.classList.toggle('chrome', false);
  $('#wc-max').innerHTML = icon(s.maximized ? 'restore' : 'max');
  $('#wc-max').title = s.maximized ? 'Restaurar' : 'Maximizar';
  if (wasFs && !s.fullscreen && state.slideshow) stopSlideshow();
  setTimeout(() => { if (state.view.mode === 'fit' && state.nat.w) fitView(false); }, 60);
});

// ------------------------------------------------------------------ arrastrar y soltar
let dragDepth = 0;
window.addEventListener('dragenter', (e) => { if (e.dataTransfer.types.includes('Files')) { dragDepth++; $('#drop-veil').classList.add('on'); } });
window.addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) $('#drop-veil').classList.remove('on'); });
window.addEventListener('dragover', (e) => e.preventDefault());
window.addEventListener('drop', (e) => {
  e.preventDefault(); dragDepth = 0; $('#drop-veil').classList.remove('on');
  if (body.classList.contains('editing')) { toast('Termina o cancela la edición antes de abrir otra imagen'); return; }
  const f = e.dataTransfer.files[0];
  if (!f) return;
  const p = api.pathForFile(f);
  if (p) openPath(p);
});

// =================================================================== EDITOR
const edit = {
  base: null, history: [], hi: 0, tab: 'adjust',
  previewLo: null, previewHi: null,
  params: ImageOps.neutral(), look: 'none', strength: 1,
  crop: null, ratio: 'free', angle: 0,
  objects: [], tool: 'pen', color: '#f0b354', size: 6, fill: false, shadow: true,
  drawing: null, cropDrag: null, renderQueued: false, comparing: false,
};

const SWATCHES = ['#f0b354', '#ef6a5b', '#f4f1ea', '#1f2125', '#5fb8ff', '#6fd08c', '#c58bff', '#ffd84d'];

function buildEditorUi() {
  // ajustes
  const wrap = $('#adjust-groups');
  wrap.innerHTML = ImageOps.ADJUST.map((g) => `<div class="adj-group"><h3>${g.group}<button data-reset-group="${g.group}">Restablecer</button></h3>
    ${g.items.map((it) => `<div class="field slider-field ${it.cls || ''}" data-key="${it.key}">
      <div class="sl-head"><label for="adj-${it.key}">${it.label}</label><output title="Doble clic para restablecer">0${it.unit || ''}</output></div>
      <input type="range" id="adj-${it.key}" min="${it.min}" max="${it.max}" value="0" step="1"></div>`).join('')}</div>`).join('');
  $$('.slider-field[data-key]', wrap).forEach((f) => {
    const key = f.dataset.key, inp = $('input', f), out = $('output', f), unit = ImageOps.RANGE[key].unit || '';
    const set = (v) => { inp.value = v; edit.params[key] = +v; out.textContent = (v > 0 && ImageOps.RANGE[key].min < 0 ? '+' : '') + v + unit; f.classList.toggle('changed', +v !== 0); paintRange(inp); };
    f._set = set;
    inp.addEventListener('input', () => { set(+inp.value); markPending('adjust'); queueRender(); });
    const reset = () => { set(0); markPending('adjust'); queueRender(); };
    out.addEventListener('dblclick', reset);
    $('label', f).addEventListener('dblclick', reset);
    inp.addEventListener('dblclick', reset);
  });
  $$('[data-reset-group]', wrap).forEach((b) => b.onclick = () => {
    const g = ImageOps.ADJUST.find((x) => x.group === b.dataset.resetGroup);
    g.items.forEach((it) => $(`.slider-field[data-key="${it.key}"]`)._set(0));
    markPending('adjust'); queueRender();
  });

  // filtros
  $('#looks-grid').innerHTML = ImageOps.LOOKS.map((l) => `<button class="look" data-look="${l.id}"><canvas width="160" height="160"></canvas><span>${l.name}</span></button>`).join('');
  $$('.look').forEach((b) => b.onclick = () => {
    edit.look = b.dataset.look;
    $$('.look').forEach((x) => x.classList.toggle('on', x === b));
    $('#look-strength-row').style.visibility = edit.look === 'none' ? 'hidden' : 'visible';
    markPending('looks'); queueRender();
  });
  const ls = $('#look-strength');
  ls.oninput = () => { edit.strength = ls.value / 100; $('#look-strength-out').textContent = ls.value; paintRange(ls); markPending('looks'); queueRender(); };

  // recorte
  $$('#ratio-chips button').forEach((b) => b.onclick = () => {
    $$('#ratio-chips button').forEach((x) => x.classList.toggle('on', x === b));
    edit.ratio = b.dataset.ratio;
    applyRatio();
  });
  const st = $('#straighten');
  st.oninput = () => { edit.angle = +st.value; $('#straighten-out').textContent = `${(+st.value).toFixed(1).replace('.', ',')}°`; paintRange(st, true); updateStraighten(); markPending('crop'); };
  st.ondblclick = () => { st.value = 0; st.oninput(); };
  $('#rot-l').onclick = () => geometry((c) => ImageOps.rotate90(c, -1));
  $('#rot-r').onclick = () => geometry((c) => ImageOps.rotate90(c, 1));
  $('#flip-h').onclick = () => geometry((c) => ImageOps.flip(c, true));
  $('#flip-v').onclick = () => geometry((c) => ImageOps.flip(c, false));
  $('#crop-reset').onclick = () => { resetCropState(); $$('#ratio-chips button').forEach((x) => x.classList.toggle('on', x.dataset.ratio === 'free')); edit.ratio = 'free'; renderCrop(); updatePendingFoot(); };

  // dibujo
  $$('#draw-tools button').forEach((b) => b.onclick = () => {
    edit.tool = b.dataset.tool;
    $$('#draw-tools button').forEach((x) => x.classList.toggle('on', x === b));
    commitTextEntry();
    applyView(false);
  });
  const sw = $('#swatches');
  sw.innerHTML = SWATCHES.map((c) => `<button class="swatch" data-color="${c}" style="background:${c}" title="${c}"></button>`).join('') +
    '<label class="swatch custom" title="Otro color"><input type="color" id="custom-color" value="#f0b354"></label>';
  const pick = (c, btn) => { edit.color = c; $$('.swatch', sw).forEach((x) => x.classList.toggle('on', x === btn)); el.textEntry.style.color = c; };
  $$('.swatch[data-color]', sw).forEach((b) => b.onclick = () => pick(b.dataset.color, b));
  $('#custom-color').oninput = (e) => pick(e.target.value, e.target.parentElement);
  pick(edit.color, $('.swatch', sw));
  const ds = $('#draw-size');
  ds.oninput = () => { edit.size = +ds.value; $('#draw-size-out').textContent = ds.value; paintRange(ds); };
  paintRange(ds);
  $('#draw-fill').onchange = (e) => { edit.fill = e.target.checked; };
  $('#draw-shadow').onchange = (e) => { edit.shadow = e.target.checked; };

  // tamaño
  const sw_ = $('#size-w'), sh_ = $('#size-h'), lock = $('#size-lock');
  let locked = true;
  lock.onclick = () => { locked = !locked; lock.classList.toggle('on', locked); lock.innerHTML = icon(locked ? 'lock' : 'unlock'); };
  const ratio = () => edit.base.width / edit.base.height;
  sw_.oninput = () => { if (locked && sw_.value) sh_.value = Math.max(1, Math.round(sw_.value / ratio())); sizeNote(); };
  sh_.oninput = () => { if (locked && sh_.value) sw_.value = Math.max(1, Math.round(sh_.value * ratio())); sizeNote(); };
  $$('#size-chips button').forEach((b) => b.onclick = () => {
    const W = edit.base.width, H = edit.base.height;
    let s = b.dataset.scale ? +b.dataset.scale : +b.dataset.long / Math.max(W, H);
    sw_.value = Math.max(1, Math.round(W * s)); sh_.value = Math.max(1, Math.round(H * s)); sizeNote();
  });
  $('#size-apply').onclick = () => {
    const w = parseInt(sw_.value, 10), h = parseInt(sh_.value, 10);
    if (!(w > 0 && h > 0)) return toast('Escribe un ancho y un alto válidos');
    if (w > 20000 || h > 20000) return toast('El tamaño máximo es 20 000 px por lado');
    if (w === edit.base.width && h === edit.base.height) return;
    pushHistory(ImageOps.resize(edit.base, w, h));
    toast(`Nuevo tamaño: ${fmtNum(w)} × ${fmtNum(h)} px`);
  };

  // pestañas y pie
  $$('#tool-tabs button').forEach((b) => b.onclick = () => selectTab(b.dataset.tab));
  $('#pending-apply').onclick = () => commitPending();
  $('#pending-discard').onclick = () => discardPending();
}

function sizeNote() {
  const w = +$('#size-w').value, h = +$('#size-h').value;
  const W = edit.base.width, H = edit.base.height;
  $('#size-note').textContent = w && h ? `Actual: ${fmtNum(W)} × ${fmtNum(H)} px. Nuevo: ${((w * h) / 1e6).toLocaleString('es-ES', { maximumFractionDigits: 1 })} MP (${Math.round((w / W) * 100)} %).` : '';
}

function paintRange(inp, centered) {
  const min = +inp.min, max = +inp.max, v = +inp.value;
  const pct = ((v - min) / (max - min)) * 100;
  const zero = min < 0 ? ((0 - min) / (max - min)) * 100 : 0;
  inp.style.setProperty('--fill-from', Math.min(pct, zero) + '%');
  inp.style.setProperty('--fill-to', Math.max(pct, zero) + '%');
}

function enterEdit() {
  const f = current();
  if (!f || body.classList.contains('editing')) return;
  if (!el.img.naturalWidth) return toast('Esta imagen no se puede editar');
  if (state.slideshow) stopSlideshow();
  let base;
  try {
    base = ImageOps.fromImage(el.img);
    base.getContext('2d').getImageData(0, 0, 1, 1);
  } catch (e) { return toast('Esta imagen no se puede editar'); }
  if (extOf(f.path) === 'svg') {
    // rasteriza SVG a un tamaño razonable
    const s = Math.max(1, 2048 / Math.max(base.width, base.height));
    if (s > 1) { base = ImageOps.makeCanvas(base.width * s, base.height * s); base.getContext('2d').drawImage(el.img, 0, 0, base.width, base.height); }
  }
  body.classList.add('editing');
  closeMenu();
  edit.history = [base]; edit.hi = 0;
  state.view.rot = 0;
  setBase(base, true);
  selectTab('adjust', true);
  updateUndo();
}

async function exitEdit(force) {
  if (!body.classList.contains('editing')) return;
  if (!force && (edit.hi > 0 || hasPending())) {
    const ok = await confirmModal('¿Descartar los cambios?', 'Has editado la imagen y no lo has guardado. Si sales ahora se perderán los cambios.', 'Descartar cambios', true);
    if (!ok) return;
  }
  commitTextEntry(true);
  body.classList.remove('editing', 'tab-crop', 'tab-draw');
  el.foot.classList.remove('on');
  edit.base = null; edit.history = []; edit.previewLo = edit.previewHi = null; edit.objects = [];
  el.canvas.width = el.canvas.height = 1;
  el.canvas.style.transform = '';
  state.nat = { w: el.img.naturalWidth || state.nat.w, h: el.img.naturalHeight || state.nat.h };
  setContentSize(state.nat.w, state.nat.h);
  fitView(false);
}

function setBase(c, initial) {
  edit.base = c;
  edit.previewHi = ImageOps.fitWithin(c, 3000);
  edit.previewLo = ImageOps.fitWithin(c, 1500);
  const dimsChanged = state.nat.w !== c.width || state.nat.h !== c.height;
  state.nat = { w: c.width, h: c.height };
  setContentSize(c.width, c.height);
  edit.params = ImageOps.neutral();
  $$('.slider-field[data-key]').forEach((f) => f._set && f._set(0));
  edit.look = 'none'; edit.strength = 1;
  $('#look-strength').value = 100; $('#look-strength-out').textContent = '100'; paintRange($('#look-strength'));
  $$('.look').forEach((x) => x.classList.toggle('on', x.dataset.look === 'none'));
  $('#look-strength-row').style.visibility = 'hidden';
  edit.objects = []; renderDrawLayer();
  resetCropState();
  edit.pending = null;
  $('#size-w').value = c.width; $('#size-h').value = c.height; sizeNote();
  if (edit.tab === 'looks') renderLookThumbs();
  renderEditCanvas();
  renderCrop();
  updatePendingFoot();
  if (initial || dimsChanged || state.view.mode === 'fit') fitView(!initial);
  updateTitleEditing();
}

function updateTitleEditing() {
  const f = current();
  if (!f || !edit.base) return;
  el.title.textContent = f.name;
  el.meta.innerHTML = `<span>Editando</span><span class="gap"></span><span>${fmtNum(edit.base.width)} × ${fmtNum(edit.base.height)}</span>`;
}

function pushHistory(c) {
  edit.history = edit.history.slice(0, edit.hi + 1);
  edit.history.push(c);
  if (edit.history.length > 14) edit.history.splice(1, 1); // conserva siempre el original
  edit.hi = edit.history.length - 1;
  setBase(c);
  updateUndo();
}

function updateUndo() {
  $('#btn-undo').disabled = !(edit.hi > 0 || hasPending());
  $('#btn-redo').disabled = !(edit.hi < edit.history.length - 1);
}

function undo() {
  if (edit.tab === 'draw' && edit.objects.length) { edit.objects.pop(); renderDrawLayer(); updatePendingFoot(); return; }
  if (hasPending()) { discardPending(); return; }
  if (edit.hi > 0) { edit.hi--; setBase(edit.history[edit.hi]); updateUndo(); }
}
function redo() {
  if (edit.hi < edit.history.length - 1) { edit.hi++; setBase(edit.history[edit.hi]); updateUndo(); }
}

function selectTab(tab, initial) {
  if (!initial && tab === edit.tab) return;
  if (!initial && hasPending()) commitPending();
  commitTextEntry();
  edit.tab = tab;
  $$('#tool-tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  $$('.tab').forEach((p) => p.classList.toggle('on', p.dataset.pane === tab));
  body.classList.toggle('tab-crop', tab === 'crop');
  body.classList.toggle('tab-draw', tab === 'draw');
  if (tab === 'looks') renderLookThumbs();
  if (tab === 'crop') renderCrop();
  if (tab === 'size') { $('#size-w').value = edit.base.width; $('#size-h').value = edit.base.height; sizeNote(); }
  renderEditCanvas();
  applyView(false);
}

// ---- estado pendiente
function hasPending() {
  if (!edit.base) return false;
  if (edit.tab === 'adjust') return !ImageOps.isNeutral(edit.params);
  if (edit.tab === 'looks') return edit.look !== 'none';
  if (edit.tab === 'crop') return !!edit.angle || !isFullCrop();
  if (edit.tab === 'draw') return edit.objects.length > 0;
  return false;
}
function markPending() { updatePendingFoot(); }
function updatePendingFoot() {
  const on = hasPending();
  el.foot.classList.toggle('on', on);
  el.footLabel.textContent = ({ adjust: 'Ajustes sin aplicar', looks: 'Filtro sin aplicar', crop: 'Recorte sin aplicar', draw: `${edit.objects.length} ${edit.objects.length === 1 ? 'trazo' : 'trazos'} sin aplicar` })[edit.tab] || '';
  updateUndo();
}

function commitPending() {
  if (!hasPending()) return;
  commitTextEntry();
  const b = edit.base;
  let out = null;
  setLoading(true);
  try {
    if (edit.tab === 'adjust') out = ImageOps.process(b, ImageOps.combine(edit.params, null, 0));
    else if (edit.tab === 'looks') out = ImageOps.process(b, ImageOps.combine({}, ImageOps.LOOKS.find((l) => l.id === edit.look), edit.strength));
    else if (edit.tab === 'crop') {
      out = ImageOps.straighten(b, edit.angle);
      if (!isFullCrop()) out = ImageOps.crop(out, edit.crop);
    } else if (edit.tab === 'draw') {
      out = ImageOps.clone(b);
      ImageOps.drawObjects(out, edit.objects, 1);
    }
  } finally { setLoading(false); }
  if (out) pushHistory(out);
}

function discardPending() {
  if (edit.tab === 'adjust') { $$('.slider-field[data-key]').forEach((f) => f._set(0)); }
  if (edit.tab === 'looks') { edit.look = 'none'; $$('.look').forEach((x) => x.classList.toggle('on', x.dataset.look === 'none')); $('#look-strength-row').style.visibility = 'hidden'; }
  if (edit.tab === 'crop') { resetCropState(); renderCrop(); }
  if (edit.tab === 'draw') { edit.objects = []; renderDrawLayer(); }
  renderEditCanvas();
  updatePendingFoot();
}

function geometry(fn) {
  if (hasPending()) commitPending();
  pushHistory(fn(edit.base));
}

// ---- render del lienzo de edición
function queueRender() {
  if (edit.renderQueued) return;
  edit.renderQueued = true;
  requestAnimationFrame(() => { edit.renderQueued = false; renderEditCanvas(); });
}

function renderEditCanvas() {
  if (!edit.base) return;
  let src;
  if (edit.comparing) src = ImageOps.fitWithin(edit.history[0], 3000);
  else if (edit.tab === 'adjust' && !ImageOps.isNeutral(edit.params)) src = ImageOps.process(edit.previewLo, ImageOps.combine(edit.params, null, 0));
  else if (edit.tab === 'looks' && edit.look !== 'none') src = ImageOps.process(edit.previewLo, ImageOps.combine({}, ImageOps.LOOKS.find((l) => l.id === edit.look), edit.strength));
  else src = edit.previewHi;
  const c = el.canvas;
  if (c.width !== src.width || c.height !== src.height) { c.width = src.width; c.height = src.height; }
  const x = c.getContext('2d');
  x.clearRect(0, 0, c.width, c.height);
  x.imageSmoothingQuality = 'high';
  x.drawImage(src, 0, 0, c.width, c.height);
  updateStraighten();
}

function renderLookThumbs() {
  if (!edit.base) return;
  const s = 160;
  const sq = ImageOps.makeCanvas(s, s);
  const b = edit.previewLo;
  const m = Math.min(b.width, b.height);
  const sx = sq.getContext('2d'); sx.imageSmoothingQuality = 'high';
  sx.drawImage(b, (b.width - m) / 2, (b.height - m) / 2, m, m, 0, 0, s, s);
  ImageOps.LOOKS.forEach((l) => {
    const cv = $(`.look[data-look="${l.id}"] canvas`);
    const out = ImageOps.process(sq, ImageOps.combine({}, l, 1));
    cv.getContext('2d').drawImage(out, 0, 0);
  });
}

// compara con el original
function setCompare(on) {
  if (!body.classList.contains('editing') || edit.comparing === on) return;
  edit.comparing = on;
  $('#btn-compare').classList.toggle('on', on);
  const ref = on ? edit.history[0] : edit.base;
  state.nat = { w: ref.width, h: ref.height };
  setContentSize(ref.width, ref.height);
  body.classList.toggle('comparing', on);
  if (on) { el.draw.style.visibility = 'hidden'; el.crop.style.visibility = 'hidden'; el.canvas.style.transform = ''; }
  else { el.draw.style.visibility = ''; el.crop.style.visibility = ''; }
  renderEditCanvas();
  fitView(false);
}
const cmp = $('#btn-compare');
cmp.addEventListener('pointerdown', () => setCompare(true));
cmp.addEventListener('pointerup', () => setCompare(false));
cmp.addEventListener('pointerleave', () => setCompare(false));

// ---- recorte
function resetCropState() {
  if (!edit.base) return;
  edit.crop = { x: 0, y: 0, w: edit.base.width, h: edit.base.height };
  edit.angle = 0;
  const st = $('#straighten'); st.value = 0; $('#straighten-out').textContent = '0°'; paintRange(st);
  if (edit.ratio !== 'free') applyRatio(true);
  updateStraighten();
}
function isFullCrop() {
  const c = edit.crop, b = edit.base;
  return !c || (Math.round(c.x) <= 0 && Math.round(c.y) <= 0 && Math.round(c.w) >= b.width && Math.round(c.h) >= b.height);
}
function ratioValue() {
  if (edit.ratio === 'free') return null;
  if (edit.ratio === 'orig') return edit.base.width / edit.base.height;
  return +edit.ratio;
}
function applyRatio(silent) {
  const r = ratioValue();
  const W = edit.base.width, H = edit.base.height;
  if (r) {
    let w = W, h = W / r;
    if (h > H) { h = H; w = H * r; }
    const c = edit.crop || { x: 0, y: 0, w: W, h: H };
    const cx = c.x + c.w / 2, cy = c.y + c.h / 2;
    edit.crop = { x: clamp(cx - w / 2, 0, W - w), y: clamp(cy - h / 2, 0, H - h), w, h };
  }
  if (!silent) { renderCrop(); updatePendingFoot(); }
}
function renderCrop() {
  if (!edit.base || !edit.crop) return;
  const { x, y, w, h } = edit.crop, W = edit.base.width, H = edit.base.height;
  Object.assign(el.crop.style, { left: (x / W) * 100 + '%', top: (y / H) * 100 + '%', width: (w / W) * 100 + '%', height: (h / H) * 100 + '%' });
  el.cropSize.textContent = `${fmtNum(w)} × ${fmtNum(h)}`;
}
function updateStraighten() {
  if (edit.tab !== 'crop' || !edit.base || edit.comparing) { el.canvas.style.transform = ''; return; }
  const k = ImageOps.coverScale(edit.base.width, edit.base.height, edit.angle);
  el.canvas.style.transform = edit.angle ? `rotate(${edit.angle}deg) scale(${k})` : '';
  el.content.style.overflow = edit.angle ? 'hidden' : '';
}

el.crop.addEventListener('pointerdown', (e) => {
  if (e.button !== 0) return;
  e.preventDefault(); e.stopPropagation();
  const h = e.target.dataset.h || 'move';
  const p = stageToImage(e.clientX, e.clientY);
  edit.cropDrag = { h, p0: p, r0: { ...edit.crop }, id: e.pointerId };
  el.crop.setPointerCapture(e.pointerId);
  el.crop.classList.add('active');
});
el.crop.addEventListener('pointermove', (e) => {
  const d = edit.cropDrag;
  if (!d || d.id !== e.pointerId) return;
  const p = stageToImage(e.clientX, e.clientY);
  const dx = p.x - d.p0.x, dy = p.y - d.p0.y;
  const W = edit.base.width, H = edit.base.height, r0 = d.r0;
  if (d.h === 'move') {
    edit.crop = { ...r0, x: clamp(r0.x + dx, 0, W - r0.w), y: clamp(r0.y + dy, 0, H - r0.h) };
  } else {
    const minS = Math.max(8, 24 / state.view.s);
    const hw = d.h.includes('w'), he = d.h.includes('e'), hn = d.h.includes('n'), hs = d.h.includes('s');
    let w = r0.w + (he ? dx : hw ? -dx : 0);
    let h = r0.h + (hs ? dy : hn ? -dy : 0);
    w = Math.max(minS, w); h = Math.max(minS, h);
    const ratio = ratioValue();
    if (ratio) {
      if ((hw || he) && (hn || hs)) { if (w / h > ratio) h = w / ratio; else w = h * ratio; }
      else if (hw || he) h = w / ratio;
      else w = h * ratio;
    }
    // anclas
    const ax = hw ? r0.x + r0.w : he ? r0.x : r0.x + r0.w / 2;
    const ay = hn ? r0.y + r0.h : hs ? r0.y : r0.y + r0.h / 2;
    const maxW = hw ? ax : he ? W - ax : 2 * Math.min(ax, W - ax);
    const maxH = hn ? ay : hs ? H - ay : 2 * Math.min(ay, H - ay);
    if (ratio) {
      const f = Math.min(1, maxW / w, maxH / h);
      w *= f; h *= f;
    } else { w = Math.min(w, maxW); h = Math.min(h, maxH); }
    const x = hw ? ax - w : he ? ax : ax - w / 2;
    const y = hn ? ay - h : hs ? ay : ay - h / 2;
    edit.crop = { x, y, w, h };
  }
  renderCrop();
});
const endCrop = (e) => {
  if (!edit.cropDrag) return;
  edit.cropDrag = null;
  el.crop.classList.remove('active');
  updatePendingFoot();
};
el.crop.addEventListener('pointerup', endCrop);
el.crop.addEventListener('pointercancel', endCrop);

// ---- dibujo
function toolCursor() { return body.classList.contains('editing') && edit.tab === 'draw'; }
function strokeW() { return Math.max(1, edit.size * ImageOps.unitFor(edit.base.width, edit.base.height)); }

function editorPointerDown(e) {
  if (!body.classList.contains('editing') || edit.tab !== 'draw' || edit.comparing) return false;
  const p = stageToImage(e.clientX, e.clientY);
  const w = strokeW();
  const base = { color: edit.color, w, shadow: edit.shadow };
  if (edit.tool === 'text') {
    commitTextEntry();
    setTimeout(() => openTextEntry(p), 0);
    return true;
  }
  let o;
  if (edit.tool === 'pen' || edit.tool === 'marker') o = { ...base, type: edit.tool, pts: [[p.x, p.y]] };
  else if (edit.tool === 'line' || edit.tool === 'arrow') o = { ...base, type: edit.tool, x1: p.x, y1: p.y, x2: p.x, y2: p.y };
  else if (edit.tool === 'rect' || edit.tool === 'ellipse') o = { ...base, type: edit.tool, x: p.x, y: p.y, w2: 0, h2: 0, fill: edit.fill, ox: p.x, oy: p.y };
  else if (edit.tool === 'pixel') o = { type: 'pixel', x: p.x, y: p.y, w: 0, h: 0, ox: p.x, oy: p.y };
  edit.drawing = { o, id: e.pointerId, shift: e.shiftKey };
  edit.objects.push(o);
  el.stage.setPointerCapture(e.pointerId);
  renderDrawLayer();
  return true;
}
function editorPointerMove(e) {
  const d = edit.drawing;
  if (!d || d.id !== e.pointerId) return false;
  const o = d.o;
  let p = stageToImage(e.clientX, e.clientY);
  if (o.type === 'pen' || o.type === 'marker') {
    const last = o.pts[o.pts.length - 1];
    if (Math.hypot(p.x - last[0], p.y - last[1]) > 1.5 / state.view.s) o.pts.push([p.x, p.y]);
  } else if (o.type === 'line' || o.type === 'arrow') {
    if (e.shiftKey) {
      const ang = Math.round(Math.atan2(p.y - o.y1, p.x - o.x1) / (Math.PI / 4)) * (Math.PI / 4);
      const len = Math.hypot(p.x - o.x1, p.y - o.y1);
      p = { x: o.x1 + Math.cos(ang) * len, y: o.y1 + Math.sin(ang) * len };
    }
    o.x2 = p.x; o.y2 = p.y;
  } else {
    let w = p.x - o.ox, h = p.y - o.oy;
    if (e.shiftKey) { const m = Math.max(Math.abs(w), Math.abs(h)); w = Math.sign(w || 1) * m; h = Math.sign(h || 1) * m; }
    const nx = w < 0 ? o.ox + w : o.ox, ny = h < 0 ? o.oy + h : o.oy;
    if (o.type === 'pixel') { o.x = nx; o.y = ny; o.w = Math.abs(w); o.h = Math.abs(h); o._preview = null; }
    else { o.x = nx; o.y = ny; o.w2 = Math.abs(w); o.h2 = Math.abs(h); }
  }
  renderDrawLayer();
  return true;
}
function editorPointerUp(e) {
  const d = edit.drawing;
  if (!d || d.id !== e.pointerId) return false;
  edit.drawing = null;
  const o = d.o;
  const tiny = (o.type === 'pixel' && (o.w < 4 || o.h < 4)) || ((o.type === 'rect' || o.type === 'ellipse') && (o.w2 < 3 || o.h2 < 3)) ||
    ((o.type === 'line' || o.type === 'arrow') && Math.hypot(o.x2 - o.x1, o.y2 - o.y1) < 3);
  if (tiny) edit.objects.pop();
  renderDrawLayer();
  updatePendingFoot();
  return true;
}

const SVGNS = 'http://www.w3.org/2000/svg';
function renderDrawLayer() {
  const svg = el.draw;
  if (!edit.base) { svg.innerHTML = ''; return; }
  const parts = ['<defs><filter id="sh" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="SHY" stdDeviation="SHB" flood-color="#000" flood-opacity=".45"/></filter></defs>'];
  for (const o of edit.objects) {
    const f = o.shadow ? ` filter="url(#sh${shadowId(o)})"` : '';
    if (o.type === 'pen' || o.type === 'marker') {
      const mk = o.type === 'marker';
      parts.push(`<path d="${ImageOps.smoothPath(o.pts)}" fill="none" stroke="${o.color}" stroke-width="${mk ? o.w * 3.2 : o.w}" stroke-linecap="${mk ? 'butt' : 'round'}" stroke-linejoin="round" ${mk ? 'opacity=".42"' : f}/>`);
    } else if (o.type === 'line' || o.type === 'arrow') {
      let s = `<g${f} stroke="${o.color}" stroke-width="${o.w}" stroke-linecap="round" stroke-linejoin="round" fill="none"><line x1="${o.x1}" y1="${o.y1}" x2="${o.x2}" y2="${o.y2}"/>`;
      if (o.type === 'arrow') { const hd = ImageOps.arrowHead(o); s += `<polyline points="${hd.map((q) => q.join(',')).join(' ')}"/>`; }
      parts.push(s + '</g>');
    } else if (o.type === 'rect') {
      const r = Math.min(o.w * 1.2, o.w2 / 2, o.h2 / 2);
      parts.push(`<g${f}>${o.fill ? `<rect x="${o.x}" y="${o.y}" width="${o.w2}" height="${o.h2}" rx="${r}" fill="${o.color}" opacity=".35"/>` : ''}<rect x="${o.x}" y="${o.y}" width="${o.w2}" height="${o.h2}" rx="${r}" fill="none" stroke="${o.color}" stroke-width="${o.w}"/></g>`);
    } else if (o.type === 'ellipse') {
      parts.push(`<g${f}><ellipse cx="${o.x + o.w2 / 2}" cy="${o.y + o.h2 / 2}" rx="${o.w2 / 2}" ry="${o.h2 / 2}" fill="${o.fill ? o.color : 'none'}" fill-opacity=".35" stroke="${o.color}" stroke-width="${o.w}"/></g>`);
    } else if (o.type === 'text') {
      parts.push(`<text x="${o.x}" y="${o.y}" fill="${o.color}" font-size="${o.size}" font-weight="700" font-family="LienzoInter, Inter, sans-serif" dominant-baseline="hanging"${f}>${esc(o.text)}</text>`);
    } else if (o.type === 'pixel') {
      if (o.w < 2 || o.h < 2) continue;
      if (!o._preview) {
        const ps = edit.previewHi.width / edit.base.width;
        const px = ImageOps.pixelateRegion(edit.previewHi, { x: o.x * ps, y: o.y * ps, w: o.w * ps, h: o.h * ps }, Math.max(2, ImageOps.pixelBlock(edit.base.width, edit.base.height) * ps));
        o._preview = px ? { url: px.canvas.toDataURL(), x: px.x / ps, y: px.y / ps, w: px.canvas.width / ps, h: px.canvas.height / ps } : null;
      }
      if (o._preview) {
        const q = o._preview;
        parts.push(`<image href="${q.url}" x="${q.x}" y="${q.y}" width="${q.w}" height="${q.h}" preserveAspectRatio="none" style="image-rendering:pixelated"/>`);
      } else parts.push(`<rect x="${o.x}" y="${o.y}" width="${o.w}" height="${o.h}" fill="rgba(240,179,84,.25)" stroke="#f0b354" stroke-dasharray="6"/>`);
    }
  }
  // filtros de sombra por grosor
  const ws = [...new Set(edit.objects.filter((o) => o.shadow && o.type !== 'pixel').map((o) => shadowId(o)))];
  parts[0] = '<defs>' + ws.map((id) => { const w = +id / 10; return `<filter id="sh${id}" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="${Math.max(1, w * 0.35)}" stdDeviation="${Math.max(1, w * 0.6)}" flood-color="#000" flood-opacity=".45"/></filter>`; }).join('') + '</defs>';
  svg.innerHTML = parts.join('');
}
function shadowId(o) { return Math.round((o.type === 'text' ? o.size / 5 : o.w) * 10); }

function openTextEntry(p) {
  const t = el.textEntry;
  t.value = '';
  t.dataset.x = p.x; t.dataset.y = p.y;
  t.classList.add('on');
  t.style.color = edit.color;
  positionTextEntry();
  setTimeout(() => t.focus(), 0);
}
function positionTextEntry() {
  const t = el.textEntry;
  if (!t.classList.contains('on')) return;
  const r = el.content.getBoundingClientRect(), sr = el.stage.getBoundingClientRect();
  const x = r.left - sr.left + (+t.dataset.x / state.nat.w) * r.width;
  const y = r.top - sr.top + (+t.dataset.y / state.nat.h) * r.height;
  t.style.left = x + 'px'; t.style.top = y + 'px';
  const fs = textSize() * state.view.s;
  t.style.fontSize = clamp(fs, 12, 64) + 'px';
}
function textSize() { return Math.max(14, edit.size * ImageOps.unitFor(edit.base.width, edit.base.height) * 8); }
function commitTextEntry(cancel) {
  const t = el.textEntry;
  if (!t.classList.contains('on')) return;
  const text = t.value.trim();
  t.classList.remove('on');
  if (cancel || !text || !edit.base) return;
  edit.objects.push({ type: 'text', text, x: +t.dataset.x, y: +t.dataset.y, size: textSize(), color: edit.color, shadow: edit.shadow, w: strokeW() });
  renderDrawLayer();
  updatePendingFoot();
}
el.textEntry.addEventListener('keydown', (e) => {
  e.stopPropagation();
  if (e.key === 'Enter') { e.preventDefault(); commitTextEntry(); }
  if (e.key === 'Escape') { e.preventDefault(); commitTextEntry(true); }
});
el.textEntry.addEventListener('blur', () => commitTextEntry());

// ---- guardar
async function saveFlow() {
  if (!body.classList.contains('editing')) return;
  if (hasPending()) commitPending();
  const f = current();
  const ext = extOf(f.path);
  const canReplace = WRITABLE.has(ext);
  const q = state.prefs.quality;
  const r = await modal(`<h2>Guardar imagen</h2><p>${fmtNum(edit.base.width)} × ${fmtNum(edit.base.height)} px</p>
    <div class="radio-cards">
      <label class="radio-card" ${canReplace ? '' : 'style="opacity:.45;pointer-events:none"'}><input type="radio" name="mode" value="replace" ${canReplace ? 'checked' : 'disabled'}><span class="dot"></span>
        <span><b>Reemplazar el original</b><small>${canReplace ? `Sobrescribe «${esc(f.name)}»` : `No se puede escribir en formato ${formatName(ext)}`}</small></span></label>
      <label class="radio-card"><input type="radio" name="mode" value="copy" ${canReplace ? '' : 'checked'}><span class="dot"></span>
        <span><b>Guardar como copia</b><small>Elige nombre, carpeta y formato (JPEG, PNG o WebP)</small></span></label>
    </div>
    <div class="field slider-field" id="q-row">
      <div class="sl-head"><label for="q-in">Calidad JPEG / WebP</label><output id="q-out">${q}</output></div>
      <input type="range" id="q-in" min="40" max="100" value="${q}">
    </div>
    <div class="actions"><button class="btn ghost" data-res="no">Cancelar</button><button class="btn accent" data-res="ok" data-default>Guardar</button></div>`);
  const qIn = $('#q-in');
  const quality = qIn ? +qIn.value : q;
  const mode = (el.modal.querySelector('input[name=mode]:checked') || {}).value;
  if (r !== 'ok') return;
  state.prefs.quality = quality; savePrefs();
  let target = f.path;
  if (mode === 'copy') {
    const stem = f.name.replace(/\.[^.]+$/, '');
    const defExt = WRITABLE.has(ext) ? ext : 'png';
    const p = await api.saveDialog(`${dirName(f.path)}/${stem}-editada.${defExt}`);
    if (!p) return;
    target = WRITABLE.has(extOf(p)) ? p : p + '.' + defExt;
  }
  const outExt = extOf(target);
  const type = ['jpg', 'jpeg', 'jpe', 'jfif'].includes(outExt) ? 'image/jpeg' : outExt === 'webp' ? 'image/webp' : 'image/png';
  setLoading(true);
  try {
    let c = edit.base;
    if (type === 'image/jpeg') {
      const flat = ImageOps.makeCanvas(c.width, c.height);
      const x = flat.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, flat.width, flat.height); x.drawImage(c, 0, 0);
      c = flat;
    }
    const blob = await new Promise((res) => c.toBlob(res, type, quality / 100));
    if (!blob) throw new Error('No se pudo codificar la imagen');
    const buf = new Uint8Array(await blob.arrayBuffer());
    await api.write(target, buf);
    await exitEdit(true);
    await openPath(target);
    toast(mode === 'copy' ? `Copia guardada: ${baseName(target)}` : 'Imagen guardada');
  } catch (e) {
    toast('No se pudo guardar: ' + (e.message || e));
  } finally { setLoading(false); }
}
document.addEventListener('input', (e) => {
  if (e.target.id === 'q-in') { $('#q-out').textContent = e.target.value; paintRange(e.target); }
});

// =================================================================== teclado
document.addEventListener('keydown', (e) => {
  if (el.veil.classList.contains('on')) return;
  const tag = (e.target.tagName || '').toLowerCase();
  if (tag === 'input' && e.target.type !== 'range' && e.target.type !== 'checkbox') return;
  const k = e.key;
  const ctrl = e.ctrlKey || e.metaKey;
  const editing = body.classList.contains('editing');
  if (el.menu.classList.contains('on') && k === 'Escape') { closeMenu(); return; }

  if (ctrl && k.toLowerCase() === 'p') { e.preventDefault(); printFlow(); return; }
  if (ctrl && k.toLowerCase() === 'o') { e.preventDefault(); if (!editing) (e.shiftKey ? openFolderDialog : openDialog)(); return; }
  if (k === 'F11') { e.preventDefault(); api.win.fullscreen(); return; }
  if (k === '+' || k === '=' || (ctrl && k === '+')) { e.preventDefault(); zoomStep(1); return; }
  if (k === '-' || (ctrl && k === '-')) { e.preventDefault(); zoomStep(-1); return; }
  if (k === '0' && !ctrl) { fitView(true); return; }
  if (k === '1' && !ctrl) { zoomActual(); return; }

  if (editing) {
    if (ctrl && k.toLowerCase() === 'z' && !e.shiftKey) { e.preventDefault(); undo(); return; }
    if (ctrl && (k.toLowerCase() === 'y' || (k.toLowerCase() === 'z' && e.shiftKey))) { e.preventDefault(); redo(); return; }
    if (ctrl && k.toLowerCase() === 's') { e.preventDefault(); saveFlow(); return; }
    if (k === 'Enter') { e.preventDefault(); commitPending(); return; }
    if (k === '\\' && !e.repeat) { setCompare(true); return; }
    if (k === 'Escape') { e.preventDefault(); if (hasPending()) discardPending(); else exitEdit(); return; }
    return;
  }

  if (state.slideshow) {
    if (k === 'Escape' || k === 'F5') { e.preventDefault(); stopSlideshow(); return; }
    if (k === ' ') { e.preventDefault(); state.slideshow.toggle(); return; }
    if (k === 'ArrowRight') { go(1); state.slideshow.restart(); return; }
    if (k === 'ArrowLeft') { go(-1); state.slideshow.restart(); return; }
    return;
  }

  switch (k) {
    case 'ArrowRight': case 'PageDown': e.preventDefault(); go(1); break;
    case 'ArrowLeft': case 'PageUp': e.preventDefault(); go(-1); break;
    case ' ': e.preventDefault(); go(1); break;
    case 'Backspace': go(-1); break;
    case 'Home': show(0); break;
    case 'End': show(state.files.length - 1); break;
    case 'r': case 'R': if (!ctrl) rotateView(e.shiftKey ? -1 : 1); break;
    case 'i': case 'I': toggleInfo(); break;
    case 'e': case 'E': enterEdit(); break;
    case 'b': case 'B': cycleBg(); break;
    case 'F5': e.preventDefault(); startSlideshow(); break;
    case 'F2': renameCurrent(); break;
    case 'Delete': trashCurrent(); break;
    case '?': showShortcuts(); break;
    case 'Escape': if (state.fullscreen) api.win.fullscreen(false); break;
    case 'c': case 'C': if (ctrl) copyImage(); break;
  }
});
document.addEventListener('keyup', (e) => { if (e.key === '\\') setCompare(false); });

// =================================================================== botones
$('#btn-open').onclick = openDialog;
$('#empty-open').onclick = openDialog;
$('#empty-folder').onclick = openFolderDialog;
$('#btn-info').onclick = () => toggleInfo();
$('#info-close').onclick = () => toggleInfo(false);
$('#btn-edit').onclick = enterEdit;
$('#btn-slideshow').onclick = () => (state.slideshow ? stopSlideshow() : startSlideshow());
$('#btn-more').onclick = (e) => { const r = e.currentTarget.getBoundingClientRect(); openMenu(moreMenuItems(), r.right - 240, r.bottom + 6); };
$('#btn-undo').onclick = undo;
$('#btn-redo').onclick = redo;
$('#btn-save').onclick = saveFlow;
$('#btn-print').onclick = printFlow;
$('#btn-print-edit').onclick = printFlow;
$('#btn-cancel-edit').onclick = () => exitEdit();
el.prev.onclick = () => go(-1);
el.next.onclick = () => go(1);
$('#wc-min').onclick = api.win.minimize;
$('#wc-max').onclick = api.win.maximize;
$('#wc-close').onclick = async () => {
  if (body.classList.contains('editing') && (edit.hi > 0 || hasPending())) {
    const ok = await confirmModal('¿Cerrar sin guardar?', 'Tienes cambios sin guardar en la imagen.', 'Cerrar sin guardar', true);
    if (!ok) return;
  }
  api.win.close();
};
$('#titlebar').addEventListener('dblclick', (e) => { if (!e.target.closest('button')) api.win.maximize(); });
api.on('open-path', (p) => { if (body.classList.contains('editing')) { toast('Termina o cancela la edición para abrir otra imagen'); return; } openPath(p); });

// =================================================================== arranque
(async function init() {
  body.classList.toggle('native-frame', !!api.nativeFrame);
  hydrateIcons();
  buildEditorUi();
  Object.assign(state.prefs, await api.getPrefs());
  applyBg();
  if (state.prefs.info) { body.classList.add('info-open'); $('#btn-info').classList.add('on'); }
  const ws = await api.win.state();
  $('#wc-max').innerHTML = icon(ws.maximized ? 'restore' : 'max');
  showEmpty(true);
  renderInfo();
  const p = await api.initialPath();
  if (p) openPath(p);
})();
