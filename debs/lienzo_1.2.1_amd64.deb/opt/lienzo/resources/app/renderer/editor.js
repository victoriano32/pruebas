'use strict';
// Operaciones de imagen de Lienzo: ajustes, filtros, geometría y dibujo.
const ImageOps = (() => {
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const smooth = (e0, e1, x) => { const t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); };

  function makeCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w));
    c.height = Math.max(1, Math.round(h));
    return c;
  }
  function ctx2d(c, opts) { return c.getContext('2d', Object.assign({ willReadFrequently: false }, opts || {})); }

  function fromImage(img) {
    const w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
    const c = makeCanvas(w, h);
    ctx2d(c).drawImage(img, 0, 0, w, h);
    return c;
  }

  function clone(src) {
    const c = makeCanvas(src.width, src.height);
    ctx2d(c).drawImage(src, 0, 0);
    return c;
  }

  // Reducción en pasos para buena calidad.
  function resize(src, w, h) {
    w = Math.max(1, Math.round(w)); h = Math.max(1, Math.round(h));
    let cur = src;
    while (cur.width / 2 >= w && cur.height / 2 >= h) {
      const n = makeCanvas(Math.round(cur.width / 2), Math.round(cur.height / 2));
      const x = ctx2d(n); x.imageSmoothingQuality = 'high'; x.drawImage(cur, 0, 0, n.width, n.height);
      cur = n;
    }
    const out = makeCanvas(w, h);
    const x = ctx2d(out); x.imageSmoothingQuality = 'high'; x.drawImage(cur, 0, 0, w, h);
    return out;
  }

  function fitWithin(src, maxSide) {
    const s = Math.min(1, maxSide / Math.max(src.width, src.height));
    return s >= 1 ? clone(src) : resize(src, src.width * s, src.height * s);
  }

  // ---------- Ajustes ----------
  const ADJUST = [
    { group: 'Luz', items: [
      { key: 'exposure', label: 'Exposición', min: -100, max: 100 },
      { key: 'brightness', label: 'Brillo', min: -100, max: 100 },
      { key: 'contrast', label: 'Contraste', min: -100, max: 100 },
      { key: 'highlights', label: 'Luces', min: -100, max: 100 },
      { key: 'shadows', label: 'Sombras', min: -100, max: 100 },
    ] },
    { group: 'Color', items: [
      { key: 'temperature', label: 'Temperatura', min: -100, max: 100, cls: 'temp-track' },
      { key: 'tint', label: 'Matiz', min: -100, max: 100, cls: 'tint-track' },
      { key: 'saturation', label: 'Saturación', min: -100, max: 100 },
      { key: 'vibrance', label: 'Intensidad', min: -100, max: 100 },
      { key: 'hue', label: 'Tono', min: -180, max: 180, cls: 'hue-track', unit: '°' },
    ] },
    { group: 'Detalle y efectos', items: [
      { key: 'sharpen', label: 'Nitidez', min: 0, max: 100 },
      { key: 'blur', label: 'Desenfoque', min: 0, max: 100 },
      { key: 'vignette', label: 'Viñeta', min: -100, max: 100 },
      { key: 'fade', label: 'Desvaído', min: 0, max: 100 },
      { key: 'grain', label: 'Grano', min: 0, max: 100 },
    ] },
  ];
  const KEYS = ADJUST.flatMap((g) => g.items.map((i) => i.key));
  const RANGE = Object.fromEntries(ADJUST.flatMap((g) => g.items.map((i) => [i.key, i])));
  const neutral = () => Object.fromEntries(KEYS.map((k) => [k, 0]));

  const LOOKS = [
    { id: 'none', name: 'Original', p: {} },
    { id: 'vivid', name: 'Vívido', p: { contrast: 18, saturation: 28, vibrance: 22 } },
    { id: 'warm', name: 'Cálido', p: { temperature: 38, saturation: 8, highlights: -8 } },
    { id: 'cool', name: 'Frío', p: { temperature: -38, tint: -6, contrast: 6 } },
    { id: 'matte', name: 'Mate', p: { fade: 42, contrast: -16, saturation: -12 } },
    { id: 'drama', name: 'Dramático', p: { contrast: 45, shadows: -22, highlights: -28, vignette: 42, saturation: -12 } },
    { id: 'sunset', name: 'Atardecer', p: { temperature: 48, tint: 16, exposure: 6, contrast: 10 } },
    { id: 'film', name: 'Película', p: { fade: 26, contrast: 14, temperature: 10, grain: 32, saturation: -8 } },
    { id: 'vintage', name: 'Vintage', p: { fade: 36, temperature: 22, vignette: 32, contrast: -6 }, css: { sepia: 0.35 } },
    { id: 'mint', name: 'Menta', p: { temperature: -16, tint: -26, fade: 20, exposure: 4 } },
    { id: 'polar', name: 'Polar', p: { exposure: 14, temperature: -22, saturation: -32, contrast: -10 } },
    { id: 'sepia', name: 'Sepia', p: { contrast: 6 }, css: { sepia: 0.85 } },
    { id: 'bw', name: 'Blanco y negro', p: {}, css: { gray: 1 } },
    { id: 'bwhard', name: 'B/N intenso', p: { contrast: 42, shadows: -12 }, css: { gray: 1 } },
    { id: 'noir', name: 'Noir', p: { contrast: 62, exposure: -10, vignette: 58, grain: 22 }, css: { gray: 1 } },
  ];

  function combine(params, look, strength) {
    const out = Object.assign(neutral(), params);
    const s = strength == null ? 1 : strength;
    if (look && look.p) for (const k in look.p) out[k] = clamp(out[k] + look.p[k] * s, RANGE[k].min * 1.5, RANGE[k].max * 1.5);
    out.gray = look && look.css && look.css.gray ? look.css.gray * s : 0;
    out.sepia = look && look.css && look.css.sepia ? look.css.sepia * s : 0;
    return out;
  }

  function isNeutral(p) { return KEYS.every((k) => !p[k]) && !p.gray && !p.sepia; }

  function buildLuts(p) {
    const r = new Uint8ClampedArray(256), g = new Uint8ClampedArray(256), b = new Uint8ClampedArray(256);
    const exp = Math.pow(2, (p.exposure / 100) * 1.6);
    const bri = (p.brightness / 100) * 0.22;
    const c = p.contrast / 100;
    const cf = c >= 0 ? 1 + c * 1.1 : 1 + c * 0.75;
    const hi = (p.highlights / 100) * 0.3;
    const sh = (p.shadows / 100) * 0.3;
    const t = p.temperature / 100, tn = p.tint / 100;
    const mul = [1 + t * 0.16 + tn * 0.05, 1 - tn * 0.1 + t * 0.02, 1 - t * 0.18 + tn * 0.05];
    const fade = (p.fade / 100) * 0.2;
    const luts = [r, g, b];
    for (let ch = 0; ch < 3; ch++) {
      for (let i = 0; i < 256; i++) {
        let v = (i / 255) * mul[ch] * exp;
        v += bri;
        v = (v - 0.5) * cf + 0.5;
        v += hi * smooth(0.45, 1, v) * (v > 0 ? 1 : 0);
        v += sh * (1 - smooth(0, 0.55, v));
        v = fade + v * (1 - fade * 1.15);
        luts[ch][i] = clamp(v, 0, 1) * 255 + 0.5;
      }
    }
    return luts;
  }

  // Aplica ajustes a un lienzo y devuelve uno nuevo del mismo tamaño.
  function process(src, p) {
    const w = src.width, h = src.height;
    const out = makeCanvas(w, h);
    const x = ctx2d(out, { willReadFrequently: true });
    const filters = [];
    if (p.hue) filters.push(`hue-rotate(${p.hue}deg)`);
    if (p.saturation) filters.push(`saturate(${Math.max(0, 1 + p.saturation / 100)})`);
    if (p.gray) filters.push(`grayscale(${clamp(p.gray, 0, 1)})`);
    if (p.sepia) filters.push(`sepia(${clamp(p.sepia, 0, 1)})`);
    if (p.blur > 0) filters.push(`blur(${(p.blur / 100) * 0.012 * Math.max(w, h)}px)`);
    if (p.blur > 0) {
      // Evita bordes transparentes al desenfocar: dibuja con margen reflejado.
      x.drawImage(src, 0, 0);
    }
    x.filter = filters.length ? filters.join(' ') : 'none';
    x.drawImage(src, 0, 0);
    x.filter = 'none';

    const needPixels = p.exposure || p.brightness || p.contrast || p.highlights || p.shadows || p.temperature || p.tint || p.fade || p.vibrance || p.sharpen || p.grain;
    if (needPixels) {
      const id = x.getImageData(0, 0, w, h);
      const d = id.data;
      const [lr, lg, lb] = buildLuts(p);
      const vib = p.vibrance / 100;
      for (let i = 0; i < d.length; i += 4) {
        let r = lr[d[i]], g = lg[d[i + 1]], b = lb[d[i + 2]];
        if (vib) {
          const mx = Math.max(r, g, b), mn = Math.min(r, g, b), avg = (r + g + b) / 3;
          const k = vib * (1 - (mx - mn) / 255) * (vib > 0 ? 1.2 : 1);
          r += (r - avg) * k; g += (g - avg) * k; b += (b - avg) * k;
        }
        d[i] = r; d[i + 1] = g; d[i + 2] = b;
      }
      if (p.sharpen > 0) sharpen(d, w, h, (p.sharpen / 100) * 1.1);
      if (p.grain > 0) {
        const amt = (p.grain / 100) * 46;
        for (let i = 0; i < d.length; i += 4) {
          const n = (Math.random() - 0.5) * amt;
          d[i] += n; d[i + 1] += n; d[i + 2] += n;
        }
      }
      x.putImageData(id, 0, 0);
    }
    if (p.vignette) vignette(x, w, h, p.vignette / 100);
    return out;
  }

  function sharpen(d, w, h, a) {
    const src = new Uint8ClampedArray(d);
    const row = w * 4;
    for (let y = 1; y < h - 1; y++) {
      for (let xx = 1; xx < w - 1; xx++) {
        const i = y * row + xx * 4;
        for (let c = 0; c < 3; c++) {
          const k = i + c;
          const v = src[k] * (1 + 4 * a) - a * (src[k - 4] + src[k + 4] + src[k - row] + src[k + row]);
          d[k] = v;
        }
      }
    }
  }

  function vignette(x, w, h, amt) {
    const cx = w / 2, cy = h / 2, r = Math.hypot(cx, cy);
    const g = x.createRadialGradient(cx, cy, r * 0.42, cx, cy, r * 1.02);
    if (amt > 0) {
      g.addColorStop(0, 'rgba(0,0,0,0)');
      g.addColorStop(1, `rgba(0,0,0,${Math.min(0.92, amt * 0.85)})`);
    } else {
      g.addColorStop(0, 'rgba(255,255,255,0)');
      g.addColorStop(1, `rgba(255,255,255,${Math.min(0.85, -amt * 0.75)})`);
    }
    x.save();
    x.fillStyle = g;
    x.fillRect(0, 0, w, h);
    x.restore();
  }

  // ---------- Geometría ----------
  function rotate90(src, dir) {
    const out = makeCanvas(src.height, src.width);
    const x = ctx2d(out);
    x.translate(out.width / 2, out.height / 2);
    x.rotate((dir > 0 ? 90 : -90) * Math.PI / 180);
    x.drawImage(src, -src.width / 2, -src.height / 2);
    return out;
  }

  function flip(src, horizontal) {
    const out = makeCanvas(src.width, src.height);
    const x = ctx2d(out);
    if (horizontal) { x.translate(src.width, 0); x.scale(-1, 1); } else { x.translate(0, src.height); x.scale(1, -1); }
    x.drawImage(src, 0, 0);
    return out;
  }

  function coverScale(w, h, deg) {
    const t = Math.abs(deg) * Math.PI / 180;
    return Math.cos(t) + Math.max(w / h, h / w) * Math.sin(t);
  }

  function straighten(src, deg) {
    if (!deg) return src;
    const w = src.width, h = src.height;
    const out = makeCanvas(w, h);
    const x = ctx2d(out);
    x.imageSmoothingQuality = 'high';
    x.translate(w / 2, h / 2);
    x.rotate(deg * Math.PI / 180);
    const k = coverScale(w, h, deg);
    x.scale(k, k);
    x.drawImage(src, -w / 2, -h / 2);
    return out;
  }

  function crop(src, r) {
    const x0 = clamp(Math.round(r.x), 0, src.width - 1), y0 = clamp(Math.round(r.y), 0, src.height - 1);
    const w = clamp(Math.round(r.w), 1, src.width - x0), h = clamp(Math.round(r.h), 1, src.height - y0);
    const out = makeCanvas(w, h);
    ctx2d(out).drawImage(src, x0, y0, w, h, 0, 0, w, h);
    return out;
  }

  // ---------- Dibujo ----------
  function unitFor(w, h) { return Math.hypot(w, h) / 1500; }

  function arrowHead(o) {
    const ang = Math.atan2(o.y2 - o.y1, o.x2 - o.x1);
    const len = Math.max(o.w * 4.2, 10);
    const spread = 0.5;
    return [
      [o.x2 - len * Math.cos(ang - spread), o.y2 - len * Math.sin(ang - spread)],
      [o.x2, o.y2],
      [o.x2 - len * Math.cos(ang + spread), o.y2 - len * Math.sin(ang + spread)],
    ];
  }

  function smoothPath(pts) {
    if (pts.length < 3) return pts.length ? `M${pts[0][0]} ${pts[0][1]} L${pts[pts.length - 1][0] + 0.01} ${pts[pts.length - 1][1]}` : '';
    let d = `M${pts[0][0]} ${pts[0][1]}`;
    for (let i = 1; i < pts.length - 1; i++) {
      const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2;
      d += ` Q${pts[i][0]} ${pts[i][1]} ${mx} ${my}`;
    }
    const l = pts[pts.length - 1];
    return d + ` L${l[0]} ${l[1]}`;
  }

  function pixelBlock(w, h) { return Math.max(6, Math.round(Math.hypot(w, h) / 110)); }

  function pixelateRegion(src, r, block) {
    const x0 = Math.max(0, Math.floor(r.x)), y0 = Math.max(0, Math.floor(r.y));
    const w = Math.min(src.width - x0, Math.ceil(r.w)), h = Math.min(src.height - y0, Math.ceil(r.h));
    if (w < 1 || h < 1) return null;
    const small = makeCanvas(Math.max(1, Math.round(w / block)), Math.max(1, Math.round(h / block)));
    const sx = ctx2d(small); sx.imageSmoothingQuality = 'medium';
    sx.drawImage(src, x0, y0, w, h, 0, 0, small.width, small.height);
    const out = makeCanvas(w, h);
    const ox = ctx2d(out); ox.imageSmoothingEnabled = false;
    ox.drawImage(small, 0, 0, w, h);
    return { canvas: out, x: x0, y: y0 };
  }

  function drawObjects(target, objects, scale = 1) {
    const x = ctx2d(target);
    for (const o of objects) {
      x.save();
      if (o.type === 'pixel') {
        const r = { x: o.x * scale, y: o.y * scale, w: o.w * scale, h: o.h * scale };
        const px = pixelateRegion(target, r, pixelBlock(target.width, target.height));
        if (px) x.drawImage(px.canvas, px.x, px.y);
        x.restore();
        continue;
      }
      x.scale(scale, scale);
      if (o.shadow) {
        x.shadowColor = 'rgba(0,0,0,.45)';
        x.shadowBlur = Math.max(2, (o.w || 4) * 1.2) * scale;
        x.shadowOffsetY = Math.max(1, (o.w || 4) * 0.35) * scale;
      }
      x.strokeStyle = o.color; x.fillStyle = o.color;
      x.lineWidth = o.w; x.lineCap = 'round'; x.lineJoin = 'round';
      switch (o.type) {
        case 'pen': case 'marker': {
          if (o.type === 'marker') { x.globalAlpha = 0.42; x.lineWidth = o.w * 3.2; x.lineCap = 'butt'; x.shadowColor = 'transparent'; }
          x.stroke(new Path2D(smoothPath(o.pts)));
          break;
        }
        case 'line': case 'arrow': {
          x.beginPath(); x.moveTo(o.x1, o.y1); x.lineTo(o.x2, o.y2); x.stroke();
          if (o.type === 'arrow') {
            const hd = arrowHead(o);
            x.beginPath(); x.moveTo(hd[0][0], hd[0][1]); x.lineTo(hd[1][0], hd[1][1]); x.lineTo(hd[2][0], hd[2][1]); x.stroke();
          }
          break;
        }
        case 'rect': {
          if (o.fill) { x.globalAlpha = 0.35; x.fillRect(o.x, o.y, o.w2, o.h2); x.globalAlpha = 1; x.shadowColor = 'transparent'; }
          roundRectPath(x, o.x, o.y, o.w2, o.h2, Math.min(o.w * 1.2, Math.abs(o.w2) / 2, Math.abs(o.h2) / 2));
          x.stroke();
          break;
        }
        case 'ellipse': {
          x.beginPath();
          x.ellipse(o.x + o.w2 / 2, o.y + o.h2 / 2, Math.abs(o.w2 / 2), Math.abs(o.h2 / 2), 0, 0, Math.PI * 2);
          if (o.fill) { x.globalAlpha = 0.35; x.fill(); x.globalAlpha = 1; x.shadowColor = 'transparent'; }
          x.stroke();
          break;
        }
        case 'text': {
          x.font = `700 ${o.size}px LienzoInter, Inter, sans-serif`;
          x.textBaseline = 'top';
          x.fillText(o.text, o.x, o.y);
          break;
        }
      }
      x.restore();
    }
  }

  function roundRectPath(x, rx, ry, w, h, r) {
    if (w < 0) { rx += w; w = -w; }
    if (h < 0) { ry += h; h = -h; }
    r = Math.max(0, r);
    x.beginPath();
    x.moveTo(rx + r, ry);
    x.arcTo(rx + w, ry, rx + w, ry + h, r);
    x.arcTo(rx + w, ry + h, rx, ry + h, r);
    x.arcTo(rx, ry + h, rx, ry, r);
    x.arcTo(rx, ry, rx + w, ry, r);
    x.closePath();
  }

  // ---------- Histograma ----------
  function histogram(src) {
    const s = fitWithin(src, 320);
    const d = ctx2d(s, { willReadFrequently: true }).getImageData(0, 0, s.width, s.height).data;
    const r = new Uint32Array(256), g = new Uint32Array(256), b = new Uint32Array(256), l = new Uint32Array(256);
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] < 8) continue;
      r[d[i]]++; g[d[i + 1]]++; b[d[i + 2]]++;
      l[(d[i] * 0.2126 + d[i + 1] * 0.7152 + d[i + 2] * 0.0722) | 0]++;
    }
    return { r, g, b, l };
  }

  function drawHistogram(canvas, hist) {
    const dpr = window.devicePixelRatio || 1;
    const W = canvas.clientWidth || 280, H = canvas.clientHeight || 96;
    canvas.width = W * dpr; canvas.height = H * dpr;
    const x = canvas.getContext('2d');
    x.scale(dpr, dpr);
    x.clearRect(0, 0, W, H);
    let max = 1;
    for (const ch of [hist.r, hist.g, hist.b]) for (let i = 2; i < 254; i++) max = Math.max(max, ch[i]);
    const pad = 6;
    const path = (arr) => {
      x.beginPath();
      x.moveTo(pad, H - pad);
      for (let i = 0; i < 256; i++) {
        const px = pad + (i / 255) * (W - pad * 2);
        const py = H - pad - Math.min(1, Math.sqrt(arr[i] / max)) * (H - pad * 2);
        x.lineTo(px, py);
      }
      x.lineTo(W - pad, H - pad);
      x.closePath();
    };
    x.globalCompositeOperation = 'lighter';
    const cols = [['r', 'rgba(232, 92, 80, .55)'], ['g', 'rgba(96, 196, 120, .5)'], ['b', 'rgba(90, 140, 235, .55)']];
    for (const [k, c] of cols) { path(hist[k]); x.fillStyle = c; x.fill(); }
    x.globalCompositeOperation = 'source-over';
    path(hist.l);
    x.strokeStyle = 'rgba(236,235,231,.55)'; x.lineWidth = 1; x.stroke();
  }

  return {
    ADJUST, KEYS, LOOKS, RANGE, neutral, combine, isNeutral, process,
    makeCanvas, fromImage, clone, resize, fitWithin,
    rotate90, flip, straighten, coverScale, crop,
    unitFor, arrowHead, smoothPath, pixelBlock, pixelateRegion, drawObjects,
    histogram, drawHistogram, clamp,
  };
})();
