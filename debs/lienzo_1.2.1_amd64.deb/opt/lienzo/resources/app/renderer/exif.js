'use strict';
// Lector EXIF mínimo para JPEG (y WebP con bloque EXIF).
const Exif = (() => {
  const TAGS = {
    0x010F: 'make', 0x0110: 'model', 0x0112: 'orientation', 0x0131: 'software', 0x0132: 'dateTime',
    0x013B: 'artist', 0x8298: 'copyright',
    0x829A: 'exposureTime', 0x829D: 'fNumber', 0x8827: 'iso', 0x9003: 'dateTimeOriginal',
    0x9204: 'exposureBias', 0x9207: 'meteringMode', 0x9209: 'flash', 0x920A: 'focalLength',
    0xA405: 'focalLength35', 0xA434: 'lensModel', 0xA433: 'lensMake', 0xA002: 'pixelX', 0xA003: 'pixelY',
  };
  const GPS = { 1: 'latRef', 2: 'lat', 3: 'lonRef', 4: 'lon', 6: 'alt' };
  const SIZES = { 1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 9: 4, 10: 8 };

  function readIFD(view, tiff, off, le, map, out, follow) {
    if (off + 2 > view.byteLength) return;
    const n = view.getUint16(off, le);
    for (let i = 0; i < n; i++) {
      const e = off + 2 + i * 12;
      if (e + 12 > view.byteLength) break;
      const tag = view.getUint16(e, le);
      const type = view.getUint16(e + 2, le);
      const count = view.getUint32(e + 4, le);
      const size = (SIZES[type] || 1) * count;
      const vo = size > 4 ? tiff + view.getUint32(e + 8, le) : e + 8;
      if (follow && (tag === 0x8769 || tag === 0x8825)) {
        follow(tag, tiff + view.getUint32(e + 8, le));
        continue;
      }
      const name = map[tag];
      if (!name) continue;
      try { out[name] = readVal(view, vo, type, count, le); } catch (_) { /* ignore */ }
    }
  }

  function readVal(view, o, type, count, le) {
    const vals = [];
    for (let i = 0; i < count; i++) {
      switch (type) {
        case 2: {
          let s = '';
          for (let j = 0; j < count; j++) { const c = view.getUint8(o + j); if (!c) break; s += String.fromCharCode(c); }
          try { s = decodeURIComponent(escape(s)); } catch (_) { /* latin1 */ }
          return s.trim();
        }
        case 1: case 7: vals.push(view.getUint8(o + i)); break;
        case 3: vals.push(view.getUint16(o + i * 2, le)); break;
        case 4: vals.push(view.getUint32(o + i * 4, le)); break;
        case 9: vals.push(view.getInt32(o + i * 4, le)); break;
        case 5: { const a = view.getUint32(o + i * 8, le), b = view.getUint32(o + i * 8 + 4, le); vals.push(b ? a / b : 0); break; }
        case 10: { const a = view.getInt32(o + i * 8, le), b = view.getInt32(o + i * 8 + 4, le); vals.push(b ? a / b : 0); break; }
        default: return null;
      }
      if (i > 32) break;
    }
    return count === 1 ? vals[0] : vals;
  }

  function parseTiff(view, tiff) {
    const bo = view.getUint16(tiff);
    const le = bo === 0x4949;
    if (!le && bo !== 0x4D4D) return null;
    const out = {}; const gps = {};
    const ifd0 = tiff + view.getUint32(tiff + 4, le);
    readIFD(view, tiff, ifd0, le, TAGS, out, (tag, off) => {
      if (tag === 0x8769) readIFD(view, tiff, off, le, TAGS, out);
      else readIFD(view, tiff, off, le, GPS, gps);
    });
    for (const k of ['exposureTime', 'fNumber', 'focalLength', 'exposureBias']) {
      const v = out[k];
      if (Array.isArray(v) && v.length === 2) out[k] = v[1] ? v[0] / v[1] : 0;
      if (typeof out[k] !== 'number') delete out[k];
    }
    if (Array.isArray(out.focalLength35)) out.focalLength35 = out.focalLength35[0];
    if (Array.isArray(gps.lat) && Array.isArray(gps.lon)) {
      const dms = (a) => a[0] + a[1] / 60 + a[2] / 3600;
      let lat = dms(gps.lat), lon = dms(gps.lon);
      if (gps.latRef === 'S') lat = -lat;
      if (gps.lonRef === 'W') lon = -lon;
      if (isFinite(lat) && isFinite(lon) && (lat || lon)) out.gps = { lat, lon, alt: gps.alt };
    }
    return out;
  }

  function parse(buffer) {
    const u8 = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    const view = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    try {
      if (view.getUint16(0) === 0xFFD8) {
        let o = 2;
        while (o + 4 < view.byteLength) {
          if (view.getUint8(o) !== 0xFF) return null;
          const marker = view.getUint8(o + 1);
          const len = view.getUint16(o + 2);
          if (marker === 0xE1 && view.getUint32(o + 4) === 0x45786966) return parseTiff(view, o + 10);
          if (marker === 0xDA) return null;
          o += 2 + len;
        }
      } else if (view.getUint32(0) === 0x52494646 && view.getUint32(8) === 0x57454250) {
        let o = 12;
        while (o + 8 < view.byteLength) {
          const id = String.fromCharCode(u8[o], u8[o + 1], u8[o + 2], u8[o + 3]);
          const len = view.getUint32(o + 4, true);
          if (id === 'EXIF') {
            let t = o + 8;
            if (view.getUint32(t) === 0x45786966) t += 6;
            return parseTiff(view, t);
          }
          o += 8 + len + (len & 1);
        }
      }
    } catch (_) { return null; }
    return null;
  }

  function fmtDate(s) {
    if (!s || typeof s !== 'string') return null;
    const m = s.match(/(\d{4}):(\d{2}):(\d{2})[ T](\d{2}):(\d{2})/);
    if (!m) return s;
    const d = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]);
    return d.toLocaleString('es-ES', { dateStyle: 'long', timeStyle: 'short' });
  }

  function fmtExposure(t) {
    if (!t) return null;
    if (t >= 1) return `${+t.toFixed(1)} s`;
    return `1/${Math.round(1 / t)} s`;
  }

  return { parse, fmtDate, fmtExposure };
})();
