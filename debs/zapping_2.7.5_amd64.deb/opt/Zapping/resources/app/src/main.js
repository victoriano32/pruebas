'use strict';

const { app, BrowserWindow, ipcMain, dialog, session, safeStorage, shell, net } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn, execFileSync } = require('child_process');

// Agente de usuario neutro: muchos proveedores IPTV bloquean "Electron".
const DEFAULT_UA =
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';
let currentUA = DEFAULT_UA;

app.userAgentFallback = DEFAULT_UA;
// Permite reproducir sin interacción previa (zapping de canales).
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

if (!app.requestSingleInstanceLock()) {
  app.quit();
}

/* ---------------------------------------------------------------- Almacén */

const DATA_FILE = () => path.join(app.getPath('userData'), 'zapping.json');
const CACHE_DIR = () => path.join(app.getPath('userData'), 'cache');

const EMPTY_STORE = {
  playlists: [],
  settings: { liveFormat: 'm3u8', externalPlayer: 'auto', defaultSection: 'live' },
  favorites: {},
  recent: {},
  progress: {},
  vpn: {},
};

let store = null;
let saveTimer = null;

function loadStore() {
  try {
    const raw = fs.readFileSync(DATA_FILE(), 'utf8');
    const parsed = JSON.parse(raw);
    store = { ...structuredClone(EMPTY_STORE), ...parsed };
    store.settings = { ...EMPTY_STORE.settings, ...(parsed.settings || {}) };
  } catch {
    store = structuredClone(EMPTY_STORE);
  }
}

function saveStore(immediate = false) {
  clearTimeout(saveTimer);
  const write = () => {
    try {
      fs.mkdirSync(path.dirname(DATA_FILE()), { recursive: true });
      const tmp = DATA_FILE() + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(store), { mode: 0o600 });
      fs.renameSync(tmp, DATA_FILE());
    } catch (e) {
      console.error('No se pudo guardar la configuración:', e);
    }
  };
  if (immediate) write();
  else saveTimer = setTimeout(write, 400);
}

function canEncrypt() {
  try {
    return safeStorage.isEncryptionAvailable();
  } catch {
    return false;
  }
}

function encryptSecret(plain) {
  if (!plain) return { password: '' };
  if (canEncrypt()) {
    try {
      return { passwordEnc: safeStorage.encryptString(plain).toString('base64') };
    } catch {}
  }
  return { password: plain };
}

function decryptSecret(p) {
  if (p.passwordEnc) {
    try {
      return safeStorage.decryptString(Buffer.from(p.passwordEnc, 'base64'));
    } catch {
      return '';
    }
  }
  return p.password || '';
}

function publicPlaylist(p) {
  const { passwordEnc, ...rest } = p;
  return { ...rest, password: decryptSecret(p) };
}

/* ---------------------------------------------------------------- Ventana */

let win = null;

function createWindow() {
  win = new BrowserWindow({
    width: 1360,
    height: 840,
    minWidth: 960,
    minHeight: 620,
    backgroundColor: '#0e1014',
    title: 'Zapping',
    icon: path.join(__dirname, 'renderer', 'icon.png'),
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      // Las emisiones IPTV no envían cabeceras CORS; sin esto hls.js no puede leerlas.
      webSecurity: false,
      // Permite elegir el idioma en películas con varias pistas de audio
      enableBlinkFeatures: 'AudioVideoTracks',
    },
  });
  win.removeMenu();
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

app.on('second-instance', () => {
  if (win) {
    if (win.isMinimized()) win.restore();
    win.focus();
  }
});

/* DNS seguro (DNS sobre HTTPS): algunos operadores de España bloquean servidores IPTV en su
   DNS (devuelven una dirección que no responde). Android suele usar DNS privado y no le afecta;
   en Linux, Zapping hace lo mismo con su propio DNS cifrado (Cloudflare, Google y Quad9).
   Modo «automatic»: primero el DNS cifrado y, si no está disponible, el del sistema.
   Ajuste «secureDns»: 'on' (por defecto) o 'off' (DNS del sistema). */
const DOH_SERVERS = [
  'https://cloudflare-dns.com/dns-query',
  'https://dns.google/dns-query',
  'https://dns.quad9.net/dns-query',
];
function applyDns() {
  const on = (store?.settings?.secureDns || 'on') !== 'off';
  try {
    app.configureHostResolver(
      on ? { secureDnsMode: 'automatic', secureDnsServers: DOH_SERVERS } : { secureDnsMode: 'off' }
    );
  } catch (e) {
    console.error('No se pudo configurar el DNS:', e);
  }
}

app.whenReady().then(() => {
  loadStore();
  applyDns();
  session.defaultSession.webRequest.onBeforeSendHeaders((details, cb) => {
    if (/^https?:/.test(details.url)) details.requestHeaders['User-Agent'] = currentUA;
    cb({ requestHeaders: details.requestHeaders });
  });
  createWindow();
});

app.on('window-all-closed', () => {
  saveStore(true);
  app.quit();
});

/* ---------------------------------------------------------------- IPC */

ipcMain.handle('store:get', () => ({
  playlists: store.playlists.map(publicPlaylist),
  settings: store.settings,
  favorites: store.favorites,
  recent: store.recent,
  progress: store.progress,
  vpn: store.vpn || {},
}));

ipcMain.handle('store:set', (_e, key, value) => {
  if (!['settings', 'favorites', 'recent', 'progress', 'vpn'].includes(key)) return false;
  const dnsBefore = store.settings?.secureDns;
  store[key] = value;
  saveStore();
  if (key === 'settings' && (value?.secureDns || 'on') !== (dnsBefore || 'on')) applyDns();
  return true;
});

ipcMain.handle('playlists:save', (_e, pl) => {
  const { password, ...rest } = pl;
  const stored = { ...rest, ...encryptSecret(password) };
  const idx = store.playlists.findIndex((p) => p.id === pl.id);
  if (idx >= 0) {
    // conservar campos que el renderizador no envía
    store.playlists[idx] = { ...store.playlists[idx], ...stored };
    if (!stored.passwordEnc) delete store.playlists[idx].passwordEnc;
    if (stored.passwordEnc) delete store.playlists[idx].password;
  } else {
    store.playlists.push(stored);
  }
  saveStore(true);
  return store.playlists.map(publicPlaylist);
});

ipcMain.handle('playlists:delete', (_e, id) => {
  store.playlists = store.playlists.filter((p) => p.id !== id);
  delete store.favorites[id];
  delete store.recent[id];
  delete store.progress[id];
  try {
    fs.rmSync(path.join(CACHE_DIR(), `${id}.json`), { force: true });
  } catch {}
  saveStore(true);
  return store.playlists.map(publicPlaylist);
});

ipcMain.handle('playlists:reorder', (_e, ids) => {
  const map = new Map(store.playlists.map((p) => [p.id, p]));
  store.playlists = ids.map((id) => map.get(id)).filter(Boolean);
  saveStore();
  return true;
});

ipcMain.handle('cache:get', (_e, id) => {
  try {
    return JSON.parse(fs.readFileSync(path.join(CACHE_DIR(), `${id}.json`), 'utf8'));
  } catch {
    return null;
  }
});

ipcMain.handle('cache:set', (_e, id, data) => {
  try {
    fs.mkdirSync(CACHE_DIR(), { recursive: true });
    fs.writeFileSync(path.join(CACHE_DIR(), `${id}.json`), JSON.stringify(data));
    return true;
  } catch {
    return false;
  }
});

// ¿Hay una VPN conectada? (interfaces típicas de VPN en Linux)
ipcMain.handle('vpn:status', () => {
  const ifs = require('os').networkInterfaces();
  return Object.entries(ifs).some(([name, addrs]) =>
    /^(tun|tap|wg|ppp|proton|nordlynx|nordtun|mullvad|tailscale|ipsec|vpn)/i.test(name) &&
    (addrs || []).some((a) => !a.internal)
  );
});

ipcMain.handle('ua:set', (_e, ua) => {
  currentUA = (ua && ua.trim()) || DEFAULT_UA;
  return true;
});

/* Descargas desde el proceso principal.
   Primero con el motor de red de Chromium (net.fetch, el mismo que usa Android): acepta
   respuestas «descuidadas» de los paneles IPTV (cabeceras repetidas o mal formadas) y usa
   el proxy y el DNS del sistema. Si falla, se prueba con el fetch de Node. */
async function netFetch(url, { ua, timeout = 30000 } = {}) {
  const headers = { 'User-Agent': (ua && ua.trim()) || currentUA, Accept: '*/*' };
  let first = null;
  try {
    return await net.fetch(url, { headers, signal: AbortSignal.timeout(timeout), redirect: 'follow' });
  } catch (e) {
    if (e?.name === 'TimeoutError' || e?.name === 'AbortError') throw e;
    first = e;
  }
  try {
    return await fetch(url, { headers, signal: AbortSignal.timeout(timeout), redirect: 'follow' });
  } catch (e) {
    // el error de Chromium suele explicar mejor qué pasa
    if (first) e.netError = first;
    throw e;
  }
}

async function httpGet(url, opts = {}) {
  const res = await netFetch(url, opts);
  const text = await res.text();
  return { status: res.status, ok: res.ok, text };
}

function friendlyError(e) {
  const code = e?.cause?.code || e?.code || '';
  const chrome = String(e?.netError?.message || (String(e?.message || '').includes('net::') ? e.message : ''));
  if (e?.name === 'TimeoutError' || e?.name === 'AbortError') return 'El servidor tardó demasiado en responder.';
  if (/NAME_NOT_RESOLVED|NAME_RESOLUTION/.test(chrome) || code === 'ENOTFOUND' || code === 'EAI_AGAIN')
    return 'No se encuentra el servidor (la dirección no existe o tu DNS no la resuelve). Revisa la dirección o prueba otro DNS.';
  if (/CONNECTION_REFUSED/.test(chrome) || code === 'ECONNREFUSED') return 'El servidor rechazó la conexión. Revisa el puerto.';
  if (/CONNECTION_TIMED_OUT|TIMED_OUT/.test(chrome) || code === 'ETIMEDOUT') return 'El servidor no responde (tiempo de espera agotado).';
  if (/CONNECTION_RESET|EMPTY_RESPONSE|CONNECTION_CLOSED/.test(chrome) || code === 'ECONNRESET')
    return 'El servidor cortó la conexión. A veces pasa cuando el proveedor bloquea tu IP o tu operador bloquea el servidor.';
  if (/CERT|SSL/.test(chrome) || String(code).startsWith('ERR_TLS') || String(code).includes('CERT'))
    return 'Problema con el certificado HTTPS del servidor. Prueba con http://';
  if (/INVALID_HTTP_RESPONSE|INVALID_RESPONSE/.test(chrome)) return 'El servidor ha enviado una respuesta no válida.';
  const detail = chrome || e?.cause?.message || code || '';
  return `${e?.message || 'Error de red desconocido.'}${detail && detail !== e?.message ? ` (${detail})` : ''}`;
}

ipcMain.handle('http:json', async (_e, url, opts) => {
  try {
    const r = await httpGet(url, opts);
    if (!r.ok) return { error: `El servidor respondió con el código ${r.status}.`, status: r.status };
    const body = r.text.replace(/^﻿/, '').trim();
    if (!body) return { data: null };
    try {
      return { data: JSON.parse(body) };
    } catch {
      return { error: 'La respuesta del servidor no es válida (no es JSON).' };
    }
  } catch (e) {
    return { error: friendlyError(e) };
  }
});

ipcMain.handle('http:text', async (_e, url, opts) => {
  try {
    const r = await httpGet(url, { timeout: 120000, ...opts });
    if (!r.ok) return { error: `El servidor respondió con el código ${r.status}.` };
    return { data: r.text };
  } catch (e) {
    return { error: friendlyError(e) };
  }
});

ipcMain.handle('http:binary', async (_e, url, opts = {}) => {
  try {
    const res = await netFetch(url, { ua: opts.ua, timeout: opts.timeout || 180000 });
    if (!res.ok) return { error: `El servidor respondió con el código ${res.status}.` };
    return { data: new Uint8Array(await res.arrayBuffer()) };
  } catch (e) {
    return { error: friendlyError(e) };
  }
});

ipcMain.handle('dialog:openM3U', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Abrir lista M3U',
    properties: ['openFile'],
    filters: [
      { name: 'Listas M3U', extensions: ['m3u', 'm3u8', 'txt'] },
      { name: 'Todos los archivos', extensions: ['*'] },
    ],
  });
  if (r.canceled || !r.filePaths[0]) return null;
  try {
    return { path: r.filePaths[0], text: fs.readFileSync(r.filePaths[0], 'utf8') };
  } catch (e) {
    return { error: e.message };
  }
});

/* ------------------------------------------------- Reproductores externos */

const PLAYERS = {
  mpv: { bin: 'mpv', label: 'MPV' },
  vlc: { bin: 'vlc', label: 'VLC' },
  celluloid: { bin: 'celluloid', label: 'Celluloid' },
};

function hasBin(bin) {
  try {
    execFileSync('which', [bin], { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

ipcMain.handle('player:detect', () =>
  Object.entries(PLAYERS)
    .filter(([, p]) => hasBin(p.bin))
    .map(([id, p]) => ({ id, label: p.label }))
);

ipcMain.handle('player:external', (_e, { url, title, player, ua }) => {
  let id = player;
  if (!id || id === 'auto' || !PLAYERS[id] || !hasBin(PLAYERS[id].bin)) {
    id = Object.keys(PLAYERS).find((k) => hasBin(PLAYERS[k].bin));
  }
  if (!id) {
    return { error: 'No hay ningún reproductor externo instalado. Instala MPV o VLC desde el Gestor de software.' };
  }
  const agent = (ua && ua.trim()) || currentUA;
  let args;
  if (id === 'mpv') args = [`--force-media-title=${title || ''}`, `--user-agent=${agent}`, '--', url];
  else if (id === 'vlc') args = [`--meta-title=${title || ''}`, `--http-user-agent=${agent}`, url];
  else args = [url];
  try {
    const child = spawn(PLAYERS[id].bin, args, { detached: true, stdio: 'ignore' });
    child.on('error', () => {});
    child.unref();
    return { ok: true, player: PLAYERS[id].label };
  } catch (e) {
    return { error: e.message };
  }
});
