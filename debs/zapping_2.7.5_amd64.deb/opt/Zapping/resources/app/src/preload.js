'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('zapping', {
  getStore: () => ipcRenderer.invoke('store:get'),
  setStore: (key, value) => ipcRenderer.invoke('store:set', key, value),
  savePlaylist: (pl) => ipcRenderer.invoke('playlists:save', pl),
  deletePlaylist: (id) => ipcRenderer.invoke('playlists:delete', id),
  reorderPlaylists: (ids) => ipcRenderer.invoke('playlists:reorder', ids),
  getCache: (id) => ipcRenderer.invoke('cache:get', id),
  setCache: (id, data) => ipcRenderer.invoke('cache:set', id, data),
  setUserAgent: (ua) => ipcRenderer.invoke('ua:set', ua),
  httpJson: (url, opts) => ipcRenderer.invoke('http:json', url, opts),
  httpText: (url, opts) => ipcRenderer.invoke('http:text', url, opts),
  httpBinary: (url, opts) => ipcRenderer.invoke('http:binary', url, opts),
  openM3UFile: () => ipcRenderer.invoke('dialog:openM3U'),
  detectPlayers: () => ipcRenderer.invoke('player:detect'),
  openExternal: (opts) => ipcRenderer.invoke('player:external', opts),
  vpnStatus: () => ipcRenderer.invoke('vpn:status'),
});
