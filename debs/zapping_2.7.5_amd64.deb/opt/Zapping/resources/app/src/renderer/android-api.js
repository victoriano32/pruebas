/* structuredClone polyfill: algunos Fire TV Stick llevan un WebView antiguo */
if (typeof structuredClone !== 'function') {
  window.structuredClone = (v) => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));
}
'use strict';
/* Adaptador para Android: ofrece la misma API que el preload de escritorio
   usando XHR, localStorage, IndexedDB y el puente nativo ZappingAndroid. */
(function () {
  if (window.zapping) return; // escritorio (Electron)

  const native = window.ZappingAndroid || null;
  const KEY = 'zapping.v1';
  const EMPTY = {
    playlists: [],
    settings: { liveFormat: 'm3u8', externalPlayer: 'auto', defaultSection: 'live', menuLayout: 'auto', orientation: 'auto', pip: 'on' },
    favorites: {},
    recent: {},
    progress: {},
    vpn: {},
  };

  function load() {
    try {
      const d = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (!d) return structuredClone(EMPTY);
      return { ...structuredClone(EMPTY), ...d, settings: { ...EMPTY.settings, ...(d.settings || {}) } };
    } catch {
      return structuredClone(EMPTY);
    }
  }
  let store = load();
  let saveT = null;
  function save(now) {
    clearTimeout(saveT);
    const w = () => {
      try {
        localStorage.setItem(KEY, JSON.stringify(store));
      } catch (e) {
        console.error('No se pudo guardar', e);
      }
    };
    if (now) w();
    else saveT = setTimeout(w, 300);
  }

  /* IndexedDB para listas M3U grandes */
  let dbp = null;
  function db() {
    if (!dbp) {
      dbp = new Promise((res, rej) => {
        const r = indexedDB.open('zapping', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('cache');
        r.onsuccess = () => res(r.result);
        r.onerror = () => rej(r.error);
      });
    }
    return dbp;
  }
  async function idb(mode, fn) {
    const d = await db();
    return new Promise((res, rej) => {
      const tx = d.transaction('cache', mode);
      const req = fn(tx.objectStore('cache'));
      tx.oncomplete = () => res(req?.result);
      tx.onerror = () => rej(tx.error);
    });
  }

  function xhr(url, timeout) {
    return new Promise((res) => {
      const x = new XMLHttpRequest();
      try {
        x.open('GET', url, true);
      } catch {
        return res({ error: 'La dirección no es válida.' });
      }
      x.timeout = timeout;
      x.onload = () => res({ status: x.status, ok: x.status >= 200 && x.status < 300, text: x.responseText });
      x.onerror = () => res({ error: 'No se puede conectar con el servidor. Revisa la dirección y tu conexión a internet.' });
      x.ontimeout = () => res({ error: 'El servidor tardó demasiado en responder.' });
      x.send();
    });
  }

  function xhrBin(url, timeout) {
    return new Promise((res) => {
      const x = new XMLHttpRequest();
      try {
        x.open('GET', url, true);
      } catch {
        return res({ error: 'La dirección no es válida.' });
      }
      x.responseType = 'arraybuffer';
      x.timeout = timeout;
      x.onload = () =>
        x.status >= 200 && x.status < 300
          ? res({ data: new Uint8Array(x.response) })
          : res({ error: `El servidor respondió con el código ${x.status}.` });
      x.onerror = () => res({ error: 'No se puede conectar. Revisa tu conexión a internet.' });
      x.ontimeout = () => res({ error: 'La descarga tardó demasiado.' });
      x.send();
    });
  }

  const pub = () => store.playlists.map((p) => ({ ...p }));

  window.zapping = {
    platform: 'android',
    // Google TV / Android TV: se maneja con el mando
    isFireTv: () => {
      try { return !!(native && native.isFireTv && native.isFireTv()); } catch { return false; }
    },
    isTv: () => {
      try { return !!(native && native.isTv && native.isTv()); } catch { return false; }
    },
    getStore: async () => structuredClone(store),
    setStore: async (k, v) => {
      if (!['settings', 'favorites', 'recent', 'progress', 'vpn'].includes(k)) return false;
      store[k] = structuredClone(v);
      save();
      return true;
    },
    savePlaylist: async (pl) => {
      const i = store.playlists.findIndex((p) => p.id === pl.id);
      if (i >= 0) store.playlists[i] = { ...store.playlists[i], ...pl };
      else store.playlists.push({ ...pl });
      save(true);
      return pub();
    },
    deletePlaylist: async (id) => {
      store.playlists = store.playlists.filter((p) => p.id !== id);
      delete store.favorites[id];
      delete store.recent[id];
      delete store.progress[id];
      save(true);
      try {
        await idb('readwrite', (s) => s.delete(id));
      } catch {}
      return pub();
    },
    reorderPlaylists: async () => true,
    getCache: async (id) => {
      try {
        return (await idb('readonly', (s) => s.get(id))) || null;
      } catch {
        return null;
      }
    },
    setCache: async (id, data) => {
      try {
        await idb('readwrite', (s) => s.put(data, id));
        return true;
      } catch {
        return false;
      }
    },
    setUserAgent: async () => true,
    httpJson: async (url) => {
      const r = await xhr(url, 30000);
      if (r.error) return r;
      if (!r.ok) return { error: `El servidor respondió con el código ${r.status}.`, status: r.status };
      const body = String(r.text || '').replace(/^﻿/, '').trim();
      if (!body) return { data: null };
      try {
        return { data: JSON.parse(body) };
      } catch {
        return { error: 'La respuesta del servidor no es válida (no es JSON).' };
      }
    },
    httpBinary: (url) => xhrBin(url, 180000),
    httpText: async (url) => {
      const r = await xhr(url, 120000);
      if (r.error) return r;
      if (!r.ok) return { error: `El servidor respondió con el código ${r.status}.` };
      return { data: r.text };
    },
    openM3UFile: async () => null,
    detectPlayers: async () => [],
    openExternal: async ({ url, title }) => {
      if (native && native.openExternal(url, title || '')) return { ok: true, player: 'otra aplicación' };
      return { error: 'No hay ninguna aplicación de vídeo instalada para abrirlo. Instala VLC desde Google Play.' };
    },
    setImmersive: (on) => native && native.setImmersive(!!on),
    setOrientation: (mode) => {
      // 13 = girar libremente, 7 = vertical, 6 = horizontal
      const v = mode === 'portrait' ? 7 : mode === 'landscape' ? 6 : 13;
      native && native.setOrientation(v);
    },
    exit: () => native && native.exit(),
    vpnStatus: async () => (native && native.isVpnActive ? !!native.isVpnActive() : null),
    isInstalled: native && native.isInstalled ? (pkg) => !!native.isInstalled(pkg) : undefined,
    openVpnApp: (pkg) => native && native.openApp && native.openApp(pkg || ''),
    setPipReady: (on) => native && native.setPipReady && native.setPipReady(!!on),
    getVolume: native && native.getVolume ? () => native.getVolume() : undefined,
    setVolume: native && native.setVolume ? (p) => native.setVolume(p | 0) : undefined,
    getBrightness: native && native.getBrightness ? () => Math.min(100, native.getBrightness()) : undefined,
    setBrightness: native && native.setBrightness ? (p) => native.setBrightness(p | 0) : undefined,
  };

  window.addEventListener('pagehide', () => save(true));
})();
