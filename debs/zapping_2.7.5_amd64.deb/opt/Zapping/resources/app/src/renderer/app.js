'use strict';

/* =====================================================================
   Zapping: reproductor IPTV (Xtream Codes y M3U)
   ===================================================================== */

const api = window.zapping;
const PLATFORM = api.platform || 'desktop';
document.documentElement.dataset.platform = PLATFORM;
// Google TV / Android TV / Fire TV: interfaz para manejar con el mando (tv.js)
const TV_DETECT = (() => {
  if (PLATFORM !== 'android') return { auto: false, why: 'ordenador' };
  const ua = navigator.userAgent || '';
  let sys = false;
  try { sys = !!api.isTv?.(); } catch {}
  let fire = false;
  try { fire = !!api.isFireTv?.(); } catch {}
  // modelos de Fire TV: «AFTMM», «AFTKA», «AFTSSS»…; otras teles: «Android TV», «GoogleTV», «BRAVIA»
  const uaTv = /\bAFT[A-Z0-9]+|Android TV|GoogleTV|BRAVIA|SMART-TV|\bTV Build/i.test(ua);
  const noTouch = (navigator.maxTouchPoints || 0) === 0 && !('ontouchstart' in window);
  fire = fire || /\bAFT[A-Z0-9]+/.test(ua);
  const auto = sys || fire || uaTv || noTouch;
  const why = fire ? 'Fire TV' : sys ? 'tele (sistema)' : uaTv ? 'tele (modelo)' : noTouch ? 'sin pantalla táctil' : 'móvil o tableta';
  return { auto, fire, why };
})();
let TV_PREF = 'auto';
try { TV_PREF = localStorage.getItem('zapping.tvMode') || JSON.parse(localStorage.getItem('zapping.v1') || '{}')?.settings?.tvMode || 'auto'; } catch {}
const IS_TV = PLATFORM === 'android' && (TV_PREF === 'on' || (TV_PREF === 'auto' && TV_DETECT.auto));
const IS_FIRE = IS_TV && !!TV_DETECT.fire;
if (IS_TV) document.documentElement.classList.add('tv');
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

/* ------------------------------------------------------------ utilidades */

function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'text') el.textContent = v;
    else if (k === 'style') el.style.cssText = v;
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  for (const c of kids.flat()) {
    if (c == null || c === false) continue;
    el.append(c instanceof Node ? c : String(c));
  }
  return el;
}

function icon(id) {
  const ns = 'http://www.w3.org/2000/svg';
  const s = document.createElementNS(ns, 'svg');
  s.setAttribute('class', 'ic');
  const u = document.createElementNS(ns, 'use');
  u.setAttribute('href', '#i-' + id);
  s.append(u);
  return s;
}

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

function norm(s) {
  return String(s || '')
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .toLowerCase();
}

function hash(str) {
  let x = 5381;
  for (let i = 0; i < str.length; i++) x = ((x << 5) + x + str.charCodeAt(i)) | 0;
  return (x >>> 0).toString(36);
}

function b64(s) {
  if (!s) return '';
  s = String(s).trim();
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(s) || s.length % 4 !== 0) return s;
  try {
    const bin = atob(s);
    const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
    return new TextDecoder('utf-8').decode(bytes);
  } catch {
    return s;
  }
}

function clock(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const hh = Math.floor(sec / 3600);
  const mm = Math.floor((sec % 3600) / 60);
  const ss = sec % 60;
  const p = (n) => String(n).padStart(2, '0');
  return hh ? `${hh}:${p(mm)}:${p(ss)}` : `${mm}:${p(ss)}`;
}

function hhmm(date) {
  return date.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
}

function longDate(ms) {
  return new Date(ms).toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });
}

function durationText(info) {
  let secs = Number(info?.duration_secs) || 0;
  if (!secs && typeof info?.duration === 'string') {
    const parts = info.duration.split(':').map(Number);
    if (parts.length === 3 && parts.every((n) => !isNaN(n))) secs = parts[0] * 3600 + parts[1] * 60 + parts[2];
  }
  if (!secs && info?.episode_run_time) secs = Number(info.episode_run_time) * 60;
  if (!secs) return '';
  const hh = Math.floor(secs / 3600);
  const mm = Math.round((secs % 3600) / 60);
  return hh ? `${hh} h ${mm} min` : `${mm} min`;
}

function initials(name) {
  const w = String(name || '?')
    .replace(/[^\p{L}\p{N} ]/gu, ' ')
    .trim()
    .split(/\s+/);
  return ((w[0] || '?')[0] + (w[1] ? w[1][0] : (w[0] || '')[1] || '')).toUpperCase();
}

function toast(msg, isErr = false, ms = 4200, id = null) {
  let t = id ? $(`#toasts [data-id="${id}"]`) : null;
  if (t) {
    t.textContent = msg;
    clearTimeout(t._timer);
  } else {
    t = h('div', { class: 'toast' + (isErr ? ' err' : ''), text: msg, dataset: id ? { id } : {} });
    $('#toasts').append(t);
  }
  t._timer = setTimeout(() => t.remove(), ms);
}

function isTyping(e) {
  const t = e.target;
  return t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);
}

function anyDialogOpen() {
  return $$('dialog').some((d) => d.open);
}

/* ------------------------------------------------------------ estado */

const S = {
  store: null,
  pl: null,
  plToken: 0,
  client: null,
  section: 'live',
  cat: 'all',
  query: '',
  catFilter: '',
  sort: 'default',
  data: {},
  detail: null,
  observers: [],
  epgCache: new Map(),
  live: { current: null, list: [], epgToken: 0, epg: [] },
  digitBuf: '',
  digitTimer: null,
  players: [],
};

const SECTION_ACTIONS = {
  live: ['get_live_categories', 'get_live_streams'],
  movies: ['get_vod_categories', 'get_vod_streams'],
  series: ['get_series_categories', 'get_series'],
};

const SECTION_WORDS = {
  live: ['canal', 'canales'],
  movies: ['película', 'películas'],
  series: ['serie', 'series'],
};

/* ------------------------------------------------------------ Xtream */

function normalizeBase(input) {
  let s = String(input || '').trim();
  if (!s) return '';
  if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
  try {
    const u = new URL(s);
    const path = u.pathname
      .replace(/\/(player_api|get|xmltv|panel_api)\.php.*$/i, '')
      .replace(/\/+$/, '');
    return u.origin + path;
  } catch {
    return s.replace(/\/+$/, '');
  }
}

function parseProviderLink(str) {
  try {
    const u = new URL(String(str).trim());
    const username = u.searchParams.get('username');
    const password = u.searchParams.get('password');
    if (username && password) {
      return { server: normalizeBase(u.origin + u.pathname), username, password, host: u.hostname };
    }
    // Formato /usuario/contraseña/123.ts
    const m = u.pathname.match(/^\/(?:live\/|movie\/|series\/)?([^/]+)\/([^/]+)\/\d+(\.\w+)?$/);
    if (m) return { server: u.origin, username: decodeURIComponent(m[1]), password: decodeURIComponent(m[2]), host: u.hostname };
  } catch {}
  return null;
}

class Xtream {
  constructor(pl) {
    this.pl = pl;
    this.base = normalizeBase(pl.server);
  }
  url(action, params = {}) {
    const q = new URLSearchParams({ username: this.pl.username, password: this.pl.password });
    if (action) q.set('action', action);
    for (const [k, v] of Object.entries(params)) q.set(k, v);
    return `${this.base}/player_api.php?${q}`;
  }
  async call(action, params) {
    const r = await api.httpJson(this.url(action, params), { ua: this.pl.ua });
    if (r.error) throw new Error(r.error);
    return r.data;
  }
  stream(kind, id, ext) {
    const u = encodeURIComponent(this.pl.username);
    const p = encodeURIComponent(this.pl.password);
    return `${this.base}/${kind}/${u}/${p}/${id}.${ext}`;
  }
}

function accountFrom(data) {
  const ui = data?.user_info || {};
  return {
    auth: Number(ui.auth) === 1,
    status: ui.status || '',
    exp: ui.exp_date ? Number(ui.exp_date) * 1000 : null,
    max: ui.max_connections != null ? Number(ui.max_connections) : null,
    active: ui.active_cons != null ? Number(ui.active_cons) : null,
    formats: Array.isArray(ui.allowed_output_formats) ? ui.allowed_output_formats : [],
    checked: Date.now(),
  };
}

function accountStatus(acc) {
  if (!acc) return null;
  const st = String(acc.status || '').toLowerCase();
  if (st === 'expired' || (acc.exp && acc.exp < Date.now())) return { text: 'Caducada', bad: true };
  if (st === 'banned' || st === 'disabled') return { text: 'Desactivada', bad: true };
  if (st === 'active') return { text: 'Activa', bad: false };
  return st ? { text: acc.status, bad: false } : null;
}

/* ------------------------------------------------------------ M3U */

function parseM3U(text) {
  const lines = String(text || '').split(/\r?\n/);
  const items = [];
  let meta = null;
  let group = '';
  for (let raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith('#EXTINF')) {
      const body = line.slice(line.indexOf(':') + 1);
      let inQ = false;
      let cut = -1;
      for (let i = 0; i < body.length; i++) {
        const c = body[i];
        if (c === '"') inQ = !inQ;
        else if (c === ',' && !inQ) {
          cut = i;
          break;
        }
      }
      const attrsPart = cut >= 0 ? body.slice(0, cut) : body;
      const name = cut >= 0 ? body.slice(cut + 1).trim() : '';
      const attrs = {};
      attrsPart.replace(/([\w-]+)="([^"]*)"/g, (_, k, v) => {
        attrs[k.toLowerCase()] = v;
      });
      meta = { name: name || attrs['tvg-name'] || 'Sin nombre', attrs };
      group = '';
    } else if (line.startsWith('#EXTGRP:')) {
      group = line.slice(8).trim();
    } else if (line.startsWith('#')) {
      continue;
    } else if (meta) {
      const a = meta.attrs;
      items.push({
        name: meta.name,
        logo: a['tvg-logo'] || '',
        group: a['group-title'] || group || '',
        tvgId: a['tvg-id'] || '',
        num: Number(a['tvg-chno'] || a['channel-number']) || 0,
        url: line,
      });
      meta = null;
    }
  }
  return items;
}

function m3uToSection(entries) {
  const groups = new Map();
  const items = entries.map((e, i) => {
    const cat = e.group ? 'g:' + e.group : '';
    if (e.group && !groups.has(cat)) groups.set(cat, e.group);
    return finishItem({
      type: 'live',
      key: 'm3u:' + hash(e.url),
      id: hash(e.url),
      name: e.name,
      logo: e.logo,
      cat,
      num: e.num || i + 1,
      url: e.url,
      epg: e.tvgId,
    });
  });
  return { cats: [...groups].map(([id, name]) => ({ id, name })), items };
}

/* ------------------------------------------------------------ elementos */

function finishItem(it) {
  it._n = norm(it.name);
  return it;
}

function mapItem(section, x) {
  const cat = String(x.category_id ?? (Array.isArray(x.category_ids) ? x.category_ids[0] : '') ?? '');
  if (section === 'live') {
    return finishItem({
      type: 'live',
      key: 'live:' + x.stream_id,
      id: String(x.stream_id),
      name: x.name || 'Sin nombre',
      logo: x.stream_icon || '',
      cat,
      num: Number(x.num) || 0,
      epg: x.epg_channel_id || '',
    });
  }
  if (section === 'movies') {
    return finishItem({
      type: 'movie',
      key: 'movie:' + x.stream_id,
      id: String(x.stream_id),
      name: x.name || 'Sin título',
      logo: x.stream_icon || x.cover || '',
      cat,
      rating: parseFloat(x.rating) || 0,
      ext: x.container_extension || 'mp4',
      added: Number(x.added) || 0,
    });
  }
  return finishItem({
    type: 'series',
    key: 'series:' + x.series_id,
    id: String(x.series_id),
    name: x.name || 'Sin título',
    logo: x.cover || '',
    cat,
    rating: parseFloat(x.rating) || 0,
    added: Number(x.last_modified) || 0,
    year: String(x.releaseDate || x.release_date || x.year || '').slice(0, 4),
  });
}

function snapshot(it) {
  const keep = ['type', 'key', 'id', 'name', 'logo', 'cat', 'num', 'ext', 'url', 'rating', 'year', 'seriesId', 'seriesName', 'season', 'episode'];
  const o = {};
  for (const k of keep) if (it[k] != null && it[k] !== '') o[k] = it[k];
  return o;
}

function makeLogo(src, name, cls = 'logo') {
  const fallback = () => h('span', { class: cls + ' logo-fallback', text: initials(name) });
  if (!src) return fallback();
  const img = h('img', { class: cls, src, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer', decoding: 'async' });
  img.addEventListener('error', () => img.replaceWith(fallback()), { once: true });
  return img;
}

/* ------------------------------------------------------------ almacén */

const pid = () => S.pl?.id;

function favs() {
  const id = pid();
  return (S.store.favorites[id] ||= {});
}
function isFav(key) {
  return !!favs()[key];
}
function toggleFav(item) {
  const f = favs();
  if (f[item.key]) delete f[item.key];
  else f[item.key] = { ...snapshot(item), at: Date.now() };
  api.setStore('favorites', S.store.favorites);
  return !!f[item.key];
}

function addRecent(item, extra = {}) {
  const id = pid();
  const list = (S.store.recent[id] ||= []);
  const i = list.findIndex((r) => r.key === item.key);
  if (i >= 0) list.splice(i, 1);
  list.unshift({ ...snapshot(item), ...extra, at: Date.now() });
  list.length = Math.min(list.length, 80);
  api.setStore('recent', S.store.recent);
}

function getProgress(key) {
  return S.store.progress[pid()]?.[key] || null;
}

let progressSaveTimer = null;
function setProgress(key, t, d) {
  const id = pid();
  const m = (S.store.progress[id] ||= {});
  m[key] = { t, d, at: Date.now() };
  clearTimeout(progressSaveTimer);
  progressSaveTimer = setTimeout(() => api.setStore('progress', S.store.progress), 1500);
}

function progressRatio(key) {
  const p = getProgress(key);
  if (!p || !p.d) return 0;
  return Math.min(1, p.t / p.d);
}

function progressBar(ratio) {
  if (!ratio) return null;
  return h('div', { class: 'progress' }, h('i', { style: `width:${Math.max(3, ratio * 100).toFixed(1)}%` }));
}

/* ------------------------------------------------------------ reproductor */

function kindOf(url) {
  const path = String(url).split(/[?#]/)[0].toLowerCase();
  if (path.endsWith('.m3u8') || path.endsWith('.m3u')) return 'hls';
  if (path.endsWith('.ts')) return 'ts';
  if (/\.(mp4|mkv|webm|m4v|mov|avi|ogv|mp3|aac)$/.test(path)) return 'native';
  return 'unknown';
}

function candidatesFor(url, { live = false } = {}) {
  const k = kindOf(url);
  // Enlaces tipo Xtream «/usuario/contraseña/123.ts»: la versión .m3u8 permite decodificar el sonido Dolby
  if (live && k === 'ts' && /\/[^/]+\/[^/]+\/\d+\.ts(\?|$)/.test(url)) {
    return [{ url, kind: 'ts' }, { url: url.replace(/\.ts(\?|$)/, '.m3u8$1'), kind: 'hls' }];
  }
  if (k === 'unknown') {
    return live
      ? [{ url, kind: 'hls' }, { url, kind: 'ts' }, { url, kind: 'native' }]
      : [{ url, kind: 'native' }, { url, kind: 'hls' }];
  }
  return [{ url, kind: k }];
}

function mediaErrorText(err) {
  switch (err?.code) {
    case 2: return 'Se ha perdido la conexión con el servidor.';
    case 3: return 'No se ha podido decodificar el vídeo.';
    case 4: return 'El reproductor integrado no admite este formato.';
    default: return 'Error desconocido al reproducir.';
  }
}

function hlsErrorText(d) {
  const code = d?.response?.code;
  if (code === 401 || code === 403) return 'El servidor ha denegado el acceso. Puede que la cuenta haya caducado o que tengas abiertas todas las conexiones permitidas.';
  if (code === 404) return 'Este canal no existe en el servidor.';
  if (code >= 500) return 'El servidor del proveedor está dando errores.';
  if (d?.details === 'manifestParsingError') return 'El servidor no ha devuelto una emisión válida.';
  if (d?.type === 'mediaError') return 'No se ha podido decodificar el vídeo (puede ser HEVC/H.265).';
  return 'No se ha podido cargar la emisión.';
}

/* Ventana flotante (Android): el sistema solo la abre si hay algo reproduciéndose */
function updatePip() {
  if (PLATFORM !== 'android') return;
  const enabled = (S.store?.settings?.pip || 'on') !== 'off';
  const live = S.section === 'live' && !!S.live.current && !!livePlayer.current;
  api.setPipReady?.(enabled && (!!theaterState || live));
}

/* ---- Audio, idiomas y subtítulos ---- */

const LANG_NAMES = {
  es: 'Español', en: 'Inglés', ca: 'Catalán', eu: 'Euskera', gl: 'Gallego', fr: 'Francés', de: 'Alemán',
  it: 'Italiano', pt: 'Portugués', ja: 'Japonés', ko: 'Coreano', zh: 'Chino', ru: 'Ruso', ar: 'Árabe', orig: 'Original',
};

function langCode(...vals) {
  for (const raw of vals) {
    const v = norm(raw).trim();
    if (!v) continue;
    const w = v.split(/[^a-z]+/).filter(Boolean);
    const has = (...xs) => xs.some((x) => w.includes(x));
    if (has('es', 'spa', 'esp', 'cas', 'castellano', 'espanol', 'spanish', 'latino', 'lat')) return 'es';
    if (has('en', 'eng', 'english', 'ingles')) return 'en';
    if (has('ca', 'cat', 'catala', 'catalan')) return 'ca';
    if (has('eu', 'eus', 'baq', 'euskera', 'basque')) return 'eu';
    if (has('gl', 'glg', 'gallego', 'galego')) return 'gl';
    if (has('fr', 'fre', 'fra', 'french', 'frances')) return 'fr';
    if (has('de', 'ger', 'deu', 'german', 'aleman')) return 'de';
    if (has('it', 'ita', 'italian', 'italiano')) return 'it';
    if (has('pt', 'por', 'portuguese', 'portugues')) return 'pt';
    if (has('ja', 'jpn', 'japanese')) return 'ja';
    if (has('ko', 'kor', 'korean')) return 'ko';
    if (has('zh', 'chi', 'zho', 'chinese')) return 'zh';
    if (has('ru', 'rus', 'russian')) return 'ru';
    if (has('ar', 'ara', 'arabic')) return 'ar';
    if (has('original', 'vo', 'vos', 'und', 'qaa', 'mul')) return 'orig';
  }
  return '';
}

function trackLabel(name, lang, i, kind = 'Pista') {
  const code = langCode(lang, name);
  const langName = LANG_NAMES[code];
  let n = String(name || '').trim();
  // nombres técnicos que no dicen nada: «SoundHandler», «audio_1», «Track 2», «und»…
  if (/^((audio|subtitles?|track|stream|pista)[_\s-]*\d*|\d+|(sound|video|subtitle|text)\s*handler|default|und|unknown)$/i.test(n)) n = '';
  // «English» → «Inglés», «Spanish» → «Español»: el nombre ya es el idioma
  if (langName && n && langCode(n) === code) return langName;
  if (n && !/^(audio|subtitles?|track|stream)?[_\s-]*\d*$/i.test(n)) {
    return langName && !norm(n).includes(norm(langName)) && code !== 'orig' ? `${n} (${langName})` : n;
  }
  return langName || `${kind} ${i + 1}`;
}

function audioCodecName(c) {
  c = String(c || '').toLowerCase();
  if (!c) return '';
  if (/ec-?3|eac3/.test(c)) return 'Dolby Digital Plus (E-AC-3)';
  if (/ac-?3/.test(c)) return 'Dolby Digital (AC-3)';
  if (/dts/.test(c)) return 'DTS';
  if (/mp2|mp4a\.6b|mp4a\.69|mpeg/.test(c)) return 'MPEG Layer II (MP2)';
  if (/mp3|mp4a\.40\.34/.test(c)) return 'MP3';
  if (/opus/.test(c)) return 'Opus';
  if (/mp4a|aac/.test(c)) return 'AAC';
  return c.toUpperCase();
}

function codecSupported(codec) {
  if (!codec) return true;
  try {
    return MediaSource.isTypeSupported(`audio/mp4; codecs="${codec}"`);
  } catch {
    return true;
  }
}

class Player {
  constructor(video, msgEl, warnEl) {
    this.video = video;
    this.msg = msgEl;
    this.warn = warnEl;
    this.hls = null;
    this.ts = null;
    this.token = 0;
    this.current = null;
    this.audioInfo = {};
    // Subtítulos que no van por hls.js (p. ej. pistas del propio archivo)
    video.textTracks.addEventListener?.('addtrack', () => this.applySubsPref());
  }

  stop() {
    this.token++;
    clearTimeout(this.watchdog);
    this._teardown();
    this.current = null;
    this.hideMsg();
    this.hideWarn();
    updatePip();
  }

  _teardown() {
    const v = this.video;
    clearTimeout(this.audioTimer);
    v.onerror = v.onplaying = v.onloadedmetadata = null;
    if (this.untap) {
      this.untap();
      this.untap = null;
    }
    if (this.soft) {
      this.soft.destroy();
      this.soft = null;
    }
    if (this.vod) {
      this.vod.destroy();
      this.vod = null;
    }
    if (this.hls) {
      try { this.hls.destroy(); } catch {}
      this.hls = null;
    }
    if (this.ts) {
      try {
        this.ts.pause();
        this.ts.unload();
        this.ts.detachMediaElement();
        this.ts.destroy();
      } catch {}
      this.ts = null;
    }
    try { v.pause(); } catch {}
    if (v.hasAttribute('src')) {
      v.removeAttribute('src');
      v.load();
    }
  }

  play(candidates, opts = {}) {
    this.token++;
    this.candidates = candidates;
    this.idx = 0;
    this.opts = opts;
    this.audioRetried = false;
    this.noVodDolby = null;
    this.lastAudioCodec = '';
    this.hideWarn();
    this.showLoading();
    this._try(this.token);
  }

  /* ¿Se está decodificando el sonido? Chrome/WebView cuentan los bytes de audio decodificados */
  _checkAudio(tok) {
    const v = this.video;
    if (tok !== this.token || (v.paused && !v.ended) || this.audioChecked) return;
    this.audioChecked = true;
    const counted = typeof v.webkitAudioDecodedByteCount === 'number';
    // Sonido Dolby decodificado por la app: aún cargando, esperar un poco más
    if (this.soft && this.soft.state === 'loading') {
      this.audioChecked = false;
      this.audioTimer = setTimeout(() => this._checkAudio(tok), 3000);
      return;
    }
    if (this.vod) {
      this.audioInfo.codec = this.vod.codec;
      this.audioInfo.soft = true;
      return;
    }
    if (this.soft?.active) {
      this.audioInfo.codec = this.soft.codec;
      this.audioInfo.soft = true;
      return;
    }
    // el decodificador aún no ha recibido la tabla de audios: esperar un poco
    if (this.soft && this.soft.state === 'probe' && !this.soft.demux.streams && (this.waitedProbe = (this.waitedProbe || 0) + 1) <= 2) {
      this.audioChecked = false;
      this.audioTimer = setTimeout(() => this._checkAudio(tok), 3000);
      return;
    }
    const silent =
      this.audioInfo.hasAudio === false ||
      (counted && v.webkitAudioDecodedByteCount === 0 && (v.webkitVideoDecodedByteCount || 0) > 0);
    if (!silent) return;
    // Silencio en una emisión con Dolby: que lo decodifique Zapping
    if (this.soft && this.soft.hasDolby && this.soft.state === 'off' && this.soft.enableDolby()) {
      this.audioChecked = false;
      clearTimeout(this.audioTimer);
      this.audioTimer = setTimeout(() => this._checkAudio(tok), 5000);
      return;
    }
    this.lastAudioCodec = this.audioInfo.codec || this.lastAudioCodec;
    // Probar el otro formato de la emisión: a veces llega con otro tipo de audio
    if (!this.audioRetried && this.idx < this.candidates.length - 1) {
      this.audioRetried = true;
      this.idx++;
      this._try(tok);
      return;
    }
    this.opts.onNoAudio?.(this.lastAudioCodec);
  }

  /* Pistas de audio y subtítulos disponibles en la emisión actual */
  tracks() {
    const v = this.video;
    const hls = this.hls;
    const audio = [];
    const subs = [];
    const vod = this.vod;
    if (vod && vod.audioTracks.length > 1) {
      vod.audioTracks.forEach((t, i) =>
        audio.push({
          label: trackLabel(t.name, t.lang, i),
          note: audioCodecName(t.codec === 'eac3' ? 'ec-3' : t.codec === 'ac3' ? 'ac-3' : t.codec),
          active: vod.audioIdx === i,
          select: () => vod.selectAudio(i),
        })
      );
    } else if (hls && hls.audioTracks && hls.audioTracks.length > 1) {
      hls.audioTracks.forEach((t, i) =>
        audio.push({
          label: trackLabel(t.name, t.lang, i),
          note: t.audioCodec && !codecSupported(t.audioCodec) ? 'sin sonido aquí' : '',
          active: hls.audioTrack === i,
          select: () => {
            hls.audioTrack = i;
          },
        })
      );
    } else if (v.audioTracks && v.audioTracks.length > 1) {
      for (let i = 0; i < v.audioTracks.length; i++) {
        const t = v.audioTracks[i];
        audio.push({
          label: trackLabel(t.label, t.language, i),
          active: t.enabled,
          select: () => {
            for (let j = 0; j < v.audioTracks.length; j++) v.audioTracks[j].enabled = j === i;
          },
        });
      }
    }
    const hlsSubs = hls && hls.subtitleTracks ? hls.subtitleTracks : [];
    hlsSubs.forEach((t, i) =>
      subs.push({
        label: trackLabel(t.name, t.lang, i, 'Subtítulos'),
        active: hls.subtitleTrack === i && hls.subtitleDisplay !== false,
        select: () => {
          this._nativeSubsOff();
          hls.subtitleDisplay = true;
          hls.subtitleTrack = i;
        },
      })
    );
    // Subtítulos del propio vídeo o subtítulos para sordos (CEA-608) que no gestiona hls.js
    for (let i = 0; i < v.textTracks.length; i++) {
      const t = v.textTracks[i];
      if (t.kind !== 'subtitles' && t.kind !== 'captions') continue;
      if (hlsSubs.length && t.kind === 'subtitles') continue;
      if (this.staleTracks?.has(t) && !(t.mode !== 'disabled' && t.cues && t.cues.length)) continue;
      subs.push({
        label: t.kind === 'captions' && !t.label ? 'Subtítulos para sordos' : trackLabel(t.label, t.language, i, 'Subtítulos'),
        active: t.mode === 'showing',
        select: () => {
          this._subsOff();
          t.mode = 'showing';
        },
      });
    }
    return { audio, subs };
  }

  _nativeSubsOff() {
    const tt = this.video.textTracks;
    for (let i = 0; i < tt.length; i++) if (tt[i].kind === 'subtitles' || tt[i].kind === 'captions') tt[i].mode = 'disabled';
  }

  _subsOff() {
    if (this.hls) {
      this.hls.subtitleTrack = -1;
      this.hls.subtitleDisplay = false;
    }
    this._nativeSubsOff();
  }

  /* Idioma de audio preferido; si una pista no se puede oír aquí, se evita */
  applyAudioPref() {
    const pref = S.store?.settings?.audioLang || 'auto';
    const hls = this.hls;
    const v = this.video;
    if (hls && hls.audioTracks && hls.audioTracks.length > 1) {
      const list = hls.audioTracks.map((t, i) => ({ i, code: langCode(t.lang, t.name), ok: codecSupported(t.audioCodec) }));
      const pick =
        (pref !== 'auto' && list.find((t) => t.code === pref && t.ok)) ||
        (!list[hls.audioTrack]?.ok && list.find((t) => t.ok)) ||
        null;
      if (pick && pick.i !== hls.audioTrack) hls.audioTrack = pick.i;
    } else if (pref !== 'auto' && v.audioTracks && v.audioTracks.length > 1) {
      let found = -1;
      for (let i = 0; i < v.audioTracks.length; i++) {
        if (langCode(v.audioTracks[i].language, v.audioTracks[i].label) === pref) {
          found = i;
          break;
        }
      }
      if (found >= 0) for (let j = 0; j < v.audioTracks.length; j++) v.audioTracks[j].enabled = j === found;
    }
  }

  /* Subtítulos según Ajustes: desactivados o en el idioma elegido */
  applySubsPref() {
    if (this.userSubs) return; // el usuario ya eligió en el menú
    const pref = S.store?.settings?.subsLang || 'off';
    const hls = this.hls;
    if (pref === 'off') {
      this._subsOff();
      return;
    }
    if (hls && hls.subtitleTracks && hls.subtitleTracks.length) {
      const i = hls.subtitleTracks.findIndex((t) => langCode(t.lang, t.name) === pref);
      hls.subtitleDisplay = i >= 0;
      hls.subtitleTrack = i;
      return;
    }
    const tt = this.video.textTracks;
    let shown = false;
    for (let i = 0; i < tt.length; i++) {
      const t = tt[i];
      if (t.kind !== 'subtitles' && t.kind !== 'captions') continue;
      const match = !shown && langCode(t.language, t.label) === pref;
      t.mode = match ? 'showing' : 'disabled';
      if (match) shown = true;
    }
  }

  showWarn(content) {
    if (!this.warn) return;
    this.warn.replaceChildren(...content);
    this.warn.classList.remove('hidden');
  }

  hideWarn() {
    this.warn?.classList.add('hidden');
  }

  get url() {
    return this.candidates?.[this.idx]?.url || this.candidates?.[0]?.url;
  }

  _try(tok) {
    this._teardown();
    const { url, kind } = this.candidates[this.idx];
    this.current = { url, kind };
    this.audioInfo = {};
    this.audioChecked = false;
    this.waitedProbe = 0;
    this.userSubs = false;
    // Las pistas de subtítulos de emisiones anteriores siguen en el vídeo: se ocultan y se ignoran
    this.staleTracks = new Set();
    for (let i = 0; i < this.video.textTracks.length; i++) {
      const t = this.video.textTracks[i];
      this.staleTracks.add(t);
      if (t.kind === 'subtitles' || t.kind === 'captions') t.mode = 'disabled';
    }
    const v = this.video;
    const start = this.opts.startAt || 0;
    let recovered = false;

    const fail = (why) => {
      if (tok !== this.token) return;
      clearTimeout(this.watchdog);
      if (this.idx < this.candidates.length - 1) {
        this.idx++;
        this._try(tok);
      } else {
        this._teardown();
        this.opts.onFail?.(why);
      }
    };

    v.onplaying = () => {
      if (tok !== this.token) return;
      clearTimeout(this.watchdog);
      this.hideMsg();
      this.opts.onPlaying?.(this.current);
      updatePip();
      if (!this.audioChecked) {
        clearTimeout(this.audioTimer);
        this.audioTimer = setTimeout(() => this._checkAudio(tok), 6000);
      }
    };
    v.onloadedmetadata = () => {
      if (tok !== this.token) return;
      if (start > 0 && isFinite(v.duration) && start < v.duration - 5) v.currentTime = start;
      this.applyAudioPref();
      this.applySubsPref();
      refreshTracksMenu();
    };

    if (kind === 'hls' && window.Hls && Hls.isSupported()) {
      // Aparta el audio Dolby (AC-3/E-AC-3) de cada trozo para decodificarlo en la app
      const soft = typeof SoftAudio === 'function' ? new SoftAudio(v) : null;
      this.soft = soft;
      const Base = Hls.DefaultConfig.loader;
      class TapLoader extends Base {
        load(context, config, callbacks) {
          const ok = callbacks.onSuccess;
          super.load(context, config, {
            ...callbacks,
            onSuccess: (resp, stats, ctx, net) => {
              try {
                if (soft && soft.state !== 'off' && ctx?.frag?.type === 'main' && resp?.data instanceof ArrayBuffer) {
                  soft.feed(new Uint8Array(resp.data));
                }
              } catch {}
              ok(resp, stats, ctx, net);
            },
          });
        }
      }
      const hls = new Hls({
        fLoader: TapLoader,
        enableWorker: true,
        backBufferLength: 30,
        manifestLoadingMaxRetry: 1,
        levelLoadingMaxRetry: 3,
        fragLoadingMaxRetry: 4,
        startPosition: start > 0 ? start : -1,
      });
      this.hls = hls;
      hls.on(Hls.Events.ERROR, (_e, d) => {
        if (!d.fatal || tok !== this.token) return;
        if (d.type === Hls.ErrorTypes.MEDIA_ERROR && !recovered) {
          recovered = true;
          hls.recoverMediaError();
          return;
        }
        fail(hlsErrorText(d));
      });
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        this.applyAudioPref();
        v.play().catch(() => {});
      });
      hls.on(Hls.Events.INIT_PTS_FOUND, (_e, d) => {
        if (d && d.id === 'main' && soft && d.timescale) soft.setTimeOffset(d.initPTS / d.timescale);
      });
      hls.on(Hls.Events.BUFFER_CODECS, (_e, d) => {
        if (tok !== this.token) return;
        const lvl = hls.levels?.[hls.currentLevel] || hls.levels?.[0];
        this.audioInfo.codec = d.audio?.codec || lvl?.audioCodec || this.audioInfo.codec;
        if (!d.audio && !hls.audioTracks?.length) this.audioInfo.hasAudio = false;
      });
      hls.on(Hls.Events.AUDIO_TRACKS_UPDATED, () => {
        this.applyAudioPref();
        refreshTracksMenu();
      });
      hls.on(Hls.Events.AUDIO_TRACK_SWITCHED, () => refreshTracksMenu());
      hls.on(Hls.Events.SUBTITLE_TRACKS_UPDATED, () => {
        this.applySubsPref();
        refreshTracksMenu();
      });
      hls.on(Hls.Events.SUBTITLE_TRACK_SWITCH, () => refreshTracksMenu());
      hls.loadSource(url);
      hls.attachMedia(v);
    } else if (kind === 'ts' && window.mpegts && mpegts.isSupported()) {
      const live = !!this.opts.live;
      // Sonido Dolby en MPEG-TS: se lee una copia de la misma descarga del reproductor
      const soft = typeof SoftAudio === 'function' ? new SoftAudio(v) : null;
      this.soft = soft;
      if (soft) this.untap = tapFetch(url, (chunk) => soft.feed(chunk));
      const p = mpegts.createPlayer(
        { type: 'mpegts', isLive: live, url },
        {
          // en el hilo principal: así la descarga pasa por fetch() de esta página y se puede copiar
          enableWorker: false,
          lazyLoad: !live,
          liveBufferLatencyChasing: live,
          liveBufferLatencyMaxLatency: 6,
          liveBufferLatencyMinRemain: 1.5,
          autoCleanupSourceBuffer: true,
        }
      );
      this.ts = p;
      p.on(mpegts.Events.MEDIA_INFO, (mi) => {
        if (tok !== this.token || !mi) return;
        this.audioInfo.codec = mi.audioCodec || this.audioInfo.codec;
        if (mi.hasAudio === false) this.audioInfo.hasAudio = false;
      });
      p.on(mpegts.Events.ERROR, (type, detail, info) => {
        const code = info?.code;
        if (code === 401 || code === 403) fail(hlsErrorText({ response: { code } }));
        else if (code === 404) fail(hlsErrorText({ response: { code } }));
        else if (type === mpegts.ErrorTypes.MEDIA_ERROR) fail('No se ha podido decodificar el vídeo (puede ser HEVC/H.265).');
        else fail('No se ha podido cargar la emisión.');
      });
      if (soft) {
        // tiempo 0 del vídeo = primer instante de la emisión según el propio reproductor (ms)
        soft.offsetProvider = () => {
          const rm = p._transmuxer?._controller?._remuxer;
          if (!rm || typeof rm.getTimestampBase !== 'function' || !rm._dtsBaseInited) return null;
          return rm.getTimestampBase() / 1000;
        };
      }
      p.attachMediaElement(v);
      p.load();
      Promise.resolve(p.play()).catch(() => {});
    } else if (this._vodDolbyOk(url, kind)) {
      // Películas y series: si el archivo trae sonido Dolby, lo reproduce Zapping (vod-dolby.js)
      const vd = new VodDolby(v, url, {
        startAt: start,
        audioLang: S.store?.settings?.audioLang || 'auto',
        onError: () => {
          if (tok !== this.token) return;
          // si falla, al reproductor normal (avisará si no suena)
          this.noVodDolby = url;
          if (v.currentTime > 1) this.opts = { ...this.opts, startAt: v.currentTime };
          this._try(tok);
        },
      });
      this.vod = vd;
      const fallback = () => {
        if (tok !== this.token || this.vod !== vd) return;
        vd.destroy();
        this.vod = null;
        this.noVodDolby = url;
        this._try(tok);
      };
      const guard = setTimeout(fallback, 12000);
      vd.open()
        .then((mine) => {
          clearTimeout(guard);
          if (tok !== this.token || this.vod !== vd) return;
          if (!mine) return fallback();
          this.audioInfo.codec = vd.codec;
          this.audioInfo.soft = true;
          v.onerror = () => fail(mediaErrorText(v.error));
          v.play().catch(() => {});
        })
        .catch((e) => {
          clearTimeout(guard);
          console.warn('[Zapping] Dolby VOD', e);
          fallback();
        });
    } else {
      v.onerror = () => fail(mediaErrorText(v.error));
      v.src = url;
      v.play().catch(() => {});
    }

    clearTimeout(this.watchdog);
    this.watchdog = setTimeout(() => {
      if (tok === this.token && v.readyState < 2) fail('El servidor no responde.');
    }, this.opts.live ? 15000 : 30000);
  }

  /* ¿Merece la pena mirar si el archivo trae Dolby? Solo películas y episodios .mkv/.mp4 */
  _vodDolbyOk(url, kind) {
    if (this.opts.live || kind !== 'native' || this.noVodDolby === url) return false;
    if (typeof VodDolby !== 'function' || !VodDolby.supported()) return false;
    const path = String(url).split(/[?#]/)[0].toLowerCase();
    return /\.(mkv|mp4|m4v|mov)$/.test(path);
  }

  showLoading() {
    this.msg.replaceChildren(h('div', { class: 'spinner' }), h('p', { text: 'Conectando…' }));
    this.msg.classList.remove('hidden');
  }

  showError(title, text, actions = []) {
    this.msg.replaceChildren(
      h('h4', { text: title }),
      h('p', { text }),
      h('div', { class: 'row' }, actions)
    );
    this.msg.classList.remove('hidden');
  }

  hideMsg() {
    this.msg.classList.add('hidden');
  }
}

const livePlayer = new Player($('#live-video'), $('#live-msg'), $('#live-warn'));
const theaterPlayer = new Player($('#theater-video'), $('#theater-msg'), $('#theater-warn'));

async function openExternal(url, title) {
  if (!url) return;
  const r = await api.openExternal({ url, title, player: S.store.settings.externalPlayer, ua: S.pl?.ua });
  if (r?.error) toast(r.error, true, 6000);
  else toast(`Abriendo en ${r.player}…`);
}

/* ------------------------------------------------------------ inicio */

function showView(id) {
  $('#home').classList.toggle('hidden', id !== 'home');
  $('#browser').classList.toggle('hidden', id !== 'browser');
}

function renderHome() {
  const grid = $('#playlist-grid');
  const pls = S.store.playlists;
  grid.replaceChildren();
  if (!pls.length) {
    grid.style.display = 'block';
    grid.append(
      h('div', { class: 'empty-home' },
        h('img', { src: 'icon.png', alt: '', width: 72, height: 72 }),
        h('h2', { text: 'Añade tu primera lista' }),
        h('p', { text: 'Introduce los datos Xtream Codes que te ha dado tu proveedor (servidor, usuario y contraseña) o la dirección de una lista M3U.' }),
        h('button', { class: 'btn primary', onclick: () => openPlaylistDialog() }, icon('plus'), h('span', { text: 'Añadir lista' }))
      )
    );
    return;
  }
  grid.style.display = '';
  for (const pl of pls) {
    const facts = [];
    if (pl.type === 'xtream') {
      const st = accountStatus(pl.account);
      if (st) facts.push(h('span', {}, 'Estado: ', h('b', { class: st.bad ? 'bad' : '', text: st.text })));
      if (pl.account) {
        facts.push(h('span', {}, 'Caduca: ', h('b', { text: pl.account.exp ? longDate(pl.account.exp) : 'sin fecha' })));
        if (pl.account.max != null) facts.push(h('span', {}, 'Conexiones: ', h('b', { text: `${pl.account.active ?? 0} de ${pl.account.max}` })));
      }
    } else {
      if (pl.count != null) facts.push(h('span', {}, h('b', { text: pl.count.toLocaleString('es-ES') }), ' canales'));
      facts.push(h('span', { text: pl.file ? 'Desde archivo' : 'Desde dirección web' }));
    }
    const card = h('div', { class: 'pl-card', tabindex: 0, role: 'button', 'aria-label': `Abrir ${pl.name}` },
      h('div', {},
        h('h3', { text: pl.name }),
        h('div', { class: 'pl-kind', text: pl.type === 'xtream' ? `Xtream Codes · ${hostOf(pl.server)}` : 'Lista M3U' })
      ),
      h('div', { class: 'pl-facts' }, facts),
      h('div', { class: 'pl-tools' },
        h('button', { class: 'icon-btn small', title: 'Editar', onclick: (e) => { e.stopPropagation(); openPlaylistDialog(pl); } }, icon('edit')),
        h('button', { class: 'icon-btn small', title: 'Eliminar', onclick: (e) => { e.stopPropagation(); removePlaylist(pl); } }, icon('trash'))
      )
    );
    card.addEventListener('click', () => openPlaylist(pl));
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && e.target === card) openPlaylist(pl);
    });
    grid.append(card);
  }
}

function hostOf(server) {
  try {
    return new URL(normalizeBase(server)).host;
  } catch {
    return server || '';
  }
}

async function removePlaylist(pl) {
  const ok = await confirmDialog(`¿Eliminar «${pl.name}»?`, 'Se borrarán también sus favoritos y el historial. Tu cuenta del proveedor no se ve afectada.');
  if (!ok) return;
  S.store.playlists = await api.deletePlaylist(pl.id);
  delete S.store.favorites[pl.id];
  delete S.store.recent[pl.id];
  delete S.store.progress[pl.id];
  renderHome();
  toast('Lista eliminada');
}

function confirmDialog(title, text) {
  const d = $('#dlg-confirm');
  $('#confirm-title').textContent = title;
  $('#confirm-text').textContent = text;
  d.returnValue = '';
  d.showModal();
  return new Promise((res) => d.addEventListener('close', () => res(d.returnValue === 'yes'), { once: true }));
}

/* ------------------------------------------------------------ diálogo de lista */

const plForm = $('#form-playlist');
let plEditing = null;
let plKind = 'xtream';
let plFile = null;
let plForce = false;

function setPlKind(kind) {
  plKind = kind;
  $$('.seg', plForm).forEach((b) => b.classList.toggle('active', b.dataset.kind === kind));
  $$('[data-for]', plForm).forEach((el) => el.classList.toggle('hidden', el.dataset.for !== kind));
  resetPlError();
}

function resetPlError() {
  $('#pl-error').classList.add('hidden');
  plForce = false;
  $('#pl-save').textContent = 'Guardar lista';
}

function plError(msg) {
  const e = $('#pl-error');
  e.textContent = msg;
  e.classList.remove('hidden');
}

function openPlaylistDialog(pl = null) {
  plEditing = pl;
  plFile = null;
  plForm.reset();
  $('#dlg-playlist-title').textContent = pl ? 'Editar lista' : 'Añadir lista';
  $('#m3u-file-name').textContent = 'o carga un archivo .m3u de tu equipo';
  const f = plForm.elements;
  if (pl) {
    f.name.value = pl.name || '';
    f.ua.value = pl.ua || '';
    if (pl.type === 'xtream') {
      f.server.value = pl.server || '';
      f.username.value = pl.username || '';
      f.password.value = pl.password || '';
    } else {
      f.url.value = pl.url || '';
      if (pl.file) $('#m3u-file-name').textContent = `Archivo actual: ${pl.file}`;
    }
    if (pl.ua) $('.advanced', plForm).open = true;
  }
  $$('.seg', plForm).forEach((b) => (b.disabled = !!pl));
  setPlKind(pl ? pl.type : 'xtream');
  f.password.type = 'password';
  $('#pl-save').disabled = false;
  $('#dlg-playlist').showModal();
  (pl ? f.name : f.paste).focus();
}

$$('.seg', plForm).forEach((b) => b.addEventListener('click', () => setPlKind(b.dataset.kind)));
$('#pl-cancel').addEventListener('click', () => $('#dlg-playlist').close());
$('#pw-toggle').addEventListener('click', () => {
  const p = plForm.elements.password;
  p.type = p.type === 'password' ? 'text' : 'password';
});
plForm.addEventListener('input', (e) => {
  if (e.target.name !== 'name') resetPlError();
});
plForm.elements.paste.addEventListener('input', (e) => {
  const info = parseProviderLink(e.target.value);
  if (!info) return;
  const f = plForm.elements;
  f.server.value = info.server;
  f.username.value = info.username;
  f.password.value = info.password;
  if (!f.name.value.trim()) f.name.value = info.host;
  toast('Datos de acceso rellenados a partir del enlace');
});
$('#btn-m3u-file').addEventListener('click', async () => {
  const r = await api.openM3UFile();
  if (!r) return;
  if (r.error) return plError(`No se pudo leer el archivo: ${r.error}`);
  plFile = r;
  const fname = r.path.split('/').pop();
  $('#m3u-file-name').textContent = fname;
  plForm.elements.url.value = '';
  if (!plForm.elements.name.value.trim()) plForm.elements.name.value = fname.replace(/\.(m3u8?|txt)$/i, '');
});

plForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  resetPlErrorKeepForce();
  const f = plForm.elements;
  const btn = $('#pl-save');
  const base = {
    id: plEditing?.id || uid(),
    type: plKind,
    name: f.name.value.trim(),
    ua: f.ua.value.trim(),
    updated: Date.now(),
    created: plEditing?.created || Date.now(),
  };

  if (plKind === 'xtream') {
    const server = normalizeBase(f.server.value);
    const username = f.username.value.trim();
    const password = f.password.value;
    if (!server || !username || !password) return plError('Rellena el servidor, el usuario y la contraseña.');
    const pl = { ...base, server, username, password, name: base.name || hostOf(server) };
    if (!plForce) {
      btn.disabled = true;
      btn.textContent = 'Comprobando…';
      try {
        const data = await new Xtream(pl).call('');
        const acc = accountFrom(data);
        if (!data?.user_info) throw new Error('El servidor no ha respondido como un servidor Xtream Codes. Revisa la dirección.');
        if (!acc.auth) {
          btn.disabled = false;
          btn.textContent = 'Guardar lista';
          return plError('El usuario o la contraseña no son correctos.');
        }
        pl.account = acc;
      } catch (err) {
        btn.disabled = false;
        plForce = true;
        btn.textContent = 'Guardar sin comprobar';
        return plError(`No se ha podido conectar: ${err.message}`);
      }
    }
    await finishSave(pl);
  } else {
    const url = f.url.value.trim();
    let text = null;
    let file = plEditing?.file || null;
    if (plFile) {
      text = plFile.text;
      file = plFile.path.split('/').pop();
    } else if (url) {
      btn.disabled = true;
      btn.textContent = 'Descargando lista…';
      const r = await api.httpText(/^https?:/i.test(url) ? url : 'http://' + url, { ua: base.ua });
      btn.disabled = false;
      btn.textContent = 'Guardar lista';
      if (r.error) return plError(`No se ha podido descargar la lista: ${r.error}`);
      text = r.data;
      file = null;
    } else if (!plEditing) {
      return plError('Escribe la dirección de la lista o elige un archivo.');
    }
    const pl = { ...base, url: plFile ? '' : url, file, name: base.name || 'Lista M3U' };
    if (text != null) {
      const entries = parseM3U(text);
      if (!entries.length) return plError('No se han encontrado canales. Comprueba que es una lista M3U válida.');
      pl.count = entries.length;
      await api.setCache(pl.id, entries);
    } else {
      pl.count = plEditing?.count;
    }
    await finishSave(pl);
  }
});

function resetPlErrorKeepForce() {
  $('#pl-error').classList.add('hidden');
}

async function finishSave(pl) {
  S.store.playlists = await api.savePlaylist(pl);
  $('#dlg-playlist').close();
  renderHome();
  toast(plEditing ? 'Lista actualizada' : 'Lista añadida');
}

/* ------------------------------------------------------------ ajustes */

async function openSettings() {
  const f = $('#form-settings').elements;
  const sel = $('#ext-player-select');
  sel.replaceChildren(h('option', { value: 'auto', text: 'Automático (el primero instalado)' }));
  const players = await api.detectPlayers();
  for (const p of players) sel.append(h('option', { value: p.id, text: p.label }));
  $('#ext-player-help').textContent = players.length
    ? `Instalados: ${players.map((p) => p.label).join(', ')}.`
    : 'No hay ningún reproductor externo instalado. Puedes instalar MPV o VLC desde el Gestor de software.';
  const st = S.store.settings;
  f.liveFormat.value = st.liveFormat || 'm3u8';
  f.externalPlayer.value = players.some((p) => p.id === st.externalPlayer) ? st.externalPlayer : 'auto';
  f.defaultSection.value = st.defaultSection || 'live';
  f.menuLayout.value = st.menuLayout || 'auto';
  f.orientation.value = st.orientation || 'auto';
  f.pip.value = st.pip || 'on';
  f.posterSize.value = st.posterSize || 'm';
  f.extEpg.value = st.extEpg || 'on';
  f.epgPrefer.value = st.epgPrefer || 'provider';
  f.epgFix.value = st.epgFix || 'auto';
  f.tvMode.value = TV_PREF;
  f.secureDns.value = st.secureDns || 'on';
  $('#tv-mode-help').textContent = `Detectado: ${TV_DETECT.why}. Ahora: ${IS_TV ? 'modo tele activado' : 'modo táctil'}. Navegador del sistema: ${(navigator.userAgent.match(/Chrome\/([\d.]+)/) || [])[1] || 'desconocido'}.`;
  f.audioLang.value = st.audioLang || 'auto';
  f.subsLang.value = st.subsLang || 'off';
  f.noAudio.value = st.noAudio || 'ask';
  f.extEpgUrl.value = st.extEpgUrl || '';
  const age = XmlTv.data?.at ? Math.round((Date.now() - XmlTv.data.at) / 60000) : null;
  $('#ext-epg-help').textContent = XmlTv.error
    ? `No se pudo descargar la última vez: ${XmlTv.error}`
    : age != null
      ? `Descargada hace ${age < 60 ? `${age} min` : `${Math.round(age / 60)} h`}; se renueva cada 6 horas.`
      : 'Se descarga la primera vez que hace falta y se renueva cada 6 horas.';
  const vsel = $('#vpn-app-select');
  const apps = installedVpnApps();
  vsel.replaceChildren(
    ...apps.map(([p, n]) => h('option', { value: p, text: n })),
    h('option', { value: 'settings', text: 'Ajustes de VPN de Android' })
  );
  vsel.value = apps.some(([p]) => p === st.vpnApp) || st.vpnApp === 'settings' ? st.vpnApp : apps[0]?.[0] || 'settings';
  $('#vpn-app-help').textContent = apps.length
    ? 'Es la app que se abre cuando un canal marcado con VPN se pone sin la VPN activada.'
    : 'No se ha encontrado ninguna app de VPN conocida; se abrirán los ajustes de VPN de Android.';
  $('#dlg-settings').showModal();
}

$('#form-settings').addEventListener('submit', (e) => {
  e.preventDefault();
  const f = e.target.elements;
  S.store.settings = {
    ...S.store.settings,
    liveFormat: f.liveFormat.value,
    externalPlayer: f.externalPlayer.value,
    defaultSection: f.defaultSection.value,
    menuLayout: f.menuLayout.value,
    orientation: f.orientation.value,
    pip: f.pip.value,
    vpnApp: f.vpnApp.value,
    posterSize: f.posterSize.value,
    extEpg: f.extEpg.value,
    epgPrefer: f.epgPrefer.value,
    epgFix: f.epgFix.value,
    tvMode: f.tvMode.value,
    secureDns: f.secureDns.value,
    audioLang: f.audioLang.value,
    subsLang: f.subsLang.value,
    noAudio: f.noAudio.value,
    extEpgUrl: f.extEpgUrl.value.trim(),
  };
  // si cambia la guía externa, volver a pedir la programación
  if (S.epgCache) {
    S.epgCache = new Map();
    if (S.live.current && S.section === 'live') loadEPG(S.live.current);
    if (S.section === 'live') renderContent();
  }
  applyPosterSize();
  updatePip();
  const tvChanged = (S.store.settings.tvMode || 'auto') !== TV_PREF;
  try { localStorage.setItem('zapping.tvMode', S.store.settings.tvMode || 'auto'); } catch {}
  api.setStore('settings', S.store.settings);
  // el modo tele se aplica al volver a cargar la interfaz
  if (tvChanged) setTimeout(() => location.reload(), 300);
  applyOrientation();
  applyLayout();
  $('#dlg-settings').close();
  toast('Ajustes guardados');
});
$('#settings-cancel').addEventListener('click', () => $('#dlg-settings').close());

/* ------------------------------------------------------------ abrir lista */

async function openPlaylist(pl) {
  S.pl = pl;
  S.plToken++;
  S.data = {};
  S.epgCache = new Map();
  epgCancelQueued();
  S.detail = null;
  S.cat = 'all';
  S.query = '';
  S.catFilter = '';
  S.sort = 'default';
  S.live.current = null;
  $('#search').value = '';
  $('#cat-filter').value = '';
  $('#sort').value = 'default';
  await api.setUserAgent(pl.ua || '');
  S.client = pl.type === 'xtream' ? new Xtream(pl) : null;

  $('#pl-name').textContent = pl.name;
  updatePlMeta();
  const isM3U = pl.type === 'm3u';
  $$('.rail-btn[data-section="movies"], .rail-btn[data-section="series"]').forEach((b) => b.classList.toggle('hidden', isM3U));
  resetLiveStage();
  showView('browser');
  const sec = isM3U ? 'live' : S.store.settings.defaultSection || 'live';
  switchSection(sec);

  if (S.client) {
    const tok = S.plToken;
    S.client
      .call('')
      .then(async (data) => {
        if (tok !== S.plToken || !data?.user_info) return;
        pl.account = accountFrom(data);
        S.store.playlists = await api.savePlaylist(pl);
        S.pl = S.store.playlists.find((p) => p.id === pl.id) || pl;
        S.client.pl = S.pl;
        updatePlMeta();
        const st = accountStatus(pl.account);
        if (st?.bad) toast(`La cuenta está ${st.text.toLowerCase()}.`, true, 7000);
      })
      .catch(() => {});
  }
}

function updatePlMeta() {
  const pl = S.pl;
  let t = 'Lista M3U';
  if (pl.type === 'xtream') {
    const st = accountStatus(pl.account);
    t = pl.account?.exp ? `Caduca el ${longDate(pl.account.exp)}` : 'Xtream Codes';
    if (st?.bad) t = `Cuenta ${st.text.toLowerCase()}`;
  }
  $('#pl-meta').textContent = t;
}

function goHome() {
  livePlayer.stop();
  closeTheater();
  S.pl = null;
  S.plToken++;
  clearObservers();
  showView('home');
  renderHome();
}

/* ------------------------------------------------------------ carga de datos */

async function loadSection(sec, force = false, quiet = false) {
  if (!['live', 'movies', 'series'].includes(sec)) return;
  const tok = S.plToken;
  let d = S.data[sec];
  if (d && !force && (d.status === 'ready' || d.status === 'loading')) return d.promise;
  const prev = d;
  const keepOld = quiet && prev?.status === 'ready';
  d = { status: 'loading', cats: [], items: [] };
  if (!keepOld) {
    S.data[sec] = d;
    if (S.section === sec) renderSection();
  }

  d.promise = (async () => {
    try {
      if (S.pl.type === 'm3u') {
        let entries = force ? null : await api.getCache(S.pl.id);
        if (!entries) {
          if (!S.pl.url) {
            if (force) throw new Error('Esta lista se cargó desde un archivo. Para actualizarla, edítala y vuelve a elegir el archivo.');
            throw new Error('No se encuentra la copia local de la lista. Edítala y vuelve a elegir el archivo.');
          }
          const r = await api.httpText(S.pl.url, { ua: S.pl.ua });
          if (r.error) throw new Error(r.error);
          entries = parseM3U(r.data);
          if (!entries.length) throw new Error('La dirección ya no devuelve una lista M3U válida.');
          await api.setCache(S.pl.id, entries);
          if (S.pl.count !== entries.length) {
            S.pl.count = entries.length;
            S.store.playlists = await api.savePlaylist(S.pl);
          }
        }
        Object.assign(d, m3uToSection(entries));
      } else {
        const [ca, sa] = SECTION_ACTIONS[sec];
        const [cats, items] = await Promise.all([S.client.call(ca), S.client.call(sa)]);
        const catArr = Array.isArray(cats) ? cats : Object.values(cats || {});
        const itArr = Array.isArray(items) ? items : Object.values(items || {});
        d.cats = catArr.map((c) => ({ id: String(c.category_id), name: c.category_name || 'Sin nombre' }));
        d.items = itArr.filter((x) => x && typeof x === 'object').map((x) => mapItem(sec, x));
      }
      d.counts = new Map();
      for (const it of d.items) d.counts.set(it.cat, (d.counts.get(it.cat) || 0) + 1);
      d.status = 'ready';
    } catch (e) {
      d.status = 'error';
      d.error = e.message;
    }
    if (tok !== S.plToken) return;
    if (keepOld) {
      // si falla, se conserva la lista anterior
      if (d.status !== 'ready') return toast(`No se ha podido actualizar: ${d.error}`, true, 6000);
      S.data[sec] = d;
    }
    if (S.section === sec) {
      const scroll = $('#content-body').scrollTop;
      renderSection();
      if (keepOld) $('#content-body').scrollTop = scroll;
      if (sec === 'live' && S.live.current) markActiveChannel(false);
    }
  })();
  if (keepOld) prev.refreshing = d.promise;
  return d.promise;
}

const SECTION_DONE = {
  live: (n) => `Canales actualizados: ${n.toLocaleString('es-ES')}`,
  movies: (n) => `Películas actualizadas: ${n.toLocaleString('es-ES')}`,
  series: (n) => `Series actualizadas: ${n.toLocaleString('es-ES')}`,
};

async function refreshSection() {
  const sec = S.section;
  if (!['live', 'movies', 'series'].includes(sec)) {
    toast('Abre Directo, Películas o Series para actualizarlas.');
    return;
  }
  const btns = [$('#btn-refresh'), $('#rail-refresh')];
  if (btns[0].classList.contains('spinning')) return;
  btns.forEach((b) => b.classList.add('spinning'));
  if (S.detail) closeDetail();
  // las demás secciones se recargarán al abrirlas
  for (const other of ['live', 'movies', 'series']) if (other !== sec) delete S.data[other];
  if (sec === 'live') {
    epgCancelQueued();
    S.epgCache = new Map();
  }
  const before = S.data[sec];
  await loadSection(sec, true, true);
  btns.forEach((b) => b.classList.remove('spinning'));
  const d = S.data[sec];
  if (d !== before && d?.status === 'ready') toast(SECTION_DONE[sec](d.items.length));
}

/* ------------------------------------------------------------ secciones */

function clearObservers() {
  S.observers.forEach((o) => o.disconnect());
  S.observers = [];
}

function switchSection(sec) {
  closeCatSheet();
  if (sec !== 'live' && S.section === 'live') resetLiveStage();
  S.section = sec;
  S.cat = 'all';
  S.query = '';
  S.catFilter = '';
  S.detail = null;
  $('#search').value = '';
  $('#cat-filter').value = '';
  renderSection();
  loadSection(sec);
}

function renderSection() {
  const sec = S.section;
  $$('.rail-btn[data-section]').forEach((b) => b.classList.toggle('active', b.dataset.section === sec));
  const browser = $('#browser');
  const isLib = sec === 'favorites' || sec === 'recent';
  browser.classList.toggle('mode-live', sec === 'live');
  browser.classList.toggle('hide-cats', isLib);
  $('#live-stage').classList.toggle('hidden', sec !== 'live');
  $('#sort-wrap').classList.toggle('hidden', sec === 'live' || isLib || !!S.detail);
  $('#btn-refresh').classList.toggle('hidden', isLib);
  $('#size-wrap').classList.toggle('hidden', sec === 'live');
  closeSizeMenu();
  $('#btn-refresh').title = { live: 'Actualizar la lista de canales', movies: 'Actualizar las películas', series: 'Actualizar las series' }[sec] || 'Actualizar';
  $('.content-head').classList.toggle('hidden', !!S.detail);
  const placeholders = { live: 'Buscar canales', movies: 'Buscar películas', series: 'Buscar series', favorites: 'Buscar en favoritos', recent: 'Buscar en recientes' };
  $('#search').placeholder = placeholders[sec];
  renderCats();
  renderContent();
}

function renderCats() {
  const list = $('#cat-list');
  list.replaceChildren();
  const btn = $('#cat-open');
  const d = S.data[S.section];
  if (!d || d.status !== 'ready') {
    btn.classList.add('empty');
    return;
  }
  btn.classList.remove('empty');
  const cur = S.cat === 'all' ? null : d.cats.find((c) => c.id === S.cat);
  $('#cat-open-label').textContent = cur ? cur.name : 'Todas las categorías';
  $('#cat-open-count').textContent = (cur ? d.counts.get(cur.id) || 0 : d.items.length).toLocaleString('es-ES');
  const q = norm(S.catFilter);
  const all = h('li', { class: S.cat === 'all' ? 'active' : '', role: 'option', tabindex: 0, dataset: { cat: 'all' } },
    h('span', { class: 'cname', text: 'Todas' }),
    h('span', { class: 'ccount', text: d.items.length.toLocaleString('es-ES') })
  );
  if (!q) list.append(all);
  let shown = 0;
  for (const c of d.cats) {
    const n = d.counts.get(c.id) || 0;
    if (q && !norm(c.name).includes(q)) continue;
    shown++;
    list.append(
      h('li', { class: S.cat === c.id ? 'active' : '', role: 'option', tabindex: 0, dataset: { cat: c.id }, title: c.name },
        h('span', { class: 'cname', text: c.name }),
        h('span', { class: 'ccount', text: n.toLocaleString('es-ES') })
      )
    );
  }
  if (q && !shown) list.append(h('li', { class: 'cat-empty', text: `Ninguna categoría contiene «${S.catFilter.trim()}».` }));
}

$('#cat-list').addEventListener('click', (e) => {
  const li = e.target.closest('li[data-cat]');
  if (!li) return;
  S.cat = li.dataset.cat;
  S.detail = null;
  closeCatSheet();
  $$('#cat-list li').forEach((x) => x.classList.toggle('active', x === li));
  renderSection();
  $('#content-body').scrollTop = 0;
});

/* Panel de categorías en pantallas compactas */
function openCatSheet() {
  document.body.classList.add('cats-open');
  const active = $('#cat-list li.active');
  if (active) active.scrollIntoView({ block: 'center' });
}
function closeCatSheet() {
  document.body.classList.remove('cats-open');
}
$('#cat-open').addEventListener('click', openCatSheet);
$('#cats-close').addEventListener('click', closeCatSheet);

function filteredItems() {
  const d = S.data[S.section];
  if (!d || d.status !== 'ready') return [];
  const q = norm(S.query);
  let items = d.items;
  if (S.cat !== 'all') items = items.filter((it) => it.cat === S.cat);
  if (q) items = items.filter((it) => it._n.includes(q));
  if (S.section !== 'live' && S.sort !== 'default') {
    items = items.slice();
    if (S.sort === 'name') items.sort((a, b) => a.name.localeCompare(b.name, 'es'));
    else if (S.sort === 'added') items.sort((a, b) => (b.added || 0) - (a.added || 0));
    else if (S.sort === 'rating') items.sort((a, b) => (b.rating || 0) - (a.rating || 0));
  }
  return items;
}

function stateView(kind, title, text, actions = []) {
  return h('div', { class: 'state' },
    kind === 'loading' ? h('div', { class: 'spinner' }) : null,
    title ? h('h3', { text: title }) : null,
    text ? h('p', { text }) : null,
    actions.length ? h('div', { class: 'row', style: 'display:flex;gap:10px' }, actions) : null
  );
}

function renderChunked(container, items, make, { chunk = 150, sentinelTag = 'div' } = {}) {
  let i = 0;
  const sentinel = h(sentinelTag, { class: 'sentinel' });
  container.append(sentinel);
  let obs = null;
  const add = () => {
    const frag = document.createDocumentFragment();
    const end = Math.min(i + chunk, items.length);
    for (; i < end; i++) frag.append(make(items[i], i));
    sentinel.before(frag);
    if (i >= items.length) {
      obs?.disconnect();
      sentinel.remove();
    }
  };
  add();
  if (i < items.length) {
    obs = new IntersectionObserver((es) => es.some((x) => x.isIntersecting) && add(), {
      root: $('#content-body'),
      rootMargin: '900px',
    });
    obs.observe(sentinel);
    S.observers.push(obs);
  }
  return { ensure: (idx) => { while (i <= idx && i < items.length) add(); } };
}

let liveListCtl = null;

function renderContent() {
  clearObservers();
  epgCancelQueued();
  rowEpgObs?.disconnect();
  const body = $('#content-body');
  body.replaceChildren();
  const sec = S.section;

  if (sec === 'favorites' || sec === 'recent') return renderLibrary(body);
  if (S.detail) return renderDetail(body);

  const d = S.data[sec];
  const words = SECTION_WORDS[sec];
  if (!d || d.status === 'loading') {
    $('#count').textContent = '';
    body.append(stateView('loading', null, `Cargando ${words[1]}…`));
    return;
  }
  if (d.status === 'error') {
    $('#count').textContent = '';
    body.append(stateView('error', `No se han podido cargar las ${sec === 'live' ? 'emisiones' : words[1]}`, d.error, [
      h('button', { class: 'btn primary', onclick: () => loadSection(sec, true) }, icon('refresh'), h('span', { text: 'Reintentar' })),
    ]));
    return;
  }

  const items = filteredItems();
  $('#count').textContent = `${items.length.toLocaleString('es-ES')} ${items.length === 1 ? words[0] : words[1]}`;
  if (!items.length) {
    body.append(
      S.query
        ? stateView('empty', 'Sin resultados', `No hay ${words[1]} que coincidan con «${S.query}»${S.cat !== 'all' ? ' en esta categoría' : ''}.`)
        : stateView('empty', 'Categoría vacía', `Esta categoría no tiene ${words[1]}.`)
    );
    return;
  }

  if (sec === 'live') {
    S.live.list = items;
    const ul = h('ul', { class: 'ch-list', role: 'listbox', 'aria-label': 'Canales' });
    body.append(ul);
    liveListCtl = renderChunked(ul, items, (it, i) => channelRow(it, i), { sentinelTag: 'li' });
    markActiveChannel(false);
  } else {
    const grid = h('div', { class: 'poster-grid' });
    body.append(grid);
    renderChunked(grid, items, (it) => posterCard(it), { chunk: 90 });
  }
}

function channelRow(it, i, { onClick } = {}) {
  const fav = isFav(it.key);
  const star = h('button', { class: 'icon-btn small star' + (fav ? ' on' : ''), title: fav ? 'Quitar de favoritos' : 'Añadir a favoritos' }, icon('star'));
  star.addEventListener('click', (e) => {
    e.stopPropagation();
    const on = toggleFav(it);
    star.classList.toggle('on', on);
    star.title = on ? 'Quitar de favoritos' : 'Añadir a favoritos';
    if (S.live.current?.key === it.key) updateLiveFavButton();
  });
  const li = h('li', { class: 'ch', role: 'option', tabindex: 0, dataset: { key: it.key, name: it.name } },
    h('span', { class: 'ch-num', text: it.num || i + 1 }),
    makeLogo(it.logo, it.name),
    h('span', { class: 'ch-text' },
      h('span', { class: 'ch-name-row' },
        h('span', { class: 'ch-name', text: it.name }),
        usesVpn(it) ? h('span', { class: 'ch-vpn', title: 'Usa VPN' }, icon('shield')) : null
      ),
      it.type === 'live' && hasAnyEpg() ? h('span', { class: 'ch-now empty' }) : null
    ),
    star
  );
  li.title = it.name;
  if (it.type === 'live' && hasAnyEpg()) observeRowEpg(li, it);
  li.addEventListener('click', () => (onClick ? onClick(it) : playLive(it)));
  li.addEventListener('dblclick', () => toggleLiveFullscreen());
  return li;
}

function posterCard(it, { onClick } = {}) {
  const key = it.type === 'episode' ? it.key : it.key;
  const ratio = it.type === 'movie' || it.type === 'episode' ? progressRatio(key) : 0;
  const img = h('div', { class: 'poster-img' });
  if (it.logo) {
    const im = h('img', { src: it.logo, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer', decoding: 'async' });
    im.addEventListener('error', () => im.replaceWith(h('div', { class: 'ph', text: it.name })), { once: true });
    img.append(im);
  } else {
    img.append(h('div', { class: 'ph', text: it.name }));
  }
  if (it.rating) img.append(h('span', { class: 'rating', text: (it.rating > 10 ? it.rating / 10 : it.rating).toFixed(1) }));
  const bar = progressBar(ratio);
  if (bar) img.append(bar);
  const sub = it.type === 'episode' ? `T${it.season} E${it.episode}` : it.year || '';
  const card = h('div', { class: 'poster', tabindex: 0, role: 'button', title: it.name },
    img,
    h('div', { class: 'poster-title', text: it.type === 'episode' ? it.seriesName || it.name : it.name }),
    sub ? h('div', { class: 'poster-sub', text: sub }) : null
  );
  const go = () => (onClick ? onClick(it) : openDetail(it));
  card.addEventListener('click', go);
  card.addEventListener('keydown', (e) => e.key === 'Enter' && go());
  return card;
}

/* ------------------------------------------------------------ búsqueda */

let searchTimer = null;
$('#search').addEventListener('input', (e) => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    S.query = e.target.value.trim();
    renderContent();
    $('#content-body').scrollTop = 0;
  }, 160);
});
$('#cat-filter').addEventListener('input', (e) => {
  S.catFilter = e.target.value;
  renderCats();
});
$('#sort').addEventListener('change', (e) => {
  S.sort = e.target.value;
  renderContent();
});

/* ------------------------------------------------------------ directo */

function resetLiveStage() {
  toggleGuide(false);
  stopVpnWait();
  $('#vpn-pill').classList.add('hidden');
  livePlayer.stop();
  $('#live-video').removeAttribute('controls');
  S.live.current = null;
  S.live.epgToken++;
  $('#live-idle').classList.remove('hidden');
  $('#live-info').classList.add('hidden');
  $('#osd').classList.remove('show');
}

function liveCandidates(it) {
  if (it.url) return candidatesFor(it.url, { live: true });
  const pref = S.store.settings.liveFormat === 'ts' ? ['ts', 'm3u8'] : ['m3u8', 'ts'];
  const allowed = S.pl.account?.formats || [];
  const order = allowed.length ? pref.filter((f) => allowed.includes(f)).concat(pref.filter((f) => !allowed.includes(f))) : pref;
  return order.map((fmt) => ({ url: S.client.stream('live', it.id, fmt), kind: fmt === 'ts' ? 'ts' : 'hls' }));
}

function catName(sec, id) {
  return S.data[sec]?.cats.find((c) => c.id === id)?.name || '';
}

function playLive(it) {
  closeTheater();
  S.live.current = it;
  $('#live-idle').classList.add('hidden');
  $('#live-info').classList.remove('hidden');
  $('#live-video').setAttribute('controls', '');
  $('#live-title').textContent = it.name;
  $('#live-cat').textContent = catName('live', it.cat);
  updateLiveFavButton();
  markActiveChannel(true);
  const listIdx = S.live.list.findIndex((x) => x.key === it.key);
  showOSD(it.num || (listIdx >= 0 ? listIdx + 1 : ''), it.name);

  updateLiveVpnButton();
  addRecent(it);
  loadEPG(it);
  stopVpnWait();
  $('#vpn-pill').classList.add('hidden');
  if (usesVpn(it)) {
    livePlayer.stop();
    livePlayer.showLoading();
    Promise.resolve(api.vpnStatus?.()).then((on) => {
      if (S.live.current !== it) return;
      if (on === false) waitForVpn(it);
      else startLive(it, on === true);
    });
  } else {
    startLive(it, false);
  }
}

function startLive(it, viaVpn) {
  stopVpnWait();
  $('#vpn-pill').classList.toggle('hidden', !viaVpn);
  livePlayer.play(liveCandidates(it), {
    live: true,
    onNoAudio: (codec) => handleNoAudio(livePlayer, liveCandidates(it)[0].url, it.name, codec),
    onFail: (why) => {
      livePlayer.showError('No se puede reproducir este canal', why, [
        h('button', { class: 'btn ghost', onclick: () => playLive(it) }, icon('refresh'), h('span', { text: 'Reintentar' })),
        h('button', { class: 'btn primary', onclick: () => openExternal(liveCandidates(it)[0].url, it.name) }, icon('external'), h('span', { text: 'Abrir en reproductor externo' })),
      ]);
    },
  });
}

/* ---- VPN por canal ---- */

const VPN_APPS = [
  ['ch.protonvpn.android', 'Proton VPN'],
  ['com.nordvpn.android', 'NordVPN'],
  ['com.surfshark.vpnclient.android', 'Surfshark'],
  ['com.expressvpn.vpn', 'ExpressVPN'],
  ['de.mobileapp.angeloo', 'CyberGhost'],
  ['com.windscribe.vpn', 'Windscribe'],
  ['com.privateinternetaccess.android', 'Private Internet Access'],
  ['net.mullvad.mullvadvpn', 'Mullvad VPN'],
  ['io.privado.android', 'PrivadoVPN'],
  ['hideme.android.vpn', 'hide.me'],
  ['com.tunnelbear.android', 'TunnelBear'],
  ['hotspotshield.android.vpn', 'Hotspot Shield'],
  ['com.cloudflare.onedotonedotonedotone', '1.1.1.1 (WARP)'],
  ['net.openvpn.openvpn', 'OpenVPN Connect'],
  ['de.blinkt.openvpn', 'OpenVPN para Android'],
  ['com.wireguard.android', 'WireGuard'],
];

function vpnMap() {
  S.store.vpn ||= {};
  return (S.store.vpn[pid()] ||= {});
}
function usesVpn(it) {
  return !!it && !!vpnMap()[it.key];
}
function toggleVpn(it) {
  const m = vpnMap();
  if (m[it.key]) delete m[it.key];
  else m[it.key] = true;
  api.setStore('vpn', S.store.vpn);
  return !!m[it.key];
}

function installedVpnApps() {
  if (!api.isInstalled) return [];
  return VPN_APPS.filter(([pkg]) => api.isInstalled(pkg));
}

function vpnApp() {
  const pref = S.store.settings.vpnApp || 'auto';
  if (pref === 'settings') return { pkg: '', name: 'los ajustes de VPN' };
  const inst = installedVpnApps();
  const f = inst.find(([p]) => p === pref) || inst[0];
  return f ? { pkg: f[0], name: f[1] } : { pkg: '', name: 'los ajustes de VPN' };
}

function stopVpnWait() {
  clearInterval(S.live.vpnPoll);
  S.live.vpnPoll = null;
  S.live.vpnWait = null;
}

function waitForVpn(it) {
  livePlayer.stop();
  S.live.vpnWait = it;
  const app = vpnApp();
  const android = PLATFORM === 'android';
  livePlayer.showError(
    'Este canal usa VPN',
    android
      ? 'La VPN no está activada. Actívala y el canal empezará solo en cuanto esté conectada.'
      : 'La VPN no está activada. Conéctala y el canal empezará solo.',
    [
      android
        ? h('button', { class: 'btn primary', onclick: () => api.openVpnApp?.(app.pkg) }, icon('shield'),
            h('span', { text: app.pkg ? `Abrir ${app.name}` : 'Abrir ajustes de VPN' }))
        : null,
      h('button', { class: 'btn ghost', onclick: () => startLive(it, false) }, h('span', { text: 'Ver sin VPN' })),
    ].filter(Boolean)
  );
  clearInterval(S.live.vpnPoll);
  S.live.vpnPoll = setInterval(async () => {
    if (S.live.vpnWait !== it || S.live.current !== it) return stopVpnWait();
    if ((await api.vpnStatus?.()) === true && S.live.vpnWait === it) startLive(it, true);
  }, 2000);
}

function updateLiveVpnButton() {
  const b = $('#live-vpn');
  const on = usesVpn(S.live.current);
  b.classList.toggle('active', on);
  b.title = on ? 'Este canal usa VPN (pulsa para quitarla)' : 'Usar VPN en este canal';
}

function paintRowVpn(li, on) {
  const row = li.querySelector('.ch-name-row');
  if (!row) return;
  row.querySelector('.ch-vpn')?.remove();
  if (on) row.append(h('span', { class: 'ch-vpn', title: 'Usa VPN' }, icon('shield')));
}

$('#live-vpn').addEventListener('click', () => {
  const it = S.live.current;
  if (!it) return;
  const on = toggleVpn(it);
  updateLiveVpnButton();
  const row = $(`.ch[data-key="${CSS.escape(it.key)}"]`);
  if (row) paintRowVpn(row, on);
  toast(on ? 'Este canal usará VPN' : 'Este canal ya no usa VPN');
  playLive(it);
});

function markActiveChannel(scroll) {
  const cur = S.live.current;
  $$('.ch.active').forEach((el) => el.classList.remove('active'));
  if (!cur) return;
  const idx = S.live.list.findIndex((x) => x.key === cur.key);
  if (idx >= 0 && liveListCtl) liveListCtl.ensure(idx);
  const row = $(`.ch[data-key="${CSS.escape(cur.key)}"]`);
  if (row) {
    row.classList.add('active');
    if (scroll) row.scrollIntoView({ block: 'nearest' });
  }
}

function updateLiveFavButton() {
  const b = $('#live-fav');
  const on = S.live.current && isFav(S.live.current.key);
  b.classList.toggle('on', !!on);
  b.title = on ? 'Quitar de favoritos' : 'Añadir a favoritos';
}

$('#live-fav').addEventListener('click', () => {
  const it = S.live.current;
  if (!it) return;
  toggleFav(it);
  updateLiveFavButton();
  const star = $(`.ch[data-key="${CSS.escape(it.key)}"] .star`);
  if (star) star.classList.toggle('on', isFav(it.key));
});
$('#live-ext').addEventListener('click', () => {
  const it = S.live.current;
  if (it) openExternal(livePlayer.url || liveCandidates(it)[0].url, it.name);
});
$('#live-full').addEventListener('click', () => toggleLiveFullscreen());
$('#live-video').addEventListener('dblclick', () => toggleLiveFullscreen());

function isFull() {
  return !!document.fullscreenElement || !!$('.pseudo-fs');
}

function enterFull(el) {
  if (PLATFORM === 'android') {
    el.classList.add('pseudo-fs');
    api.setImmersive?.(true);
    if ((S.store.settings.orientation || 'auto') !== 'portrait') api.setOrientation?.('landscape');
  } else {
    el.requestFullscreen().catch(() => {});
  }
}

function exitFull() {
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  const wasPseudo = !!$('.pseudo-fs');
  $$('.pseudo-fs').forEach((el) => el.classList.remove('pseudo-fs'));
  if (PLATFORM === 'android' && !theaterState) api.setImmersive?.(false);
  if (wasPseudo) applyOrientation();
}

function toggleLiveFullscreen() {
  if (isFull()) exitFull();
  else if (S.live.current) enterFull($('#live-box'));
}

/* Gestos en el reproductor: mitad izquierda brillo, mitad derecha volumen */
const Gestures = {
  getVol(v) {
    return api.getVolume ? api.getVolume() : Math.round((v.muted ? 0 : v.volume) * 100);
  },
  setVol(v, p) {
    if (api.setVolume) api.setVolume(p);
    else {
      v.volume = p / 100;
      v.muted = p === 0;
    }
  },
  getBri(v) {
    return api.getBrightness ? api.getBrightness() : v._bri ?? 100;
  },
  setBri(v, p) {
    if (api.setBrightness) api.setBrightness(Math.max(1, p));
    else {
      v._bri = p;
      v.style.filter = p >= 100 ? '' : `brightness(${(0.2 + 0.8 * p / 100).toFixed(2)})`;
    }
  },
};

function attachGestures(box, video) {
  const hud = h('div', { class: 'gesture-hud', 'aria-hidden': 'true' },
    h('span', { class: 'hud-ic' }),
    h('div', { class: 'hud-bar' }, h('i')),
    h('span', { class: 'hud-val' })
  );
  box.append(hud);
  let g = null;
  let hideT = null;

  const show = (kind, p) => {
    const name = kind === 'vol' ? (p === 0 ? 'mute' : 'volume') : 'sun';
    hud.querySelector('.hud-ic').replaceChildren(icon(name));
    hud.querySelector('.hud-bar i').style.width = p + '%';
    hud.querySelector('.hud-val').textContent = `${kind === 'vol' ? 'Volumen' : 'Brillo'} ${p} %`;
    hud.classList.add('show');
    clearTimeout(hideT);
  };

  box.addEventListener('touchstart', (e) => {
    g = null;
    if (e.touches.length !== 1 || !video.hasAttribute('src') && !video.srcObject && !video.currentSrc) return;
    const t = e.touches[0];
    const r = box.getBoundingClientRect();
    const yIn = t.clientY - r.top;
    // no tocar la barra de controles del vídeo ni la zona superior
    if (yIn < 44 || yIn > r.height - 60) return;
    g = { x0: t.clientX, y0: t.clientY, h: r.height, kind: t.clientX - r.left < r.width / 2 ? 'bri' : 'vol', active: false, last: -1 };
  }, { passive: true });

  box.addEventListener('touchmove', (e) => {
    if (!g) return;
    const t = e.touches[0];
    const dy = g.y0 - t.clientY;
    const dx = t.clientX - g.x0;
    if (!g.active) {
      if (Math.abs(dx) > 28 && Math.abs(dx) > Math.abs(dy)) {
        g = null; // gesto horizontal: no es nuestro
        return;
      }
      if (Math.abs(dy) < 14) return;
      g.active = true;
      g.start = g.kind === 'vol' ? Gestures.getVol(video) : Gestures.getBri(video);
      g.y0 = t.clientY;
    }
    e.preventDefault();
    const moved = ((g.y0 - t.clientY) / (g.h * 0.75)) * 100;
    const p = Math.max(0, Math.min(100, Math.round(g.start + moved)));
    if (p !== g.last) {
      g.last = p;
      if (g.kind === 'vol') Gestures.setVol(video, p);
      else Gestures.setBri(video, p);
      show(g.kind, p);
    }
  }, { passive: false });

  const end = () => {
    if (g?.active) {
      clearTimeout(hideT);
      hideT = setTimeout(() => hud.classList.remove('show'), 800);
    }
    g = null;
  };
  box.addEventListener('touchend', end);
  box.addEventListener('touchcancel', end);
}

attachGestures($('#live-box'), $('#live-video'));
attachGestures($('.theater-box'), $('#theater-video'));

function zap(step) {
  const list = S.live.list;
  if (!list.length) return;
  let idx = S.live.current ? list.findIndex((x) => x.key === S.live.current.key) : -1;
  idx = idx < 0 ? 0 : (idx + step + list.length) % list.length;
  playLive(list[idx]);
}

/* Número de canal en pantalla */
let osdTimer = null;
function showOSD(num, name, typing = false) {
  const osd = $('#osd');
  $('#osd-num').textContent = num === '' || num == null ? '' : String(num);
  $('#osd-name').textContent = name || '';
  osd.classList.toggle('typing', typing);
  osd.classList.add('show');
  clearTimeout(osdTimer);
  if (!typing) osdTimer = setTimeout(() => osd.classList.remove('show'), 3200);
}

function typeDigit(d) {
  S.digitBuf = (S.digitBuf + d).slice(-5);
  showOSD(S.digitBuf, '', true);
  clearTimeout(S.digitTimer);
  S.digitTimer = setTimeout(() => {
    const n = Number(S.digitBuf);
    S.digitBuf = '';
    const all = S.data.live?.items || [];
    let it = S.live.list.find((x) => x.num === n) || all.find((x) => x.num === n);
    if (!it && n > 0 && n <= S.live.list.length && S.live.list.every((x) => !x.num)) it = S.live.list[n - 1];
    if (!it) {
      showOSD(n, 'No hay ningún canal con ese número');
      return;
    }
    if (!S.live.list.some((x) => x.key === it.key)) {
      S.cat = 'all';
      S.query = '';
      $('#search').value = '';
      renderCats();
      renderContent();
    }
    playLive(it);
  }, 1400);
}

/* Guía de programación */
/* ---- Guía de programación: caché por canal y cola de peticiones ---- */

const EPG_TTL = 15 * 60 * 1000;
const epgQ = { running: 0, jobs: [] };

function parseEpgTime(ts, str) {
  const n = Number(ts);
  if (n) return n * 1000;
  const p = Date.parse(String(str || '').replace(' ', 'T'));
  return isNaN(p) ? 0 : p;
}

function parseEpg(arr) {
  const now = Date.now();
  // la corrección de la hora se aplica después (fixProviderEpg); aquí se deja una hora de margen
  return (Array.isArray(arr) ? arr : [])
    .map((l) => ({
      title: b64(l.title) || 'Sin título',
      desc: b64(l.description),
      start: parseEpgTime(l.start_timestamp, l.start),
      end: parseEpgTime(l.stop_timestamp, l.stop || l.end),
    }))
    .filter((p) => p.start && p.end && p.end > now - 4 * 3600000)
    .sort((a, b) => a.start - b.start);
}

/* ---------- Hora de la guía del proveedor ----------
   Muchos proveedores sirven la guía con una hora de diferencia (sobre todo tras el cambio
   de hora). En automático se compara, en los canales que también están en la guía
   externa, la hora a la que empieza cada programa con el mismo título en las dos guías. */
const epgCal = { votes: new Map(), plId: null };

function epgTitleKey(t) {
  return String(t || '')
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .toLowerCase()
    .replace(/\b(t\d+|e\d+|temporada|episodio|cap(itulo)?\.?)\b.*$/, '')
    .replace(/[^a-z0-9]/g, '')
    .slice(0, 18);
}

/* Diferencia (ms) entre la guía del proveedor y la externa para un canal, o null */
function epgDelta(prov, ext) {
  if (!prov.length || !ext.length) return null;
  const byTitle = new Map();
  for (const e of ext) {
    const k = epgTitleKey(e.title);
    if (k.length < 4) continue;
    if (!byTitle.has(k)) byTitle.set(k, []);
    byTitle.get(k).push(e.start);
  }
  const counts = new Map();
  for (const p of prov) {
    const starts = byTitle.get(epgTitleKey(p.title));
    if (!starts) continue;
    let best = null;
    for (const st of starts) {
      const d = p.start - st;
      if (Math.abs(d) <= 3.5 * 3600000 && (best == null || Math.abs(d) < Math.abs(best))) best = d;
    }
    if (best == null) continue;
    const r = Math.round(best / 1800000) * 1800000; // a la media hora
    counts.set(r, (counts.get(r) || 0) + 1);
  }
  let win = null;
  let n = 0;
  let total = 0;
  for (const [d, c] of counts) {
    total += c;
    if (c > n) {
      n = c;
      win = d;
    }
  }
  // al menos dos programas que coinciden y que sea lo más repetido con claridad
  if (n < 2 || n < total * 0.6) return null;
  return win;
}

/* Desfase más repetido entre los canales comparados: se usa en los que no se pueden comparar */
function epgGlobalDelta() {
  let win = 0;
  let n = 0;
  let total = 0;
  for (const [d, c] of epgCal.votes) {
    total += c;
    if (c > n) {
      n = c;
      win = d;
    }
  }
  return n >= 2 && n >= total * 0.6 ? win : 0;
}

async function fixProviderEpg(it, list) {
  const mode = S.store?.settings?.epgFix || 'auto';
  const now = Date.now();
  let delta = 0;
  if (mode !== 'auto') {
    delta = -(Number(mode) || 0) * 3600000;
  } else if (extEpgEnabled()) {
    if (epgCal.plId !== S.pl?.id) {
      epgCal.plId = S.pl?.id;
      epgCal.votes = new Map();
    }
    let ext = [];
    try {
      ext = await extEpgLookup(it, { past: true });
    } catch {}
    const d = epgDelta(list, ext);
    if (d != null) {
      epgCal.votes.set(d, (epgCal.votes.get(d) || 0) + 1);
      delta = d;
    } else {
      delta = epgGlobalDelta();
    }
  }
  return list
    .map((p) => (delta ? { ...p, start: p.start - delta, end: p.end - delta } : p))
    .filter((p) => p.end > now);
}

async function fetchEpg(it) {
  let list = [];
  // guía externa primero, si se ha elegido así en Ajustes
  if (S.store?.settings?.epgPrefer === 'external' && extEpgEnabled()) {
    try {
      list = await extEpgLookup(it);
    } catch {}
    if (list.length) return list;
  }
  if (S.client && !it.url) {
    try {
      const d = await S.client.call('get_short_epg', { stream_id: it.id, limit: 12 });
      list = parseEpg(d?.epg_listings);
    } catch {}
    if (!list.length) {
      // Algunos servidores solo rellenan la tabla completa
      try {
        const d = await S.client.call('get_simple_data_table', { stream_id: it.id });
        list = parseEpg(d?.epg_listings).slice(0, 30);
      } catch {}
    }
    if (list.length) list = await fixProviderEpg(it, list);
  }
  // Si el proveedor no da guía para este canal, se busca en la guía externa
  if (!list.length && extEpgEnabled() && S.store?.settings?.epgPrefer !== 'external') {
    try {
      list = await extEpgLookup(it);
    } catch {}
  }
  return list;
}

function hasAnyEpg() {
  return !!S.client || extEpgEnabled();
}

function epgPump() {
  while (epgQ.running < 3 && epgQ.jobs.length) {
    const job = epgQ.jobs.shift();
    epgQ.running++;
    job.run().finally(() => {
      epgQ.running--;
      epgPump();
    });
  }
}

/* Cancela las peticiones que aún no han empezado (p. ej. al cambiar de categoría) */
function epgCancelQueued() {
  const keep = [];
  for (const job of epgQ.jobs.splice(0)) {
    if (job.urgent) keep.push(job);
    else job.cancel();
  }
  epgQ.jobs.push(...keep);
}

function epgCached(it) {
  const c = S.epgCache.get(it.id);
  if (!c || c.pending) return null;
  const now = Date.now();
  return c.list.filter((p) => p.end > now);
}

function epgFor(it, urgent = false) {
  if (!hasAnyEpg()) return Promise.resolve([]);
  const now = Date.now();
  const c = S.epgCache.get(it.id);
  if (c) {
    if (c.pending) {
      if (urgent) c.bump?.();
      return c.pending;
    }
    const fresh = c.list.filter((p) => p.end > now);
    const stale = now - c.at > EPG_TTL || (c.list.length && !fresh.length);
    if (!stale) return Promise.resolve(fresh);
  }
  const token = S.plToken;
  const entry = { at: 0, list: [] };
  entry.pending = new Promise((resolve) => {
    const job = {
      run: async () => {
        let list = [];
        try {
          list = await fetchEpg(it);
        } catch {}
        if (token !== S.plToken) return resolve([]);
        entry.list = list;
        entry.at = Date.now();
        entry.pending = null;
        resolve(list);
      },
      cancel: () => {
        if (S.epgCache.get(it.id) === entry) S.epgCache.delete(it.id);
        resolve(null);
      },
    };
    job.urgent = urgent;
    entry.bump = () => {
      job.urgent = true;
      const i = epgQ.jobs.indexOf(job);
      if (i > 0) {
        epgQ.jobs.splice(i, 1);
        epgQ.jobs.unshift(job);
      }
    };
    if (urgent) epgQ.jobs.unshift(job);
    else epgQ.jobs.push(job);
  });
  S.epgCache.set(it.id, entry);
  epgPump();
  return entry.pending;
}

/* Programa actual en cada fila de canal */
function paintRowEpg(li, list) {
  const box = li.querySelector('.ch-now');
  if (!box) return;
  const now = Date.now();
  const cur = (list || []).find((p) => p.start <= now && now < p.end);
  const next = (list || []).find((p) => p.start > now);
  box.replaceChildren();
  if (cur) {
    box.append(
      h('span', { class: 'ch-now-title', text: cur.title }),
      h('span', { class: 'ch-now-bar' }, h('i', { style: `width:${(((now - cur.start) / (cur.end - cur.start)) * 100).toFixed(1)}%` }))
    );
    li.title = `${li.dataset.name}\nAhora: ${cur.title} (hasta las ${hhmm(new Date(cur.end))})${next ? `\nDespués: ${next.title}` : ''}`;
  } else if (next) {
    box.append(h('span', { class: 'ch-now-title muted', text: `${hhmm(new Date(next.start))} · ${next.title}` }));
  }
  box.classList.toggle('empty', !cur && !next);
}

let rowEpgObs = null;
function observeRowEpg(li, it) {
  if (!hasAnyEpg()) return;
  const cached = epgCached(it);
  if (cached) {
    paintRowEpg(li, cached);
    // si caducó, se vuelve a pedir cuando esté a la vista
    const c = S.epgCache.get(it.id);
    if (Date.now() - c.at < EPG_TTL) return;
  }
  if (!rowEpgObs) {
    rowEpgObs = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          rowEpgObs.unobserve(e.target);
          const row = e.target;
          const item = row._item;
          epgFor(item).then((list) => {
            if (list && row.isConnected) paintRowEpg(row, list);
          });
        }
      },
      { root: $('#content-body'), rootMargin: '150px 0px' }
    );
  }
  li._item = it;
  rowEpgObs.observe(li);
}

/* Guía del canal que se está viendo */
async function loadEPG(it) {
  const tok = ++S.live.epgToken;
  const box = $('#epg');
  S.live.epg = [];
  box.replaceChildren();
  if (!hasAnyEpg()) {
    box.append(h('p', { class: 'muted small', text: 'Esta lista no incluye guía de programación. Puedes activar la guía externa en Ajustes.' }));
    return;
  }
  const cached = epgCached(it);
  if (cached && cached.length) {
    S.live.epg = cached;
    renderEPG();
  } else {
    box.append(h('p', { class: 'muted small', text: 'Cargando la guía de programación…' }));
  }
  const list = await epgFor(it, true);
  if (tok !== S.live.epgToken) return;
  S.live.epg = list || [];
  renderEPG();
  const row = $(`.ch[data-key="${CSS.escape(it.key)}"]`);
  if (row && list) paintRowEpg(row, list);
}

function renderEPG() {
  const box = $('#epg');
  box.replaceChildren();
  const list = S.live.epg;
  if (!list.length) {
    box.append(h('p', { class: 'muted small', text: extEpgEnabled()
      ? (XmlTv.error && !XmlTv.data ? `No hay guía para este canal. La guía externa no se ha podido descargar: ${XmlTv.error}` : 'No hay guía para este canal ni en tu proveedor ni en la guía externa.')
      : 'Tu proveedor no ofrece guía de programación para este canal.' }));
    $('#live-guide').classList.add('hidden');
    return;
  }
  $('#live-guide').classList.remove('hidden');
  const now = Date.now();
  let shownNext = false;
  list.forEach((p) => {
    const isNow = p.start <= now && now < p.end;
    const isNext = !isNow && !shownNext;
    if (isNext) shownNext = true;
    const ratio = isNow ? (now - p.start) / (p.end - p.start) : 0;
    box.append(
      h('div', { class: 'epg-item' + (isNow ? ' now' : '') + (isNext ? ' next' : '') },
        h('div', { class: 'epg-time', text: hhmm(new Date(p.start)) }),
        h('div', {},
          h('div', { class: 'epg-title' }, isNow ? h('span', { class: 'live-dot', title: 'En emisión' }) : null, p.title),
          isNow ? h('div', { class: 'muted small', text: `Hasta las ${hhmm(new Date(p.end))}` }) : null,
          isNow ? progressBar(ratio) : null,
          p.desc ? h('div', { class: 'epg-desc', text: p.desc }) : null
        )
      )
    );
  });
  box.classList.toggle('has-now', list.some((p) => p.start <= now && now < p.end));
  if (list[0]?.src === 'ext') {
    box.append(h('p', { class: 'muted small epg-source', text: S.store?.settings?.epgPrefer === 'external' ? 'Guía externa (horario de España).' : 'Guía externa: tu proveedor no ofrece programación para este canal.' }));
  }
}

/* Guía completa en el móvil en vertical */
function toggleGuide(force) {
  const on = force ?? !document.body.classList.contains('epg-open');
  document.body.classList.toggle('epg-open', on);
  $('#live-guide').classList.toggle('active', on);
  $('#live-guide').title = on ? 'Volver a la lista de canales' : 'Guía de programación';
}
$('#live-guide').addEventListener('click', () => toggleGuide());

/* Actualizar barras de progreso y avanzar programas */
setInterval(() => {
  if (!S.pl || S.section !== 'live') return;
  const now = Date.now();
  if (S.live.epg.length) {
    if (S.live.epg[0].end <= now) S.live.epg = S.live.epg.filter((p) => p.end > now);
    renderEPG();
  }
  for (const li of $$('.ch[data-key]')) {
    const it = li._item;
    if (!it) continue;
    const list = epgCached(it);
    if (list) paintRowEpg(li, list);
  }
}, 30000);

/* ------------------------------------------------------------ fichas */

function openDetail(it) {
  if (it.type === 'live') {
    goToChannel(it);
    return;
  }
  if (it.type === 'episode') {
    playEpisodeFromRecent(it);
    return;
  }
  const sec = it.type === 'movie' ? 'movies' : 'series';
  const body = $('#content-body');
  const fromSection = S.section;
  if (S.section !== sec) {
    S.section = sec;
    loadSection(sec);
  }
  S.detail = { item: it, info: null, scroll: body.scrollTop, from: fromSection, loading: true, season: null };
  renderSection();
  body.scrollTop = 0;
  const tok = S.detail;
  const action = it.type === 'movie' ? ['get_vod_info', { vod_id: it.id }] : ['get_series_info', { series_id: it.id }];
  S.client
    .call(...action)
    .then((data) => {
      if (S.detail !== tok) return;
      tok.info = data || {};
      tok.loading = false;
      renderContent();
    })
    .catch((e) => {
      if (S.detail !== tok) return;
      tok.loading = false;
      tok.error = e.message;
      renderContent();
    });
}

function closeDetail() {
  const d = S.detail;
  if (!d) return;
  S.detail = null;
  if (d.from && d.from !== S.section) {
    S.section = d.from;
  }
  renderSection();
  $('#content-body').scrollTop = d.scroll || 0;
}

function renderDetail(body) {
  const d = S.detail;
  const it = d.item;
  const info = d.info?.info || {};
  const isMovie = it.type === 'movie';
  const title = info.name || info.title || it.name;
  const cover = info.movie_image || info.cover_big || info.cover || it.logo;
  const backdrop = (Array.isArray(info.backdrop_path) ? info.backdrop_path[0] : info.backdrop_path) || '';
  const year = String(info.releasedate || info.releaseDate || info.release_date || it.year || '').slice(0, 4);
  const dur = isMovie ? durationText(info) : '';
  const rating = parseFloat(info.rating) || it.rating || 0;

  const wrap = h('div', { class: 'detail' });
  if (backdrop) wrap.append(h('div', { class: 'detail-backdrop', style: `background-image:url("${encodeURI(backdrop).replace(/"/g, '%22')}")` }));
  wrap.append(
    h('button', { class: 'btn ghost small-btn back-link', onclick: closeDetail }, icon('back'), h('span', { text: 'Volver' }))
  );

  const posterBox = h('div', { class: 'detail-poster' });
  if (cover) {
    const im = h('img', { src: cover, alt: '', referrerpolicy: 'no-referrer' });
    im.addEventListener('error', () => im.remove(), { once: true });
    posterBox.append(im);
  }

  const fileRes = resInfo(info.video?.width, info.video?.height);
  const facts = h('div', { class: 'facts' },
    year ? h('span', { text: year }) : null,
    dur ? h('span', { text: dur }) : null,
    info.genre ? h('span', { text: info.genre }) : null,
    rating ? h('span', { class: 'r', text: `★ ${(rating > 10 ? rating / 10 : rating).toFixed(1)}` }) : null,
    fileRes ? h('span', { class: 'res-badge ' + fileRes.tier, text: fileRes.short, title: `${fileRes.name} · ${fileRes.dims}` }) : null
  );

  const credits = h('dl', { class: 'credits' });
  if (info.director) credits.append(h('dt', { text: 'Dirección' }), h('dd', { text: info.director }));
  const cast = info.cast || info.actors;
  if (cast) credits.append(h('dt', { text: 'Reparto' }), h('dd', { text: cast }));

  const actions = h('div', { class: 'detail-actions' });
  const favBtn = h('button', { class: 'btn ghost' }, icon('star'), h('span'));
  const paintFav = () => {
    const on = isFav(it.key);
    favBtn.lastChild.textContent = on ? 'En favoritos' : 'Añadir a favoritos';
    favBtn.classList.toggle('on', on);
    favBtn.querySelector('.ic').style.fill = on ? 'var(--amber)' : 'none';
    favBtn.querySelector('.ic').style.color = on ? 'var(--amber)' : '';
  };
  favBtn.addEventListener('click', () => {
    toggleFav(it);
    paintFav();
  });
  paintFav();

  if (isMovie) {
    const ext = d.info?.movie_data?.container_extension || it.ext || 'mp4';
    const url = S.client.stream('movie', it.id, ext);
    const prog = getProgress(it.key);
    const resumable = prog && prog.t > 30 && prog.d && prog.t < prog.d - 60;
    if (resumable) {
      actions.append(
        h('button', { class: 'btn primary', onclick: () => playMovie(it, ext, prog.t) }, icon('play'), h('span', { text: `Continuar (${clock(prog.t)})` })),
        h('button', { class: 'btn ghost', onclick: () => playMovie(it, ext, 0) }, h('span', { text: 'Desde el principio' }))
      );
    } else {
      actions.append(h('button', { class: 'btn primary', onclick: () => playMovie(it, ext, 0) }, icon('play'), h('span', { text: 'Reproducir' })));
    }
    actions.append(
      h('button', { class: 'btn ghost', onclick: () => openExternal(url, title) }, icon('external'), h('span', { text: 'Reproductor externo' }))
    );
  }
  if (!isMovie && d.info) {
    const all = seriesEpisodes(d);
    const last = (S.store.recent[pid()] || []).find((r) => r.type === 'episode' && r.seriesId === it.id);
    const list = last && all[last.season];
    const idx = list ? list.findIndex((ep) => String(ep.id) === String(last.id)) : -1;
    if (idx >= 0) {
      // si el último episodio ya está terminado, proponer el siguiente
      const done = progressRatio(last.key) > 0.95 && idx + 1 < list.length;
      const target = done ? idx + 1 : idx;
      const ep = list[target];
      actions.append(
        h('button', { class: 'btn primary', onclick: () => playEpisode(it, last.season, list, target) },
          icon('play'), h('span', { text: `${done ? 'Ver' : 'Continuar'} T${last.season} E${ep.episode_num}` }))
      );
    } else {
      const first = Object.keys(all).sort((a, b) => Number(a) - Number(b)).find((s) => s !== '0') || Object.keys(all)[0];
      if (first && all[first]?.length) {
        actions.append(
          h('button', { class: 'btn primary', onclick: () => playEpisode(it, first, all[first], 0) }, icon('play'), h('span', { text: 'Ver desde el primer episodio' }))
        );
      }
    }
  }
  actions.append(favBtn);

  const plot = info.plot || info.description || '';
  const main = h('div', {},
    h('h2', { text: title }),
    facts,
    actions,
    plot ? h('p', { class: 'plot', text: plot }) : null,
    credits.childElementCount ? credits : null
  );

  if (d.loading) main.append(h('div', { class: 'state', style: 'padding:30px 0;align-items:flex-start' }, h('div', { class: 'spinner' })));
  if (d.error) main.append(h('p', { class: 'form-error', style: 'margin-top:16px', text: `No se ha podido cargar la ficha: ${d.error}` }));
  if (!isMovie && d.info) main.append(renderSeasons(it, d));

  wrap.append(h('div', { class: 'detail-inner' }, posterBox, main));
  body.append(wrap);
}

function seriesEpisodes(d) {
  const eps = d.info?.episodes || {};
  const out = {};
  const src = Array.isArray(eps) ? { 1: eps } : eps;
  for (const [season, list] of Object.entries(src)) {
    if (!Array.isArray(list)) continue;
    out[season] = list
      .filter(Boolean)
      .slice()
      .sort((a, b) => Number(a.episode_num) - Number(b.episode_num));
  }
  return out;
}

function renderSeasons(it, d) {
  const all = seriesEpisodes(d);
  const seasons = Object.keys(all).sort((a, b) => Number(a) - Number(b));
  const box = h('div');
  if (!seasons.length) {
    box.append(h('p', { class: 'muted', style: 'margin-top:24px', text: 'Esta serie todavía no tiene episodios disponibles.' }));
    return box;
  }
  if (!d.season || !all[d.season]) {
    // abrir en la temporada del último episodio visto
    const recent = (S.store.recent[pid()] || []).find((r) => r.type === 'episode' && r.seriesId === it.id);
    d.season = recent && all[recent.season] ? String(recent.season) : seasons[0];
  }
  const tabs = h('div', { class: 'seasons', role: 'tablist' },
    seasons.map((s) =>
      h('button', {
        class: 'season-tab' + (s === d.season ? ' active' : ''),
        role: 'tab',
        text: s === '0' ? 'Especiales' : `Temporada ${s}`,
        onclick: () => {
          d.season = s;
          renderContent();
        },
      })
    )
  );
  const list = all[d.season];
  const ul = h('ul', { class: 'episodes' });
  list.forEach((ep, idx) => {
    const key = 'ep:' + ep.id;
    const ratio = progressRatio(key);
    const epInfo = ep.info || {};
    const li = h('li', { class: 'ep' + (ratio > 0.95 ? ' watched' : ''), tabindex: 0 },
      h('div', { class: 'ep-num', text: ep.episode_num ?? idx + 1 }),
      h('div', { style: 'min-width:0' },
        h('div', { class: 'ep-title', text: cleanEpisodeTitle(ep.title, it.name) || `Episodio ${ep.episode_num}` }),
        epInfo.plot ? h('div', { class: 'ep-plot', text: epInfo.plot }) : null,
        progressBar(ratio)
      ),
      h('div', { class: 'ep-dur' },
        durationText(epInfo),
        (() => {
          const r = resInfo(epInfo.video?.width, epInfo.video?.height);
          return r ? h('span', { class: 'res-badge ' + r.tier, text: r.short, title: r.dims }) : null;
        })()
      )
    );
    li.addEventListener('click', () => playEpisode(it, d.season, list, idx));
    ul.append(li);
  });
  box.append(tabs, ul);
  return box;
}

function cleanEpisodeTitle(t, seriesName) {
  let s = String(t || '');
  if (seriesName && s.toLowerCase().startsWith(seriesName.toLowerCase())) s = s.slice(seriesName.length);
  return s.replace(/^\s*[-–:|]\s*/, '').replace(/^S\d+\s*E\d+\s*[-–:|]?\s*/i, '').trim() || String(t || '');
}

/* ------------------------------------------------------------ cine (VOD) */

let theaterState = null;

function playMovie(it, ext, startAt) {
  const url = S.client.stream('movie', it.id, ext);
  addRecent({ ...it, ext });
  openTheater({
    title: it.name,
    sub: '',
    key: it.key,
    candidates: candidatesFor(url),
    startAt,
  });
}

function playEpisode(series, season, list, idx) {
  const ep = list[idx];
  const ext = ep.container_extension || 'mp4';
  const url = S.client.stream('series', ep.id, ext);
  const key = 'ep:' + ep.id;
  const title = cleanEpisodeTitle(ep.title, series.name);
  const prog = getProgress(key);
  const startAt = prog && prog.t > 30 && prog.d && prog.t < prog.d - 60 ? prog.t : 0;
  addRecent(
    { type: 'episode', key, id: String(ep.id), name: title, logo: series.logo, ext },
    { seriesId: series.id, seriesName: series.name, season, episode: ep.episode_num }
  );
  openTheater({
    title: series.name,
    sub: `Temporada ${season}, episodio ${ep.episode_num}${title ? ` · ${title}` : ''}`,
    key,
    candidates: candidatesFor(url),
    startAt,
    next: idx + 1 < list.length ? () => playEpisode(series, season, list, idx + 1) : null,
  });
}

function playEpisodeFromRecent(r) {
  const url = S.client.stream('series', r.id, r.ext || 'mp4');
  const prog = getProgress(r.key);
  const startAt = prog && prog.t > 30 && prog.d && prog.t < prog.d - 60 ? prog.t : 0;
  addRecent(r);
  openTheater({
    title: r.seriesName || r.name,
    sub: `Temporada ${r.season}, episodio ${r.episode}`,
    key: r.key,
    candidates: candidatesFor(url),
    startAt,
  });
}

let idleTimer = null;
function theaterActivity() {
  const t = $('#theater');
  t.classList.remove('idle');
  clearTimeout(idleTimer);
  idleTimer = setTimeout(() => t.classList.add('idle'), 2600);
}

function openTheater(opts) {
  livePlayer.stop();
  if (S.section === 'live') resetLiveStage();
  theaterState = { ...opts, lastSave: 0 };
  $('#theater-title').textContent = opts.title;
  $('#theater-sub').textContent = opts.sub || '';
  $('#theater-next').classList.toggle('hidden', !opts.next);
  $('#theater').classList.remove('hidden');
  if (PLATFORM === 'android') {
    api.setImmersive?.(true);
    if ((S.store.settings.orientation || 'auto') !== 'portrait') api.setOrientation?.('landscape');
  }
  theaterActivity();

  const toastEl = $('#resume-toast');
  if (opts.startAt > 0) {
    $('#resume-text').textContent = `Continuando desde ${clock(opts.startAt)}`;
    toastEl.classList.remove('hidden');
    clearTimeout(theaterState.toastTimer);
    theaterState.toastTimer = setTimeout(() => toastEl.classList.add('hidden'), 9000);
  } else {
    toastEl.classList.add('hidden');
  }

  theaterPlayer.play(opts.candidates, {
    startAt: opts.startAt,
    onNoAudio: (codec) => handleNoAudio(theaterPlayer, opts.candidates[0].url, opts.title, codec),
    onFail: (why) => {
      theaterPlayer.showError('No se puede reproducir', `${why} Prueba a abrirlo en un reproductor externo.`, [
        h('button', { class: 'btn ghost', onclick: () => openTheater({ ...opts }) }, icon('refresh'), h('span', { text: 'Reintentar' })),
        h('button', { class: 'btn primary', onclick: () => openExternal(opts.candidates[0].url, opts.title) }, icon('external'), h('span', { text: 'Abrir en reproductor externo' })),
      ]);
    },
  });
}

function saveTheaterProgress() {
  const st = theaterState;
  const v = $('#theater-video');
  if (!st || !isFinite(v.duration) || !v.duration || v.currentTime < 1) return;
  const t = v.currentTime >= v.duration * 0.96 ? v.duration : v.currentTime;
  setProgress(st.key, t, v.duration);
}

function closeTheater() {
  if (!theaterState) return;
  saveTheaterProgress();
  theaterPlayer.stop();
  theaterState = null;
  closeTracksMenu();
  updatePip();
  $('#theater').classList.add('hidden');
  $('#resume-toast').classList.add('hidden');
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  if (PLATFORM === 'android' && !$('.pseudo-fs')) {
    api.setImmersive?.(false);
    applyOrientation();
  }
  if (S.pl && (S.detail || S.section === 'recent')) renderContent();
}

$('#theater-video').addEventListener('timeupdate', () => {
  const st = theaterState;
  if (!st) return;
  const now = Date.now();
  if (now - st.lastSave > 5000) {
    st.lastSave = now;
    saveTheaterProgress();
  }
});
$('#theater-video').addEventListener('ended', () => {
  saveTheaterProgress();
  if (theaterState?.next) theaterState.next();
});
$('#theater-video').addEventListener('dblclick', () => toggleTheaterFullscreen());
$('#theater').addEventListener('mousemove', theaterActivity);
$('#theater').addEventListener('pointerdown', theaterActivity);
$('#theater-close').addEventListener('click', closeTheater);
$('#theater-next').addEventListener('click', () => {
  saveTheaterProgress();
  theaterState?.next?.();
});
$('#theater-ext').addEventListener('click', () => {
  const st = theaterState;
  if (!st) return;
  const v = $('#theater-video');
  saveTheaterProgress();
  theaterPlayer.stop();
  openExternal(st.candidates[0].url, st.title);
  if (v) closeTheater();
});
$('#resume-restart').addEventListener('click', () => {
  const v = $('#theater-video');
  try { v.currentTime = 0; } catch {}
  if (theaterState) theaterState.startAt = 0;
  $('#resume-toast').classList.add('hidden');
});

function toggleTheaterFullscreen() {
  if (PLATFORM === 'android') return; // en Android el cine ya ocupa toda la pantalla
  if (document.fullscreenElement) document.exitFullscreen();
  else $('#theater').requestFullscreen().catch(() => {});
}

/* ------------------------------------------------------------ favoritos y recientes */

function goToChannel(snap) {
  const go = () => {
    const it = S.data.live?.items.find((x) => x.key === snap.key) || finishItem({ ...snap });
    playLive(it);
  };
  S.section = 'live';
  S.cat = 'all';
  S.query = '';
  S.detail = null;
  $('#search').value = '';
  renderSection();
  const p = loadSection('live');
  if (S.data.live?.status === 'ready') go();
  else Promise.resolve(p).then(() => S.section === 'live' && go());
}

function renderLibrary(body) {
  const isFavs = S.section === 'favorites';
  let items = isFavs
    ? Object.values(favs()).sort((a, b) => (b.at || 0) - (a.at || 0))
    : (S.store.recent[pid()] || []).slice();
  const q = norm(S.query);
  if (q) items = items.filter((x) => norm(x.name + ' ' + (x.seriesName || '')).includes(q));
  $('#count').textContent = items.length ? `${items.length} ${items.length === 1 ? 'elemento' : 'elementos'}` : '';

  if (!items.length) {
    if (q) body.append(stateView('empty', 'Sin resultados', `Nada coincide con «${S.query}».`));
    else if (isFavs) body.append(stateView('empty', 'Aún no tienes favoritos', 'Pulsa la estrella de un canal, una película o una serie para tenerlo siempre a mano aquí.'));
    else body.append(stateView('empty', 'Todavía no has visto nada', 'Los canales, películas y episodios que reproduzcas aparecerán aquí para que puedas continuar donde lo dejaste.'));
    return;
  }

  const channels = items.filter((x) => x.type === 'live');
  const media = items.filter((x) => x.type !== 'live');

  if (channels.length) {
    body.append(h('h3', { class: 'group-title', text: 'Canales' }));
    const ul = h('ul', { class: 'ch-list', style: 'max-width:720px' });
    channels.forEach((c, i) => ul.append(channelRow(c, i, { onClick: goToChannel })));
    body.append(ul);
  }
  if (media.length) {
    const groups = isFavs
      ? [['Películas', media.filter((x) => x.type === 'movie')], ['Series', media.filter((x) => x.type === 'series')]]
      : [['Películas y episodios', media]];
    for (const [label, list] of groups) {
      if (!list.length) continue;
      body.append(h('h3', { class: 'group-title', text: label }));
      const grid = h('div', { class: 'poster-grid' });
      list.forEach((m) => grid.append(posterCard(m)));
      body.append(grid);
    }
  }
  if (!isFavs) {
    body.append(
      h('div', { style: 'padding:8px 18px 32px' },
        h('button', {
          class: 'btn ghost small-btn',
          onclick: async () => {
            if (!(await confirmDialog('¿Borrar el historial?', 'Se vaciará la lista de vistos recientemente de esta lista. El punto donde dejaste cada película se conserva.'))) return;
            S.store.recent[pid()] = [];
            api.setStore('recent', S.store.recent);
            renderContent();
          },
        }, icon('trash'), h('span', { text: 'Borrar historial' }))
      )
    );
  }
}

/* ------------------------------------------------------------ navegación y teclado */

$$('.rail-btn[data-section]').forEach((b) =>
  b.addEventListener('click', () => {
    closeTheater();
    switchSection(b.dataset.section);
  })
);
$('#rail-home').addEventListener('click', goHome);
$('#rail-settings').addEventListener('click', openSettings);
$('#btn-settings-home').addEventListener('click', openSettings);
$('#btn-add-playlist').addEventListener('click', () => openPlaylistDialog());
$('#rail-refresh').addEventListener('click', refreshSection);
$('#btn-refresh').addEventListener('click', refreshSection);

document.addEventListener('keydown', (e) => {
  if (anyDialogOpen()) return;
  const typing = isTyping(e);

  if (e.key === 'Escape') {
    if (typing) {
      e.target.blur();
      return;
    }
    if (document.fullscreenElement) return; // el navegador ya sale de pantalla completa
    if (tracksFor) return closeTracksMenu();
    if ($('.pseudo-fs')) return exitFull();
    if (document.body.classList.contains('cats-open')) return closeCatSheet();
    if (document.body.classList.contains('epg-open')) return toggleGuide(false);
    if (theaterState) return closeTheater();
    if (S.detail) return closeDetail();
    return;
  }

  if (e.ctrlKey && !e.altKey && S.pl) {
    const k = e.key.toLowerCase();
    if (k === 'f') {
      e.preventDefault();
      $('#search').focus();
      $('#search').select();
      return;
    }
    if (k === 'r') {
      e.preventDefault();
      closeTheater();
      switchSection('recent');
      return;
    }
  }

  if (typing) return;

  if (theaterState) {
    const v = $('#theater-video');
    if (e.key === 'f' || e.key === 'F') toggleTheaterFullscreen();
    else if (e.key === ' ') {
      e.preventDefault();
      v.paused ? v.play() : v.pause();
    } else if (e.key === 'ArrowRight') v.currentTime = Math.min(v.duration || Infinity, v.currentTime + 10);
    else if (e.key === 'ArrowLeft') v.currentTime = Math.max(0, v.currentTime - 10);
    theaterActivity();
    return;
  }

  if (S.pl && S.section === 'live' && S.data.live?.status === 'ready') {
    if (e.key === 'ArrowDown' || e.key === 'PageDown') {
      e.preventDefault();
      zap(1);
    } else if (e.key === 'ArrowUp' || e.key === 'PageUp') {
      e.preventDefault();
      zap(-1);
    } else if (e.key === 'f' || e.key === 'F') {
      toggleLiveFullscreen();
    } else if (/^[0-9]$/.test(e.key)) {
      typeDigit(e.key);
    } else if (e.key === 'm' || e.key === 'M') {
      const v = $('#live-video');
      v.muted = !v.muted;
      toast(v.muted ? 'Sonido silenciado' : 'Sonido activado', false, 1500);
    }
  }
});

/* Con cualquier mando o teclado: OK/Intro sobre una categoría, un canal o un episodio lo abre */
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter' || e.defaultPrevented) return;
  const el = e.target;
  if (el && el.matches && el.matches('#cat-list li[tabindex], .ch[tabindex], .ep[tabindex]')) {
    e.preventDefault();
    el.click();
  }
});

window.addEventListener('beforeunload', () => {
  saveTheaterProgress();
  api.setStore('progress', S.store.progress);
});

/* ------------------------------------------------------------ resolución del vídeo */

function resInfo(w, hgt) {
  w = Number(w) || 0;
  hgt = Number(hgt) || 0;
  if (!w || !hgt) return null;
  const dims = `${w}×${hgt}`;
  // se mira también el ancho: las películas panorámicas (1920×800) son Full HD
  if (w >= 3800 || hgt >= 2100) return { short: '4K', name: 'Ultra HD 4K', dims, tier: 'uhd' };
  if (w >= 2500 || hgt >= 1400) return { short: '1440p', name: 'Quad HD 1440p', dims, tier: 'uhd' };
  if (w >= 1900 || hgt >= 1000) return { short: '1080p', name: 'Full HD 1080p', dims, tier: 'fhd' };
  if (w >= 1270 || hgt >= 700) return { short: '720p', name: 'HD 720p', dims, tier: 'hd' };
  return { short: `${hgt}p`, name: `SD ${hgt}p`, dims, tier: 'sd' };
}

function paintRes(el, r, long = true) {
  if (!el) return;
  el.classList.toggle('hidden', !r);
  el.classList.remove('uhd', 'fhd', 'hd', 'sd');
  if (!r) return;
  el.classList.add(r.tier);
  el.textContent = long ? `${r.name} · ${r.dims}` : r.short;
  el.title = `${r.name} (${r.dims})`;
}

let resPillT = null;
function flashResPill() {
  const pill = $('#live-res-pill');
  if (!pill.textContent) return;
  pill.classList.add('show');
  clearTimeout(resPillT);
  resPillT = setTimeout(() => pill.classList.remove('show'), 4000);
}

function watchResolution(video, onChange) {
  let last = '';
  const upd = () => {
    const r = resInfo(video.videoWidth, video.videoHeight);
    const key = r ? r.dims : '';
    if (key === last) return;
    last = key;
    onChange(r);
  };
  video.addEventListener('loadedmetadata', upd);
  video.addEventListener('resize', upd);
  video.addEventListener('emptied', () => {
    last = '';
    onChange(null);
  });
}

watchResolution($('#live-video'), (r) => {
  paintRes($('#live-res'), r);
  const pill = $('#live-res-pill');
  pill.textContent = r ? r.short : '';
  pill.classList.remove('uhd', 'fhd', 'hd', 'sd');
  if (r) {
    pill.classList.add(r.tier);
    flashResPill();
  } else {
    pill.classList.remove('show');
  }
});
watchResolution($('#theater-video'), (r) => paintRes($('#theater-res'), r));
$('#live-box').addEventListener('pointerdown', flashResPill);

/* ------------------------------------------------------------ sin sonido */

/* Lee los primeros kilobytes de una emisión MPEG-TS y averigua el tipo de audio (tabla PMT) */
function readBytes(url, maxBytes = 96 * 1024, timeout = 6000) {
  return new Promise((resolve) => {
    const x = new XMLHttpRequest();
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      const t = x.responseText || '';
      const n = Math.min(t.length, maxBytes);
      const out = new Uint8Array(n);
      for (let i = 0; i < n; i++) out[i] = t.charCodeAt(i) & 0xff;
      try { x.abort(); } catch {}
      resolve(out);
    };
    try {
      x.open('GET', url, true);
      x.overrideMimeType('text/plain; charset=x-user-defined');
    } catch {
      return resolve(new Uint8Array(0));
    }
    x.onprogress = () => {
      if ((x.responseText || '').length >= maxBytes) finish();
    };
    x.onload = x.onerror = x.onabort = finish;
    setTimeout(finish, timeout);
    x.send();
  });
}

function tsAudioCodec(b) {
  const types = { 0x03: 'mp2', 0x04: 'mp2', 0x0f: 'aac', 0x11: 'aac', 0x81: 'ac-3', 0x87: 'ec-3', 0x8a: 'dts', 0x82: 'dts' };
  let start = -1;
  for (let i = 0; i + 376 < b.length; i++) {
    if (b[i] === 0x47 && b[i + 188] === 0x47 && b[i + 376] === 0x47) {
      start = i;
      break;
    }
  }
  if (start < 0) return '';
  const pmtPids = new Set();
  const found = [];
  for (let p = start; p + 188 <= b.length; p += 188) {
    if (b[p] !== 0x47) continue;
    const pusi = b[p + 1] & 0x40;
    const pid = ((b[p + 1] & 0x1f) << 8) | b[p + 2];
    const afc = (b[p + 3] >> 4) & 3;
    let o = p + 4;
    if (afc === 2) continue;
    if (afc === 3) o += 1 + b[o];
    if (!pusi) continue;
    o += 1 + b[o]; // pointer_field
    if (pid === 0 && b[o] === 0x00) {
      const len = ((b[o + 1] & 0x0f) << 8) | b[o + 2];
      for (let q = o + 8; q + 4 <= o + 3 + len - 4; q += 4) {
        const prog = (b[q] << 8) | b[q + 1];
        if (prog) pmtPids.add(((b[q + 2] & 0x1f) << 8) | b[q + 3]);
      }
    } else if (pmtPids.has(pid) && b[o] === 0x02) {
      const len = ((b[o + 1] & 0x0f) << 8) | b[o + 2];
      const end = Math.min(o + 3 + len - 4, p + 188);
      const infoLen = ((b[o + 10] & 0x0f) << 8) | b[o + 11];
      let q = o + 12 + infoLen;
      while (q + 5 <= end) {
        const st = b[q];
        const esLen = ((b[q + 3] & 0x0f) << 8) | b[q + 4];
        let codec = types[st] || '';
        if (st === 0x06) {
          // audio en «datos privados»: lo dicen los descriptores DVB
          for (let d = q + 5; d + 2 <= q + 5 + esLen; d += 2 + b[d + 1]) {
            if (b[d] === 0x6a) codec = 'ac-3';
            else if (b[d] === 0x7a) codec = 'ec-3';
            else if (b[d] === 0x7b) codec = 'dts';
          }
        }
        if (codec) found.push(codec);
        q += 5 + esLen;
      }
      if (found.length) break;
    }
  }
  // si hay varios audios, el problemático es el que no sea AAC
  return found.find((c) => c !== 'aac') || found[0] || '';
}

async function probeAudioCodec(url) {
  try {
    if (/\.m3u8?(\?|$)/i.test(url)) {
      let r = await api.httpText(url);
      let base = url;
      if (r.data && /#EXT-X-STREAM-INF/.test(r.data)) {
        const v = r.data.split(/\r?\n/).find((l) => l && !l.startsWith('#'));
        if (!v) return '';
        base = new URL(v, base).href;
        r = await api.httpText(base);
      }
      const seg = (r.data || '').split(/\r?\n/).find((l) => l && !l.startsWith('#'));
      if (!seg) return '';
      url = new URL(seg, base).href;
    } else if (!/\.ts(\?|$)/i.test(url) && kindOf(url) !== 'unknown') {
      return ''; // archivos .mp4/.mkv: no se analizan
    }
    return tsAudioCodec(await readBytes(url));
  } catch {
    return '';
  }
}

function externalPlayerName() {
  if (PLATFORM === 'android') return api.isInstalled?.('org.videolan.vlc') ? 'VLC' : 'otro reproductor';
  return 'un reproductor externo';
}

async function handleNoAudio(player, url, title, codec) {
  const tok = player.token;
  if (!codec) codec = await probeAudioCodec(player.current?.url || url);
  if (tok !== player.token) return; // ya se cambió de canal
  const fmt = audioCodecName(codec);
  if ((S.store.settings.noAudio || 'ask') === 'external') {
    player.stop();
    openExternal(url, title);
    toast(fmt ? `Sonido en ${fmt}: abierto en otro reproductor` : 'Canal sin sonido compatible: abierto en otro reproductor', false, 5000);
    return;
  }
  const noVlc = PLATFORM === 'android' && api.isInstalled && !api.isInstalled('org.videolan.vlc');
  player.showWarn([
    h('div', { class: 'warn-text' },
      h('strong', { text: 'Sin sonido' }),
      h('span', {
        class: 'warn-long',
        text: fmt
          ? ` Este canal emite el audio en ${fmt}, que el reproductor integrado no puede reproducir en este dispositivo.`
          : ' Este canal emite el audio en un formato que el reproductor integrado no puede reproducir (normalmente Dolby AC-3 o MP2).',
      }),
      h('span', { class: 'warn-short', text: fmt ? ` · ${fmt.replace(/ \(.*\)$/, '')}` : ' · formato no compatible' }),
      noVlc ? h('span', { class: 'muted warn-long', text: ' Instala VLC desde Google Play para oírlo.' }) : null
    ),
    h('div', { class: 'warn-actions' },
      h('button', { class: 'btn primary small-btn', onclick: () => { player.stop(); openExternal(url, title); } },
        icon('external'), h('span', { class: 'warn-long', text: `Abrir en ${externalPlayerName()}` }),
        h('span', { class: 'warn-short', text: externalPlayerName() === 'VLC' ? 'VLC' : 'Abrir fuera' })),
      h('button', { class: 'icon-btn small', title: 'Seguir sin sonido', onclick: () => player.hideWarn() }, icon('x'))
    ),
  ]);
}

/* ------------------------------------------------------------ menú de audio y subtítulos */

let tracksFor = null; // { player, anchor }

function openTracksMenu(player, anchor) {
  tracksFor = { player, anchor };
  renderTracksMenu();
  const menu = $('#tracks-menu');
  menu.classList.remove('hidden');
  const r = anchor.getBoundingClientRect();
  const w = menu.offsetWidth;
  const left = Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w));
  let top = r.bottom + 6;
  if (top + menu.offsetHeight > window.innerHeight - 8) top = Math.max(8, r.top - menu.offsetHeight - 6);
  menu.style.left = `${left}px`;
  menu.style.top = `${top}px`;
}

function closeTracksMenu() {
  tracksFor = null;
  $('#tracks-menu').classList.add('hidden');
}

function refreshTracksMenu() {
  if (tracksFor) renderTracksMenu();
}

function renderTracksMenu() {
  const { player } = tracksFor;
  const { audio, subs } = player.tracks();
  const menu = $('#tracks-menu');
  const item = (label, active, onPick, note = '') =>
    h('button', { type: 'button', role: 'menuitemradio', 'aria-checked': String(!!active), onclick: () => { onPick(); renderTracksMenu(); } },
      h('span', { text: label }),
      note ? h('small', { class: 'muted', text: note }) : null
    );
  const kids = [h('p', { class: 'tm-title', text: 'Audio' })];
  const softCodec = player.vod ? player.vod.codec : player.soft?.active ? player.soft.codec : '';
  const fmt = audioCodecName(softCodec || player.audioInfo.codec);
  if (audio.length) audio.forEach((a) => kids.push(item(a.label, a.active, a.select, a.note)));
  else kids.push(h('p', { class: 'tm-note', text: fmt ? `Una sola pista de audio (${fmt}).` : 'Esta emisión trae una sola pista de audio.' }));
  if (softCodec) kids.push(h('p', { class: 'tm-note', text: `El sonido ${audioCodecName(softCodec)} lo decodifica Zapping, porque el reproductor del sistema no lo admite.` }));
  const v = player.video;
  const diag = [
    `Formato: ${player.vod ? `archivo leído por Zapping (vídeo ${player.vod.vcodec || '?'}, sonido convertido a ${player.vod.enc === 'aac' ? 'AAC' : 'Opus'})` : player.current?.kind === 'ts' ? 'MPEG-TS' : player.current?.kind === 'hls' ? 'HLS' : player.current?.kind === 'native' ? 'archivo' : player.current?.kind || '—'}.`,
    player.soft ? player.soft.diagnosis() : '',
    typeof v.webkitAudioDecodedByteCount === 'number' ? `Audio del reproductor: ${Math.round(v.webkitAudioDecodedByteCount / 1024)} KB.` : '',
  ].filter(Boolean).join(' ');
  kids.push(h('p', { class: 'tm-note small tm-diag', text: `Diagnóstico de audio: ${diag}` }));
  kids.push(h('p', { class: 'tm-title', text: 'Subtítulos' }));
  if (subs.length) {
    kids.push(item('Desactivados', !subs.some((x) => x.active), () => { player.userSubs = true; player._subsOff(); }));
    subs.forEach((x) => kids.push(item(x.label, x.active, () => { player.userSubs = true; x.select(); })));
  } else {
    kids.push(h('p', { class: 'tm-note', text: 'Esta emisión no trae subtítulos que se puedan mostrar aquí.' }));
  }
  if (!audio.length || !subs.length) {
    kids.push(h('p', { class: 'tm-note small', text: PLATFORM === 'android'
      ? 'Si el archivo tiene más idiomas o subtítulos incrustados, ábrelo en VLC para elegirlos.'
      : 'Si el archivo tiene más idiomas o subtítulos incrustados, ábrelo en un reproductor externo para elegirlos.' }));
  }
  menu.replaceChildren(...kids);
}

$('#live-tracks').addEventListener('click', (e) => {
  e.stopPropagation();
  if (tracksFor) return closeTracksMenu();
  if (!livePlayer.current) return toast('Pon un canal para ver sus pistas de audio y subtítulos.');
  openTracksMenu(livePlayer, e.currentTarget);
});
$('#theater-tracks').addEventListener('click', (e) => {
  e.stopPropagation();
  if (tracksFor) return closeTracksMenu();
  openTracksMenu(theaterPlayer, e.currentTarget);
});
document.addEventListener('click', (e) => {
  if (tracksFor && !e.target.closest('#tracks-menu')) closeTracksMenu();
});
window.addEventListener('resize', () => tracksFor && closeTracksMenu());

/* ------------------------------------------------------------ tamaño de carátulas */

const POSTER_SIZES = ['s', 'm', 'l', 'xl'];
const POSTER_NAMES = { s: 'pequeñas', m: 'medianas', l: 'grandes', xl: 'muy grandes' };

function applyPosterSize() {
  const size = POSTER_SIZES.includes(S.store?.settings?.posterSize) ? S.store.settings.posterSize : 'm';
  document.body.dataset.poster = size;
  $$('#size-menu [data-size]').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.size === size)));
}

function setPosterSize(size, announce = true) {
  if (!POSTER_SIZES.includes(size)) return;
  const cur = S.store.settings.posterSize || 'm';
  if (cur === size) return;
  // mantener a la vista la carátula que estaba arriba
  const body = $('#content-body');
  const first = $$('.poster', body).find((p) => p.getBoundingClientRect().bottom > body.getBoundingClientRect().top + 8);
  S.store.settings = { ...S.store.settings, posterSize: size };
  api.setStore('settings', S.store.settings);
  applyPosterSize();
  if (first) first.scrollIntoView({ block: 'start' });
  if (announce) toast(`Carátulas ${POSTER_NAMES[size]}`, false, 1400, 'poster-size');
}

function closeSizeMenu() {
  $('#size-menu').classList.add('hidden');
  $('#btn-size').setAttribute('aria-expanded', 'false');
}

$('#btn-size').addEventListener('click', (e) => {
  e.stopPropagation();
  const menu = $('#size-menu');
  const open = menu.classList.toggle('hidden') === false;
  $('#btn-size').setAttribute('aria-expanded', String(open));
});
$('#size-menu').addEventListener('click', (e) => {
  const b = e.target.closest('[data-size]');
  if (!b) return;
  setPosterSize(b.dataset.size, false);
  closeSizeMenu();
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('#size-wrap')) closeSizeMenu();
});

/* Pellizcar con dos dedos sobre las carátulas para cambiar su tamaño */
(function pinchPosters() {
  const body = $('#content-body');
  let d0 = 0;
  const dist = (t) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
  body.addEventListener('touchstart', (e) => {
    d0 = e.touches.length === 2 && $('.poster-grid', body) ? dist(e.touches) : 0;
  }, { passive: true });
  body.addEventListener('touchmove', (e) => {
    if (!d0 || e.touches.length !== 2) return;
    const ratio = dist(e.touches) / d0;
    if (ratio < 1.3 && ratio > 0.77) return;
    const i = POSTER_SIZES.indexOf(S.store.settings.posterSize || 'm');
    const next = POSTER_SIZES[Math.max(0, Math.min(POSTER_SIZES.length - 1, i + (ratio > 1 ? 1 : -1)))];
    d0 = dist(e.touches); // un paso por gesto: hay que seguir separando o juntando los dedos
    setPosterSize(next);
  }, { passive: true });
  body.addEventListener('touchend', () => {
    d0 = 0;
  });
})();

/* ------------------------------------------------------------ disposición */

function applyLayout() {
  const w = window.innerWidth;
  const hgt = window.innerHeight;
  const compact = !IS_TV && (w < 760 || hgt < 500);
  const land = w > hgt;
  const pref = S.store?.settings?.menuLayout || 'auto';
  const menu = pref === 'auto' ? (IS_TV ? 'top' : compact && !land ? 'bottom' : 'side') : pref;
  const b = document.body;
  b.classList.toggle('compact', compact);
  b.classList.toggle('land', land);
  for (const m of ['side', 'top', 'bottom']) b.classList.toggle('menu-' + m, m === menu);
}

function applyOrientation() {
  if (PLATFORM === 'android' && !IS_TV) api.setOrientation?.(S.store?.settings?.orientation || 'auto');
}

let layoutT = null;
window.addEventListener('resize', () => {
  clearTimeout(layoutT);
  layoutT = setTimeout(() => {
    applyLayout();
    if (S.live.current) markActiveChannel(true);
  }, 80);
});

if (PLATFORM === 'android') {
  $('#live-idle').replaceChildren(
    h('p', { text: 'Elige un canal de la lista.' }),
    h('p', { class: 'muted small', text: 'Desliza arriba o abajo sobre el vídeo: a la izquierda cambia el brillo y a la derecha el volumen. Toca dos veces para verlo a pantalla completa.' })
  );
  $('#live-video').setAttribute('controlslist', 'nofullscreen noplaybackrate nodownload');
  $('#theater-video').setAttribute('controlslist', 'nofullscreen nodownload');
}

/* Botón «atrás» de Android */
window.zappingBack = () => {
  const dlg = $$('dialog').find((d) => d.open);
  if (dlg) return dlg.close();
  if (tracksFor) return closeTracksMenu();
  if (document.body.classList.contains('cats-open')) return closeCatSheet();
  if ($('.pseudo-fs')) return exitFull();
  if (theaterState) return closeTheater();
  if (document.body.classList.contains('epg-open')) return toggleGuide(false);
  if (S.pl) {
    if (S.detail) return closeDetail();
    if (document.activeElement && isTyping({ target: document.activeElement })) return document.activeElement.blur();
    if (S.store.playlists.length > 1) return goHome();
  }
  api.exit?.();
};

/* La app pasa a segundo plano: parar la emisión para no gastar conexión */
window.zappingPause = () => {
  stopVpnWait();
  if (theaterState) {
    saveTheaterProgress();
    $('#theater-video').pause();
  }
  if (S.live.current) {
    S.live.resumeItem = S.live.current;
    livePlayer.stop();
  }
};
/* Entrar y salir de la ventana flotante: solo se ve el vídeo */
window.zappingPip = (on) => {
  document.body.classList.toggle('pip', !!on);
  if (on) {
    closeCatSheet();
    $('#osd').classList.remove('show');
  }
};

window.zappingResume = () => {
  const it = S.live.resumeItem;
  S.live.resumeItem = null;
  if (it && S.pl && S.section === 'live' && !theaterState && S.live.current?.key === it.key) playLive(it);
};

/* ------------------------------------------------------------ arranque */

(async function boot() {
  S.store = await api.getStore();
  S.store.favorites ||= {};
  S.store.recent ||= {};
  S.store.progress ||= {};
  S.store.vpn ||= {};
  applyOrientation();
  applyLayout();
  applyPosterSize();
  if (TV_PREF !== (S.store.settings.tvMode || 'auto')) S.store.settings.tvMode = TV_PREF;
  renderHome();
  showView('home');
  window.__zappingReady = true;
  if (window.ZAPPING_SAFE) {
    toast('Zapping se cerró por falta de memoria y se ha vuelto a abrir sin la guía externa. Si pasa a menudo, desactívala en Ajustes.', false, 9000);
  }
  if (S.store.playlists.length === 1) openPlaylist(S.store.playlists[0]);
})();
