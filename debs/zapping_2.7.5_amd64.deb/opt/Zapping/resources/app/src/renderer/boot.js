'use strict';
/* Zapping · arranque protegido
   Si algo falla al abrir la app (por ejemplo, en un Fire TV Stick con un navegador del
   sistema antiguo), en vez de quedarse la pantalla en blanco se muestra qué ha pasado y
   se ofrece reintentar o arrancar sin el modo tele. */
window.ZAPPING_SAFE = location.hash === '#seguro';
(function () {
  const errs = [];
  let box = null;

  function show(reason) {
    if (window.__zappingReady) return;
    if (!document.body) {
      document.addEventListener('DOMContentLoaded', () => show(reason), { once: true });
      return;
    }
    if (!box) {
      box = document.createElement('div');
      box.setAttribute('role', 'alert');
      box.style.cssText =
        'position:fixed;inset:0;z-index:9999;background:#13171e;color:#e9ecf1;font:16px/1.5 sans-serif;' +
        'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:32px;text-align:center';
      document.body.appendChild(box);
    }
    box.innerHTML = '';
    const h = document.createElement('h2');
    h.textContent = 'Zapping no ha podido arrancar';
    h.style.cssText = 'margin:0;font-size:22px';
    const p = document.createElement('p');
    p.textContent = reason || 'Ha ocurrido un error al abrir la aplicación.';
    p.style.cssText = 'margin:0;color:#8d97a8;max-width:60ch';
    const pre = document.createElement('pre');
    pre.textContent = errs.slice(0, 4).join('\n') + '\n' + navigator.userAgent;
    pre.style.cssText = 'margin:0;max-width:90vw;max-height:30vh;overflow:auto;white-space:pre-wrap;font-size:12px;color:#c7cdd8;background:#191e27;padding:10px 14px;border-radius:8px;text-align:left';
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:12px;flex-wrap:wrap;justify-content:center';
    const mk = (text, fn) => {
      const b = document.createElement('button');
      b.textContent = text;
      b.style.cssText = 'font:inherit;padding:10px 18px;border-radius:8px;border:2px solid #f0a43a;background:#222935;color:#fff';
      b.addEventListener('click', fn);
      b.addEventListener('focus', () => (b.style.background = '#f0a43a'));
      b.addEventListener('blur', () => (b.style.background = '#222935'));
      row.appendChild(b);
      return b;
    };
    const first = mk('Reintentar', () => location.reload());
    mk('Arrancar sin modo tele', () => {
      try { localStorage.setItem('zapping.tvMode', 'off'); } catch {}
      location.reload();
    });
    mk('Modo seguro (sin guía externa)', () => {
      location.hash = '#seguro';
      location.reload();
    });
    box.append(h, p, pre, row);
    // flechas del mando entre los botones, aunque el resto de la app no haya cargado
    if (!box.__keys) {
      box.__keys = true;
      // en «window» y en captura: va antes que el manejo del mando de la app
      window.addEventListener('keydown', (e) => {
        if (!box || !box.isConnected || window.__zappingReady) return;
        const bs = Array.from(box.querySelectorAll('button'));
        const i = bs.indexOf(document.activeElement);
        let n = -1;
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') n = Math.min(bs.length - 1, i + 1);
        else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') n = Math.max(0, i - 1);
        else if (e.key === 'Enter' && i >= 0) n = -2;
        if (n === -1) return;
        e.preventDefault();
        e.stopImmediatePropagation();
        if (n === -2) bs[i].click();
        else bs[n].focus();
      }, true);
    }
    setTimeout(() => first.focus(), 50);
  }

  window.addEventListener('error', (e) => {
    errs.push(`${e.message || e.error || 'Error'} (${String(e.filename || '').split('/').pop()}:${e.lineno || '?'})`);
    if (!window.__zappingReady) show('Ha ocurrido un error al abrir la aplicación.');
  });
  window.addEventListener('unhandledrejection', (e) => {
    errs.push(String((e.reason && (e.reason.stack || e.reason.message)) || e.reason));
    if (!window.__zappingReady) show('Ha ocurrido un error al abrir la aplicación.');
  });
  setTimeout(() => {
    if (!window.__zappingReady) show('La aplicación ha tardado demasiado en arrancar.');
  }, 20000);
})();
