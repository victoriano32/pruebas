'use strict';
/* Sonido Dolby (AC-3 / E-AC-3) por software.
   El motor de vídeo de Android/Chrome no decodifica AC-3: hls.js descarta ese audio y el
   canal se ve sin sonido. Aquí se aparta el audio de cada trozo MPEG-TS que descarga
   hls.js, se decodifica con FFmpeg compilado a WebAssembly (vendor/ac3-decoder.js) y se
   reproduce con Web Audio, sincronizado con el reloj del vídeo. */

/* ---------- Demultiplexado MPEG-TS: solo el audio ---------- */

const TS_AUDIO_TYPES = { 0x03: 'mp2', 0x04: 'mp2', 0x0f: 'aac', 0x11: 'aac', 0x81: 'ac-3', 0x87: 'ec-3', 0x8a: 'dts', 0x82: 'dts' };

function makeTsAudioDemuxer() {
  const st = {
    pmtPids: new Set(),
    streams: null, // [{pid, codec}]
    pid: -1, // PID de audio que se decodifica
    pes: null, // { pts, chunks: [], size }
    rest: null, // bytes de un paquete TS a medias (flujo continuo)
    synced: false,
  };

  function parsePat(b, o) {
    const len = ((b[o + 1] & 0x0f) << 8) | b[o + 2];
    for (let q = o + 8; q + 4 <= o + 3 + len - 4; q += 4) {
      const prog = (b[q] << 8) | b[q + 1];
      if (prog) st.pmtPids.add(((b[q + 2] & 0x1f) << 8) | b[q + 3]);
    }
  }

  function parsePmt(b, o, packetEnd) {
    const len = ((b[o + 1] & 0x0f) << 8) | b[o + 2];
    const end = Math.min(o + 3 + len - 4, packetEnd);
    const infoLen = ((b[o + 10] & 0x0f) << 8) | b[o + 11];
    let q = o + 12 + infoLen;
    const streams = [];
    while (q + 5 <= end) {
      const type = b[q];
      const pid = ((b[q + 1] & 0x1f) << 8) | b[q + 2];
      const esLen = ((b[q + 3] & 0x0f) << 8) | b[q + 4];
      let codec = TS_AUDIO_TYPES[type] || '';
      if (type === 0x06) {
        for (let d = q + 5; d + 2 <= q + 5 + esLen; d += 2 + b[d + 1]) {
          if (b[d] === 0x6a) codec = 'ac-3';
          else if (b[d] === 0x7a) codec = 'ec-3';
          else if (b[d] === 0x7b) codec = 'dts';
        }
      }
      if (codec) streams.push({ pid, codec });
      q += 5 + esLen;
    }
    if (streams.length) {
      st.streams = streams;
      // se prepara ya el primer audio Dolby, por si hay que decodificarlo
      const dolby = streams.find((x) => x.codec === 'ac-3' || x.codec === 'ec-3');
      if (st.pid < 0 && dolby) st.pid = dolby.pid;
    }
  }

  function flushPes(out) {
    const p = st.pes;
    st.pes = null;
    if (!p || !p.size) return;
    const data = new Uint8Array(p.size);
    let off = 0;
    for (const c of p.chunks) {
      data.set(c, off);
      off += c.length;
    }
    out.push({ pts: p.pts, data });
  }

  return {
    get streams() {
      return st.streams;
    },
    selectPid(pid) {
      st.pid = pid;
    },
    /* Devuelve los paquetes PES completos del PID elegido: [{pts (en 1/90000 s o null), data}] */
    push(input) {
      const out = [];
      let b = input;
      if (st.rest) {
        b = new Uint8Array(st.rest.length + input.length);
        b.set(st.rest);
        b.set(input, st.rest.length);
        st.rest = null;
      }
      let start = -1;
      if (st.synced && b[0] === 0x47) start = 0;
      else {
        for (let i = 0; i + 376 < b.length && i < 188 * 8; i++) {
          if (b[i] === 0x47 && b[i + 188] === 0x47 && b[i + 376] === 0x47) {
            start = i;
            break;
          }
        }
      }
      if (start < 0) {
        st.synced = false;
        if (b.length < 188 * 3) st.rest = b.slice();
        return out;
      }
      st.synced = true;
      let p = start;
      for (; p + 188 <= b.length; p += 188) {
        if (b[p] !== 0x47) {
          // se perdió la alineación: buscarla de nuevo en el siguiente trozo
          st.synced = false;
          st.rest = b.slice(p);
          return out;
        }
        const pusi = b[p + 1] & 0x40;
        const pid = ((b[p + 1] & 0x1f) << 8) | b[p + 2];
        const afc = (b[p + 3] >> 4) & 3;
        if (afc === 2 || afc === 0) continue;
        let o = p + 4;
        if (afc === 3) o += 1 + b[o];
        if (o >= p + 188) continue;
        if (pid === 0 || st.pmtPids.has(pid)) {
          if (!pusi) continue;
          const t = o + 1 + b[o];
          if (pid === 0 && b[t] === 0x00) parsePat(b, t);
          else if (b[t] === 0x02) parsePmt(b, t, p + 188);
          continue;
        }
        if (pid !== st.pid) continue;
        if (pusi) {
          flushPes(out);
          // cabecera PES: 00 00 01 | id | longitud | flags | flags | longitud cabecera | PTS
          if (b[o] !== 0 || b[o + 1] !== 0 || b[o + 2] !== 1) continue;
          const flags = b[o + 7];
          const hlen = b[o + 8];
          let pts = null;
          if (flags & 0x80) {
            pts =
              (b[o + 9] & 0x0e) * 536870912 + // << 29
              b[o + 10] * 4194304 + // << 22
              (b[o + 11] & 0xfe) * 16384 + // << 14
              b[o + 12] * 128 + // << 7
              (b[o + 13] >> 1);
          }
          const ps = o + 9 + hlen;
          st.pes = { pts, chunks: [], size: 0 };
          if (ps < p + 188) {
            const c = b.subarray(ps, p + 188);
            st.pes.chunks.push(c.slice());
            st.pes.size += c.length;
          }
        } else if (st.pes) {
          const c = b.subarray(o, p + 188);
          st.pes.chunks.push(c.slice());
          st.pes.size += c.length;
        }
      }
      // lo que sobra (menos de un paquete) se une al siguiente trozo
      if (p < b.length) st.rest = b.slice(p);
      // el último PES se entrega cuando empiece el siguiente (puede seguir en el próximo trozo)
      return out;
    },
  };
}

/* ---------- Tramas AC-3 / E-AC-3 ---------- */

const AC3_FRAME_WORDS = [
  [64, 64, 80, 80, 96, 96, 112, 112, 128, 128, 160, 160, 192, 192, 224, 224, 256, 256, 320, 320, 384, 384, 448, 448, 512, 512, 640, 640, 768, 768, 896, 896, 1024, 1024, 1152, 1152, 1280, 1280],
  [69, 70, 87, 88, 104, 105, 121, 122, 139, 140, 174, 175, 208, 209, 243, 244, 278, 279, 348, 349, 417, 418, 487, 488, 557, 558, 696, 697, 835, 836, 975, 976, 1114, 1115, 1253, 1254, 1393, 1394],
  [96, 96, 120, 120, 144, 144, 168, 168, 192, 192, 240, 240, 288, 288, 336, 336, 384, 384, 480, 480, 576, 576, 672, 672, 768, 768, 960, 960, 1152, 1152, 1344, 1344, 1536, 1536, 1728, 1728, 1920, 1920],
];

function ac3FrameSize(b, i) {
  if (b[i] !== 0x0b || b[i + 1] !== 0x77 || i + 6 > b.length) return 0;
  const bsid = b[i + 5] >> 3;
  if (bsid <= 10) {
    const fscod = b[i + 4] >> 6;
    const frmsizecod = b[i + 4] & 0x3f;
    if (fscod > 2 || frmsizecod > 37) return 0;
    return AC3_FRAME_WORDS[fscod][frmsizecod] * 2;
  }
  if (bsid <= 16) return ((((b[i + 2] & 0x07) << 8) | b[i + 3]) + 1) * 2; // E-AC-3
  return 0;
}

/* ---------- Decodificador (WebAssembly) ---------- */

let ac3ModulePromise = null;

function loadAc3Module() {
  if (!ac3ModulePromise) {
    ac3ModulePromise = new Promise((resolve, reject) => {
      if (globalThis.createAc3Module) return resolve();
      const s = document.createElement('script');
      s.src = 'vendor/ac3-decoder.js';
      s.onload = () => resolve();
      s.onerror = () => reject(new Error('No se pudo cargar el decodificador de audio.'));
      document.head.append(s);
    })
      .then(() => globalThis.createAc3Module())
      .then((m) => ({
        m,
        init: m.cwrap('init_decoder', 'number', ['number']),
        packet: m.cwrap('configure_decode_packet', 'number', ['number', 'number']),
        decode: m.cwrap('decode_packet', 'number', ['number', 'number']),
        format: m.cwrap('get_decoded_format', 'number', ['number']),
        plane: m.cwrap('get_decoded_plane_ptr', 'number', ['number', 'number']),
        channels: m.cwrap('get_decoded_channels', 'number', ['number']),
        rate: m.cwrap('get_decoded_sample_rate', 'number', ['number']),
        count: m.cwrap('get_decoded_sample_count', 'number', ['number']),
        close: m.cwrap('close_decoder', null, ['number']),
      }))
      .catch((e) => {
        ac3ModulePromise = null;
        throw e;
      });
  }
  return ac3ModulePromise;
}

/* ---------- Copia de lo que descarga el reproductor MPEG-TS ----------
   mpegts.js descarga la emisión con fetch(). Para no abrir una segunda conexión (los
   proveedores limitan cuántas puede haber a la vez), se duplica el flujo de esa misma
   descarga y una copia va al decodificador de audio. */
const fetchTaps = new Map(); // url → { fn, readers: Set }

function tapFetch(url, fn) {
  const entry = { fn, readers: new Set() };
  fetchTaps.set(url, entry);
  return () => {
    if (fetchTaps.get(url) === entry) fetchTaps.delete(url);
    for (const r of entry.readers) r.cancel().catch(() => {});
    entry.readers.clear();
  };
}

(function patchFetch() {
  const orig = window.fetch;
  if (!orig || orig.__zapping) return;
  const wrapped = function (input, init) {
    const url = typeof input === 'string' ? input : input && input.url;
    const entry = url ? fetchTaps.get(url) : null;
    const p = orig.call(this, input, init);
    if (!entry) return p;
    return p.then((res) => {
      if (!res.ok || !res.body || typeof res.body.tee !== 'function') return res;
      const [forPlayer, forAudio] = res.body.tee();
      const reader = forAudio.getReader();
      entry.readers.add(reader);
      (async () => {
        try {
          for (;;) {
            const { value, done } = await reader.read();
            if (done || fetchTaps.get(url) !== entry) break;
            if (value && value.length) entry.fn(value);
          }
        } catch {}
        entry.readers.delete(reader);
        reader.cancel().catch(() => {});
      })();
      const out = new Response(forPlayer, { status: res.status, statusText: res.statusText, headers: res.headers });
      try {
        Object.defineProperty(out, 'url', { value: res.url });
        Object.defineProperty(out, 'redirected', { value: res.redirected });
      } catch {}
      return out;
    });
  };
  wrapped.__zapping = true;
  window.fetch = wrapped;
})();

/* ---------- No fiarse del soporte Dolby que anuncia el sistema ----------
   Muchos móviles dicen admitir AC-3 porque pueden enviarlo por HDMI a una barra de sonido,
   pero por el altavoz no suena nada. Si el reproductor lo cree, le pasa el Dolby al sistema
   y el canal queda mudo. Se le dice que no hay AC-3: así elige otro audio si lo hay, y si no,
   el Dolby lo decodifica Zapping. */
(function hideNativeDolby() {
  for (const MS of [window.MediaSource, window.ManagedMediaSource]) {
    if (!MS || typeof MS.isTypeSupported !== 'function' || MS.__zapping) continue;
    const orig = MS.isTypeSupported.bind(MS);
    MS.isTypeSupported = (type) => (/\b(ac-?3|ec-?3|eac3)\b/i.test(String(type)) ? false : orig(type));
    MS.__zapping = true;
  }
})();

/* ---------- Sistema de audio compartido ----------
   Android y Chrome solo dejan sonar el audio de una página si se pone en marcha tras un
   toque. Se crea (o se reanuda) con el primer toque en la pantalla y se reutiliza. */
let sharedAudioCtx = null;

function audioCtx() {
  if (!sharedAudioCtx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    sharedAudioCtx = new AC({ latencyHint: 'playback' });
  }
  return sharedAudioCtx;
}

function unlockAudio() {
  const c = audioCtx();
  if (c && c.state === 'suspended') c.resume().catch(() => {});
}
for (const ev of ['pointerdown', 'touchend', 'click', 'keydown']) {
  document.addEventListener(ev, unlockAudio, { capture: true, passive: true });
}

/* ---------- Reproducción sincronizada ---------- */

class SoftAudio {
  constructor(video) {
    this.video = video;
    this.demux = makeTsAudioDemuxer();
    this.codec = '';
    this.state = 'probe'; // probe → loading → on | off
    this.queue = []; // [{ pts (s, sin ajustar), dur, buf, src }]
    this.offset = null; // segundos que hay que restar al PTS para tener el tiempo del vídeo
    this.decoded = 0;
    this.probes = 0;
    this.reason = '';
    this.ctx = null;
    this.gain = null;
    this.anchor = null; // { w: tiempo del AudioContext, t: tiempo del vídeo }
    this.carry = null; // trozo de trama a medias entre paquetes
    this.nextPts = null;
    this.onVideoEvent = (e) => {
      if (e && e.type === 'ratechange' && this.ownRate) {
        this.ownRate = false; // el cambio de velocidad lo hicimos nosotros
        return;
      }
      this.resync();
    };
    this.onVolume = () => this.applyVolume();
    for (const ev of ['pause', 'seeking', 'waiting', 'ratechange']) video.addEventListener(ev, this.onVideoEvent);
    video.addEventListener('volumechange', this.onVolume);
    this.timer = setInterval(() => this.pump(), 50);
  }

  get active() {
    return this.state === 'on' && this.decoded > 0;
  }

  /* hls.js ha descargado un trozo de la emisión */
  feed(bytes) {
    // se sigue leyendo aunque esté apagado: por si luego hay que activar el Dolby
    const packets = this.demux.push(bytes);
    if (this.state === 'off') return;
    if (this.state === 'probe') {
      const streams = this.demux.streams;
      if (!streams) {
        // trozos sin audio (el audio va en una pista aparte): dejar de mirar
        if (++this.probes > 3) this.state = 'off';
        return;
      }
      // Si hay AAC, el reproductor lo usará y no hace falta nada (salvo que luego se detecte silencio)
      const aac = streams.find((s) => s.codec === 'aac');
      const dolby = streams.find((s) => s.codec === 'ac-3' || s.codec === 'ec-3');
      if (aac || !dolby) {
        this.state = 'off';
        this.reason = dolby ? 'la emisión trae también AAC' : 'la emisión no lleva audio Dolby';
        return;
      }
      this.pending = packets;
      this.enableDolby();
      return;
    }
    if (this.state === 'loading') {
      this.pending.push(...packets);
      return;
    }
    this.decodePackets(packets);
  }

  /* Activa el decodificador para el primer audio Dolby de la emisión.
     También se usa si se detecta silencio aunque hubiera otro audio. */
  enableDolby() {
    const dolby = (this.demux.streams || []).find((s) => s.codec === 'ac-3' || s.codec === 'ec-3');
    if (!dolby || this.state === 'on' || this.state === 'loading') return false;
    this.codec = dolby.codec;
    this.demux.selectPid(dolby.pid);
    this.state = 'loading';
    this.reason = '';
    this.pending ||= [];
    this.start().catch((e) => {
      this.state = 'off';
      this.reason = e?.message || 'error al iniciar el decodificador';
    });
    return true;
  }

  get hasDolby() {
    return !!(this.demux.streams || []).find((s) => s.codec === 'ac-3' || s.codec === 'ec-3');
  }

  async start() {
    this.lib = await loadAc3Module();
    if (this.state !== 'loading') return;
    this.dec = this.lib.init(this.codec === 'ec-3' ? 1 : 0);
    if (!this.dec) throw new Error('No se pudo iniciar el decodificador');
    this.ctx = audioCtx();
    if (!this.ctx) throw new Error('Este dispositivo no permite reproducir audio desde la app');
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    this.gain = this.ctx.createGain();
    this.gain.channelCountMode = 'explicit';
    this.gain.channelCount = 2; // 5.1 → estéreo
    this.gain.channelInterpretation = 'speakers';
    this.gain.connect(this.ctx.destination);
    this.applyVolume();
    this.state = 'on';
    const pending = this.pending || [];
    this.pending = null;
    this.decodePackets(pending);
  }

  setTimeOffset(seconds) {
    this.offset = seconds;
  }

  decodePackets(packets) {
    const L = this.lib;
    for (const pkt of packets) {
      let data = pkt.data;
      let t = pkt.pts != null ? pkt.pts / 90000 : this.nextPts;
      if (this.carry) {
        const merged = new Uint8Array(this.carry.length + data.length);
        merged.set(this.carry);
        merged.set(data, this.carry.length);
        data = merged;
        this.carry = null;
        if (this.nextPts != null) t = this.nextPts;
      }
      let i = 0;
      while (i + 6 <= data.length) {
        const size = ac3FrameSize(data, i);
        if (!size) {
          i++;
          continue;
        }
        if (i + size > data.length) {
          this.carry = data.slice(i);
          break;
        }
        const frame = data.subarray(i, i + size);
        i += size;
        const ptr = L.packet(this.dec, frame.length);
        if (!ptr) continue;
        L.m.HEAPU8.set(frame, ptr);
        if (L.decode(this.dec, 0n) < 0) continue;
        const ch = L.channels(this.dec);
        const rate = L.rate(this.dec);
        const n = L.count(this.dec);
        const fmt = L.format(this.dec);
        if (!n || !ch || !rate || (fmt !== 8 && fmt !== 3)) continue;
        const buf = this.ctx.createBuffer(ch, n, rate);
        if (fmt === 8) {
          // float planar
          for (let c = 0; c < ch; c++) {
            const p = L.plane(this.dec, c);
            buf.copyToChannel(new Float32Array(L.m.HEAPU8.buffer, p, n), c);
          }
        } else {
          // float intercalado
          const all = new Float32Array(L.m.HEAPU8.buffer, L.plane(this.dec, 0), n * ch);
          for (let c = 0; c < ch; c++) {
            const one = new Float32Array(n);
            for (let k = 0; k < n; k++) one[k] = all[k * ch + c];
            buf.copyToChannel(one, c);
          }
        }
        const dur = n / rate;
        if (t == null) t = 0;
        this.queue.push({ pts: t, dur, buf, src: null });
        this.decoded++;
        t += dur;
      }
      this.nextPts = t;
    }
    // no acumular más de ~2 minutos
    if (this.queue.length > 4000) this.queue.splice(0, this.queue.length - 4000);
  }

  setRate(r) {
    const v = this.video;
    if (Math.abs((v.playbackRate || 1) - r) < 0.0005) return;
    this.ownRate = true;
    v.playbackRate = r;
  }

  applyVolume() {
    if (!this.gain) return;
    this.gain.gain.value = this.video.muted ? 0 : this.video.volume;
  }

  stopSources() {
    for (const q of this.queue) {
      if (q.src) {
        try { q.src.stop(); } catch {}
        q.src = null;
      }
    }
    this.anchor = null;
  }

  resync() {
    this.stopSources();
  }

  pump() {
    if (this.offsetProvider) {
      const o = this.offsetProvider();
      if (o != null && isFinite(o)) this.offset = o;
    }
    if (this.state !== 'on' || this.offset == null || !this.ctx) return;
    const v = this.video;
    if (v.paused || v.seeking || v.readyState < 3) {
      if (this.anchor) this.stopSources();
      return;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    const now = v.currentTime;
    const ac = this.ctx.currentTime;
    // retardo hasta que el sonido sale por el altavoz o los auriculares
    const lat = Math.min(0.5, this.ctx.outputLatency || this.ctx.baseLatency || 0);
    // Desfase entre audio e imagen: los relojes del sonido y del vídeo no van exactamente
    // al mismo ritmo. Se corrige acelerando o frenando el vídeo como mucho un 1 % (no se nota);
    // si el desfase es grande (más de 0,2 s), se vuelve a sincronizar de golpe.
    if (this.anchor) {
      const drift = this.anchor.t + (ac - this.anchor.w) - (now + lat);
      if (Math.abs(drift) > 0.2) {
        this.stopSources();
        this.setRate(1);
      } else {
        this.setRate(Math.abs(drift) < 0.01 ? 1 : Math.max(0.99, Math.min(1.01, 1 + drift * 0.25)));
      }
    }
    // tirar lo que ya pasó
    while (this.queue.length && this.queue[0].pts - this.offset + this.queue[0].dur < now - 0.5) this.queue.shift();
    const horizon = now + 0.8;
    for (const q of this.queue) {
      const t = q.pts - this.offset;
      if (t > horizon) break;
      if (q.src || t + q.dur <= now) continue;
      if (!this.anchor) this.anchor = { w: ac + 0.1, t: now + 0.1 + lat };
      let when = this.anchor.w + (t - this.anchor.t);
      let skip = 0;
      if (when < ac) {
        skip = ac - when;
        when = ac;
      }
      if (skip >= q.dur) continue;
      const src = this.ctx.createBufferSource();
      src.buffer = q.buf;
      src.connect(this.gain);
      src.start(when, skip);
      q.src = src;
    }
  }

  /* Una línea para el menú de audio: ayuda a saber qué pasa si un canal no suena */
  diagnosis() {
    const st = this.demux.streams;
    const list = st ? st.map((x) => audioCodecName(x.codec).replace(/ \(.*\)$/, '')).join(', ') : 'aún sin leer';
    const dec =
      this.state === 'on' ? `activo, ${this.decoded} tramas` : this.state === 'loading' ? 'cargando' : this.state === 'probe' ? 'esperando datos' : `apagado${this.reason ? ` (${this.reason})` : ''}`;
    return `Audios en la emisión: ${list}. Decodificador de Zapping: ${dec}. Sonido del sistema: ${sharedAudioCtx ? sharedAudioCtx.state : 'sin iniciar'}.`;
  }

  destroy() {
    clearInterval(this.timer);
    if (this.video.playbackRate !== 1) {
      this.ownRate = true;
      this.video.playbackRate = 1;
    }
    for (const ev of ['pause', 'seeking', 'waiting', 'ratechange']) this.video.removeEventListener(ev, this.onVideoEvent);
    this.video.removeEventListener('volumechange', this.onVolume);
    this.stopSources();
    this.queue = [];
    this.state = 'off';
    if (this.dec && this.lib) {
      try { this.lib.close(this.dec); } catch {}
    }
    this.dec = 0;
    // el sistema de audio es compartido: solo se desconecta lo de este canal
    try { this.gain?.disconnect(); } catch {}
    this.gain = null;
    this.ctx = null;
  }
}
