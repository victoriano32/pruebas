/* Zapping · Google TV / Android TV
   Todo se maneja con el mando: las flechas mueven el foco al elemento más cercano en esa
   dirección, OK lo pulsa y Atrás vuelve. En el directo a pantalla completa, arriba y abajo
   cambian de canal; en películas y series, izquierda y derecha avanzan y retroceden. */
'use strict';

(function tvMode() {
  if (typeof IS_TV === 'undefined' || !IS_TV) return;
  const body = document.body;
  body.classList.add('tv');
  // Fire TV Stick: mando sin números ni botones de canal, y menos memoria
  const FIRE = typeof IS_FIRE !== 'undefined' ? IS_FIRE : !!api.isFireTv?.();
  if (FIRE) document.documentElement.classList.add('fire');

  const DIRS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };
  const KEYS_CH_UP = ['ChannelUp', 'PageUp'];
  const KEYS_CH_DOWN = ['ChannelDown', 'PageDown'];
  const KEYS_PLAY = ['MediaPlayPause', ' '];

  /* ---------- Elementos que se pueden elegir con el mando ---------- */

  // filas y tarjetas que en el móvil se tocan pero no son botones
  const CLICKABLE = '.ch, #cat-list li[data-cat], .ep, .pl-card, .poster';
  function markClickable(root) {
    for (const el of root.querySelectorAll ? root.querySelectorAll(CLICKABLE) : []) {
      if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '0');
    }
  }
  new MutationObserver((muts) => {
    for (const m of muts) for (const n of m.addedNodes) if (n.nodeType === 1) {
      if (n.matches?.(CLICKABLE) && !n.hasAttribute('tabindex')) n.setAttribute('tabindex', '0');
      markClickable(n);
    }
  }).observe(body, { childList: true, subtree: true });
  markClickable(document);

  const FOCUSABLE =
    'button, input:not([type=hidden]), select, textarea, a[href], summary, [tabindex]:not([tabindex="-1"])';

  function visible(el) {
    if (el.disabled || el.closest('[hidden], .hidden, [inert]')) return false;
    if (typeof el.checkVisibility === 'function' && !el.checkVisibility({ checkOpacity: false, checkVisibilityCSS: true })) return false;
    const r = el.getBoundingClientRect();
    return r.width > 2 && r.height > 2;
  }

  /* Zona en la que se mueve el foco: el diálogo o menú abierto, o la pantalla */
  function scope() {
    const dlg = $$('dialog').find((d) => d.open);
    if (dlg) return dlg;
    const tm = $('#tracks-menu');
    if (tm && !tm.classList.contains('hidden')) return tm;
    const sm = $('#size-menu');
    if (sm && !sm.classList.contains('hidden')) return sm;
    if (body.classList.contains('cats-open')) return $('#cats-pane');
    if (!$('#theater').classList.contains('hidden')) return $('#theater');
    const home = $('#home');
    if (home && !home.classList.contains('hidden')) return home;
    return $('#browser');
  }

  function candidates(root) {
    return $$(FOCUSABLE, root).filter((el) => !el.closest('.tv-skip') && visible(el));
  }

  /* Recorte de los contenedores con desplazamiento: ¿se ve ahora mismo? */
  function onScreen(el, r) {
    if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) return false;
    for (let p = el.parentElement; p && p !== body; p = p.parentElement) {
      const st = getComputedStyle(p);
      if (!/(auto|scroll|hidden)/.test(st.overflowY + st.overflowX)) continue;
      const pr = p.getBoundingClientRect();
      if (r.bottom <= pr.top + 4 || r.top >= pr.bottom - 4 || r.right <= pr.left + 4 || r.left >= pr.right - 4) return false;
    }
    return true;
  }

  function best(from, dir, list) {
    const a = from;
    const acx = (a.left + a.right) / 2;
    const acy = (a.top + a.bottom) / 2;
    let win = null;
    let winScore = Infinity;
    for (const { el, r, nested } of list) {
      const cx = (r.left + r.right) / 2;
      const cy = (r.top + r.bottom) / 2;
      let primary;
      let ortho;
      let overlap;
      if (dir === 'right' || dir === 'left') {
        if (nested) primary = dir === 'right' ? cx - acx : acx - cx;
        else primary = dir === 'right' ? r.left - a.right : a.left - r.right;
        if (primary < -4 || (nested && primary <= 0)) continue;
        if (!nested && (dir === 'right' ? cx <= acx : cx >= acx)) continue;
        ortho = Math.abs(cy - acy);
        overlap = Math.min(r.bottom, a.bottom) - Math.max(r.top, a.top) > 2;
      } else {
        if (nested) primary = dir === 'down' ? cy - acy : acy - cy;
        else primary = dir === 'down' ? r.top - a.bottom : a.top - r.bottom;
        if (primary < -4 || (nested && primary <= 0)) continue;
        if (!nested && (dir === 'down' ? cy <= acy : cy >= acy)) continue;
        ortho = Math.abs(cx - acx);
        // en vertical se prefiere lo que empieza a la misma altura por la izquierda (listas)
        ortho = Math.min(ortho, Math.abs(r.left - a.left) * 1.2);
        overlap = Math.min(r.right, a.right) - Math.max(r.left, a.left) > 2;
      }
      let score = Math.max(0, primary) + ortho * (overlap ? 0.4 : 2);
      if (!overlap) score += 1000;
      if (!onScreen(el, r)) score += 400;
      if (score < winScore) {
        winScore = score;
        win = el;
      }
    }
    return win;
  }

  let lastRect = null;

  function focusEl(el) {
    if (!el) return;
    if (isTextInput(el)) lockInput(el);
    el.focus({ preventScroll: true });
    try { el.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch {}
    lastRect = el.getBoundingClientRect();
  }

  function move(dir) {
    const root = scope();
    const cur = document.activeElement;
    const inScope = cur && cur !== body && root.contains(cur) && visible(cur);
    const list = candidates(root).filter((el) => el !== cur);
    if (!list.length) return false;
    if (!inScope) {
      focusEl(entryPoint(root, list));
      return true;
    }
    const a = cur.getBoundingClientRect();
    // dentro de una tarjeta (p. ej. editar y borrar una lista) solo se entra y se sale de lado
    const horiz = dir === 'left' || dir === 'right';
    const items = [];
    for (const el of list) {
      const nested = cur.contains(el) || el.contains(cur);
      if (nested && !horiz) continue;
      items.push({ el, r: el.getBoundingClientRect(), nested });
    }
    const next = best(a, dir, items);
    if (next) {
      focusEl(next);
      return true;
    }
    // final de una lista que se va cargando por partes: desplazar y volver a intentar
    const sc = scrollParent(cur);
    if (sc && (dir === 'down' || dir === 'up')) {
      const before = sc.scrollTop;
      sc.scrollTop += dir === 'down' ? 200 : -200;
      if (sc.scrollTop !== before) setTimeout(() => move(dir), 80);
    }
    return true;
  }

  function scrollParent(el) {
    for (let p = el.parentElement; p && p !== body; p = p.parentElement) {
      const st = getComputedStyle(p).overflowY;
      if ((st === 'auto' || st === 'scroll') && p.scrollHeight > p.clientHeight) return p;
    }
    return null;
  }

  /* Por dónde empezar cuando no hay nada con foco */
  function entryPoint(root, list) {
    if (lastRect) {
      const cx = (lastRect.left + lastRect.right) / 2;
      const cy = (lastRect.top + lastRect.bottom) / 2;
      let win = null;
      let d0 = Infinity;
      for (const el of list) {
        const r = el.getBoundingClientRect();
        if (!onScreen(el, r)) continue;
        const d = Math.hypot((r.left + r.right) / 2 - cx, (r.top + r.bottom) / 2 - cy);
        if (d < d0) {
          d0 = d;
          win = el;
        }
      }
      if (win) return win;
    }
    const pref = [
      '.ch.active',
      '.ch',
      '.poster',
      '.pl-card',
      '.rail-btn.active',
      '#theater-tracks',
      '.tracks-menu button[aria-checked="true"]',
      'button.primary',
    ];
    for (const sel of pref) {
      const el = list.find((x) => x.matches(sel) && onScreen(x, x.getBoundingClientRect()));
      if (el) return el;
    }
    return list.find((x) => onScreen(x, x.getBoundingClientRect())) || list[0];
  }

  /* ---------- Cajas de texto: el teclado solo sale al pulsar OK ---------- */

  function isTextInput(el) {
    if (!el) return false;
    if (el.tagName === 'TEXTAREA') return true;
    return el.tagName === 'INPUT' && !/^(checkbox|radio|button|submit|range|color|file)$/i.test(el.type);
  }

  function lockInput(el) {
    if (el.dataset.tvEdit === '1') return;
    el.readOnly = true;
    el.dataset.tvLocked = '1';
  }

  let refocusing = false;
  function editInput(el) {
    el.readOnly = false;
    el.dataset.tvEdit = '1';
    delete el.dataset.tvLocked;
    // volver a darle el foco ya editable hace que salga el teclado de la tele
    refocusing = true;
    el.blur();
    el.focus();
    refocusing = false;
    try { el.click(); } catch {}
    try { el.setSelectionRange(el.value.length, el.value.length); } catch {}
  }

  // las cajas que reciben el foco solas (p. ej. al abrir un diálogo) no sacan el teclado
  document.addEventListener('focusin', (e) => {
    if (isTextInput(e.target) && e.target.dataset.tvEdit !== '1') lockInput(e.target);
  });

  // si lo que tenía el foco desaparece (la lista se vuelve a dibujar), el foco pasa a lo más cercano
  document.addEventListener('focusout', (e) => {
    const gone = e.target;
    if (e.relatedTarget || refocusing) return;
    lastRect = gone.getBoundingClientRect?.() || lastRect;
    setTimeout(() => {
      if (gone.isConnected && visible(gone)) return;
      const a = document.activeElement;
      if (a && a !== body) return;
      if (theaterState && !$$('dialog').some((d) => d.open) && $('#tracks-menu').classList.contains('hidden')) return;
      if (liveFull()) return;
      // al abrir una ficha, el foco va a «Reproducir»
      const prim = S.detail && $('#content-body .btn.primary');
      if (prim && visible(prim) && scope().contains(prim)) return focusEl(prim);
      const root = scope();
      const list = candidates(root);
      if (list.length) focusEl(entryPoint(root, list));
    }, 60);
  });

  document.addEventListener('focusout', (e) => {
    const el = e.target;
    if (refocusing) return;
    if (el && el.dataset && el.dataset.tvEdit === '1') {
      delete el.dataset.tvEdit;
      lockInput(el);
    }
  });

  /* ---------- Directo a pantalla completa ---------- */

  function liveFull() {
    return !!$('#live-box.pseudo-fs');
  }

  function showLiveInfo() {
    const it = S.live.current;
    if (!it) return;
    const idx = S.live.list.findIndex((x) => x.key === it.key);
    const now = Date.now();
    const cur = (S.live.epg || []).find((p) => p.start <= now && now < p.end);
    showOSD(it.num || (idx >= 0 ? idx + 1 : ''), cur ? `${it.name} · ${cur.title}` : it.name);
  }

  function backToList() {
    exitFull();
    setTimeout(() => {
      const row = $('.ch.active') || (S.live.current && $(`.ch[data-key="${CSS.escape(S.live.current.key)}"]`));
      if (row) focusEl(row);
    }, 60);
  }

  /* ---------- Películas y series: barra de tiempo propia ---------- */

  const tv = $('#theater-video');
  const bar = h('div', { class: 'tv-bar', 'aria-hidden': 'true' },
    h('span', { class: 'tv-state' }, h('svg', { class: 'ic' })),
    h('span', { class: 'tv-cur', text: '0:00' }),
    h('div', { class: 'tv-track' }, h('i', { class: 'tv-buf' }), h('i', { class: 'tv-pos' }), h('i', { class: 'tv-seek' })),
    h('span', { class: 'tv-dur', text: '' })
  );
  // el <svg> creado con h() no es SVG de verdad: se pone con innerHTML
  bar.querySelector('.tv-state').innerHTML = '<svg class="ic"><use href="#i-play"/></svg>';
  $('.theater-box').append(bar);
  const hint = h('div', { class: 'tv-hint' });
  $('.theater-box').append(hint);

  let seekTarget = null;
  let seekTimer = null;
  let seekRepeat = 0;

  function fmt(t) {
    return typeof clock === 'function' ? clock(t) : `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
  }

  function paintBar() {
    const d = tv.duration;
    const t = seekTarget ?? tv.currentTime;
    const ok = isFinite(d) && d > 0;
    $('.tv-cur', bar).textContent = fmt(t || 0);
    $('.tv-dur', bar).textContent = ok ? fmt(d) : '';
    $('.tv-pos', bar).style.width = ok ? `${Math.min(100, (tv.currentTime / d) * 100)}%` : '0';
    $('.tv-seek', bar).style.left = ok ? `${Math.min(100, (t / d) * 100)}%` : '0';
    bar.classList.toggle('seeking', seekTarget != null);
    let buf = 0;
    for (let i = 0; i < tv.buffered.length; i++) if (tv.buffered.start(i) <= tv.currentTime + 1) buf = Math.max(buf, tv.buffered.end(i));
    $('.tv-buf', bar).style.width = ok ? `${Math.min(100, (buf / d) * 100)}%` : '0';
    $('.tv-state', bar).innerHTML = `<svg class="ic"><use href="#${tv.paused ? 'i-play' : 'i-pause'}"/></svg>`;
    $('#theater').classList.toggle('tv-paused', tv.paused);
  }
  for (const ev of ['timeupdate', 'play', 'pause', 'durationchange', 'progress', 'seeked']) tv.addEventListener(ev, paintBar);

  function seekBy(step, repeat) {
    const d = tv.duration;
    if (!isFinite(d) || !d) return;
    seekRepeat = repeat ? seekRepeat + 1 : 0;
    const mult = seekRepeat > 12 ? 6 : seekRepeat > 4 ? 3 : 1;
    seekTarget = Math.max(0, Math.min(d - 1, (seekTarget ?? tv.currentTime) + step * mult));
    paintBar();
    theaterActivity();
    clearTimeout(seekTimer);
    seekTimer = setTimeout(() => {
      tv.currentTime = seekTarget;
      seekTarget = null;
      paintBar();
    }, 550);
  }

  function togglePlay() {
    if (tv.paused) tv.play().catch(() => {});
    else tv.pause();
    theaterActivity();
    paintBar();
  }

  function theaterBarFocused() {
    const a = document.activeElement;
    return !!(a && a !== body && $('#theater').contains(a));
  }

  function leaveTheaterBar() {
    document.activeElement?.blur();
    theaterActivity();
  }

  /* ---------- Teclas ---------- */

  document.addEventListener(
    'keydown',
    (e) => {
      const key = e.key;
      const dir = DIRS[key];
      const a = document.activeElement;
      const dlgOpen = $$('dialog').some((d) => d.open);
      const menuOpen = !$('#tracks-menu')?.classList.contains('hidden');

      // Escribiendo en una caja de texto
      if (isTextInput(a) && a.dataset.tvEdit === '1') {
        if (key === 'Enter') {
          // «Hecho» en el teclado de la tele: volver a moverse con las flechas
          setTimeout(() => {
            delete a.dataset.tvEdit;
            lockInput(a);
          }, 0);
          return;
        }
        if (dir === 'left' && a.selectionStart > 0) return;
        if (dir === 'right' && a.selectionEnd < a.value.length) return;
        if (!dir) return;
        delete a.dataset.tvEdit;
        lockInput(a);
      }

      // Películas y series
      if (theaterState && !dlgOpen && !menuOpen) {
        const inBar = theaterBarFocused();
        if (KEYS_PLAY.includes(key) || (key === 'Enter' && !inBar)) {
          e.preventDefault();
          e.stopImmediatePropagation();
          togglePlay();
          return;
        }
        if (key === 'MediaFastForward') {
          e.preventDefault();
          return seekBy(30, e.repeat);
        }
        if (key === 'MediaRewind') {
          e.preventDefault();
          return seekBy(-30, e.repeat);
        }
        if (!inBar && dir) {
          e.preventDefault();
          e.stopImmediatePropagation();
          if (dir === 'left' || dir === 'right') return seekBy(dir === 'right' ? 10 : -10, e.repeat);
          theaterActivity();
          if (dir === 'up') focusEl($('#theater-tracks'));
          else if (!$('#resume-toast').classList.contains('hidden')) focusEl($('#resume-restart'));
          return;
        }
        if (inBar && dir === 'down' && !$('#resume-toast').contains(a)) {
          e.preventDefault();
          e.stopImmediatePropagation();
          return leaveTheaterBar();
        }
        if (inBar && dir === 'up' && $('#resume-toast').contains(a)) {
          e.preventDefault();
          e.stopImmediatePropagation();
          return leaveTheaterBar();
        }
        if (inBar) theaterActivity();
      }

      // Directo a pantalla completa
      if (liveFull() && !dlgOpen && !menuOpen) {
        if (dir === 'up' || KEYS_CH_UP.includes(key)) {
          e.preventDefault();
          e.stopImmediatePropagation();
          return zap(1);
        }
        if (dir === 'down' || KEYS_CH_DOWN.includes(key)) {
          e.preventDefault();
          e.stopImmediatePropagation();
          return zap(-1);
        }
        if (key === 'Enter') {
          e.preventDefault();
          e.stopImmediatePropagation();
          return showLiveInfo();
        }
        if (dir === 'left' || dir === 'right') {
          e.preventDefault();
          e.stopImmediatePropagation();
          return backToList();
        }
        return; // números y demás: los gestiona la app
      }

      // Cambiar de canal con los botones de canal del mando sin estar a pantalla completa
      if ((key === 'ChannelUp' || key === 'ChannelDown') && S.pl && S.section === 'live' && S.live.current) {
        e.preventDefault();
        e.stopImmediatePropagation();
        return zap(key === 'ChannelUp' ? 1 : -1);
      }

      if (dir) {
        e.preventDefault();
        e.stopImmediatePropagation();
        // guía abierta: arriba y abajo recorren la programación
        const info = $('#live-info');
        if (body.classList.contains('epg-open') && info.contains(a) && (dir === 'down' || (dir === 'up' && info.scrollTop > 0))) {
          info.scrollBy({ top: dir === 'down' ? 160 : -160, behavior: 'smooth' });
          return;
        }
        move(dir);
        return;
      }

      if (key === 'Enter' && a && a !== body) {
        // OK sobre el canal que ya se está viendo: pantalla completa
        if (a.matches('.ch') && S.live.current && a.dataset.key === S.live.current.key && !dlgOpen) {
          e.preventDefault();
          e.stopImmediatePropagation();
          toggleLiveFullscreen();
          return;
        }
        if (isTextInput(a)) {
          e.preventDefault();
          e.stopImmediatePropagation();
          editInput(a);
          return;
        }
        if (a.tagName === 'SELECT') {
          e.preventDefault();
          try { a.showPicker(); } catch { a.click(); }
          return;
        }
        if (a.tagName === 'INPUT' && /checkbox|radio/i.test(a.type)) {
          e.preventDefault();
          a.click();
          return;
        }
        if (!/^(BUTTON|A)$/.test(a.tagName)) {
          e.preventDefault();
          e.stopImmediatePropagation();
          a.click();
        }
      }
    },
    true
  );

  // OK sobre el canal que se está viendo cuando la app lo trata como clic (por si acaso)
  // y atrás: al salir de la pantalla completa del directo, el foco vuelve a la lista
  const prevBack = window.zappingBack;
  window.zappingBack = () => {
    if (theaterState && theaterBarFocused() && !$$('dialog').some((d) => d.open) && $('#tracks-menu')?.classList.contains('hidden')) {
      return leaveTheaterBar();
    }
    const a = document.activeElement;
    if (isTextInput(a) && a.dataset.tvEdit === '1') {
      delete a.dataset.tvEdit;
      lockInput(a);
      return;
    }
    if (liveFull()) return backToList();
    const wasTheater = !!theaterState;
    const r = prevBack();
    if (wasTheater) {
      setTimeout(() => {
        const prim = S.detail && $('#content-body .btn.primary');
        if (prim && visible(prim)) return focusEl(prim);
        lastRect = null;
        const root = scope();
        const list = candidates(root);
        if (list.length) focusEl(entryPoint(root, list));
      }, 150);
    }
    return r;
  };

  /* ---------- Botones del mando que la app recibe desde Android ----------
     (canal +/-, play/pausa, avance y retroceso rápido, información) */
  window.zappingKey = (name, repeat) => {
    const ev = new KeyboardEvent('keydown', { key: name, bubbles: true, cancelable: true, repeat: (repeat | 0) > 0 });
    (document.activeElement || document.body).dispatchEvent(ev);
  };
  document.addEventListener(
    'keydown',
    (e) => {
      if (e.key === 'MediaPlay' && theaterState) {
        e.stopImmediatePropagation();
        tv.play().catch(() => {});
        theaterActivity();
      } else if (e.key === 'MediaPause' && theaterState) {
        e.stopImmediatePropagation();
        tv.pause();
        theaterActivity();
      } else if (e.key === 'Info') {
        e.stopImmediatePropagation();
        if (liveFull()) showLiveInfo();
        else if (theaterState) theaterActivity();
      } else if (e.key === 'Guide' || e.key === 'ContextMenu') {
        // botón Menú (☰) del mando del Fire TV, o Guía en otros mandos
        e.preventDefault();
        e.stopImmediatePropagation();
        if (!$('#tracks-menu').classList.contains('hidden')) {
          closeTracksMenu();
          return;
        }
        if (theaterState) {
          // películas y series: idioma de audio y subtítulos
          theaterActivity();
          const b = $('#theater-tracks');
          openTracksMenu(theaterPlayer, b);
          return;
        }
        if (S.pl && S.section === 'live' && S.live.current) {
          // directo: abrir o cerrar la guía completa del canal
          if (liveFull()) exitFull();
          const g = $('#live-guide');
          if (!g.classList.contains('hidden')) {
            toggleGuide();
            setTimeout(() => focusEl(body.classList.contains('epg-open') ? g : $('.ch.active') || g), 80);
          } else {
            showLiveInfo();
          }
        }
      }
    },
    true
  );

  // En la tele no hay ventana flotante: al salir de la app se para la emisión
  if (api.setPipReady) {
    const setPip = api.setPipReady;
    api.setPipReady = () => setPip.call(api, false);
    api.setPipReady();
  }

  /* ---------- Textos y ajustes propios de la tele ---------- */

  const idle = $('#live-idle');
  if (idle) {
    idle.replaceChildren(
      h('p', { text: 'Elige un canal de la lista y pulsa OK.' }),
      h('p', { class: 'muted small', text: FIRE
        ? 'Pulsa OK otra vez para verlo a pantalla completa. Allí, arriba y abajo cambian de canal, OK muestra qué se emite y Atrás vuelve a la lista. El botón Menú (☰) abre la guía del canal.'
        : 'Pulsa OK otra vez para verlo a pantalla completa. Allí, arriba y abajo cambian de canal, OK muestra qué se emite y Atrás vuelve a la lista. También puedes teclear el número del canal.' })
    );
  }

  // al abrir un menú o un diálogo, el foco entra en él
  const focusInto = (root) => setTimeout(() => {
    if (!root || root.contains(document.activeElement)) return;
    const list = candidates(root);
    if (list.length) focusEl(entryPoint(root, list));
  }, 50);
  new MutationObserver(() => {
    const tm = $('#tracks-menu');
    if (tm && !tm.classList.contains('hidden')) focusInto(tm);
  }).observe($('#tracks-menu'), { attributes: true, attributeFilter: ['class'], childList: true });
  for (const d of $$('dialog')) {
    new MutationObserver(() => d.open && focusInto(d)).observe(d, { attributes: true, attributeFilter: ['open'] });
  }
  let theaterShown = false;
  new MutationObserver(() => {
    const shown = !$('#theater').classList.contains('hidden');
    if (shown && !theaterShown) {
      // al empezar una película, las teclas van al vídeo
      document.activeElement?.blur?.();
      seekTarget = null;
      paintBar();
    }
    theaterShown = shown;
  }).observe($('#theater'), { attributes: true, attributeFilter: ['class'] });

  // primer foco al arrancar
  setTimeout(() => {
    if (document.activeElement === body || !document.activeElement) {
      const root = scope();
      const list = candidates(root);
      if (list.length) focusEl(entryPoint(root, list));
    }
  }, 900);
})();
