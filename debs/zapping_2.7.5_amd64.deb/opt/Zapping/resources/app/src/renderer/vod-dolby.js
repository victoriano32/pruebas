/* Zapping · Películas y series con sonido Dolby (AC-3 / E-AC-3)
   Android y Chrome no decodifican el Dolby de los archivos .mkv/.mp4, y su reproductor
   no deja separar el audio. Así que Zapping lee el archivo él mismo (Mediabunny, por
   partes y con una sola conexión), copia el vídeo tal cual, decodifica el Dolby con el
   decodificador de la app y lo vuelve a comprimir en Opus (o AAC). El resultado se le
   entrega al <video> por MediaSource: imagen y sonido van juntos, así que la sincronía,
   la pausa, la barra de tiempo y la ventana flotante funcionan como siempre. */
'use strict';

const VOD_DOLBY = ['ac3', 'eac3'];
const VOD_AHEAD = 75; // segundos de margen por delante
const VOD_BEHIND = 40; // segundos que se conservan por detrás

let vodDecoderRegistered = false;

function registerZapAc3Decoder() {
  const MB = window.Mediabunny;
  if (vodDecoderRegistered || !MB || typeof loadAc3Module !== 'function') return;
  vodDecoderRegistered = true;

  class ZapAc3Decoder extends MB.CustomAudioDecoder {
    static supports(codec) {
      return codec === 'ac3' || codec === 'eac3';
    }

    async init() {
      this.L = await loadAc3Module();
      this.dec = this.L.init(this.codec === 'eac3' ? 1 : 0);
      if (!this.dec) throw new Error('No se pudo iniciar el decodificador Dolby');
    }

    decode(packet) {
      const L = this.L;
      const data = packet.data;
      let t = packet.timestamp;
      let i = 0;
      while (i + 6 <= data.length) {
        let size = ac3FrameSize(data, i);
        if (!size) {
          // no parece una trama: se entrega entera al decodificador
          if (i === 0) size = data.length;
          else break;
        }
        if (i + size > data.length) size = data.length - i;
        const frame = data.subarray(i, i + size);
        i += size;
        const ptr = L.packet(this.dec, frame.length);
        if (!ptr) continue;
        L.m.HEAPU8.set(frame, ptr);
        if (L.decode(this.dec, 0n) < 0) continue;
        const ch = L.channels(this.dec);
        const rate = L.rate(this.dec);
        const n = L.count(this.dec);
        const fmt = L.format(this.dec);
        if (!n || !ch || !rate || (fmt !== 8 && fmt !== 3)) continue;
        let pcm;
        if (fmt === 8) {
          pcm = new Float32Array(n * ch);
          for (let c = 0; c < ch; c++) pcm.set(new Float32Array(L.m.HEAPU8.buffer, L.plane(this.dec, c), n), c * n);
        } else {
          pcm = new Float32Array(L.m.HEAPU8.buffer, L.plane(this.dec, 0), n * ch).slice();
        }
        this.onSample(
          new MB.AudioSample({
            data: pcm,
            format: fmt === 8 ? 'f32-planar' : 'f32',
            numberOfChannels: ch,
            sampleRate: rate,
            timestamp: t,
          })
        );
        t += n / rate;
      }
    }

    flush() {}

    close() {
      if (this.dec && this.L) {
        try { this.L.close(this.dec); } catch {}
      }
      this.dec = 0;
    }
  }

  MB.registerDecoder(ZapAc3Decoder);
}

/* Espera a que un SourceBuffer termine lo que está haciendo */
function sbIdle(sb) {
  if (!sb.updating) return Promise.resolve();
  return new Promise((res) => sb.addEventListener('updateend', res, { once: true }));
}

class VodDolby {
  static supported() {
    return !!(window.Mediabunny && window.MediaSource && window.AudioEncoder && typeof loadAc3Module === 'function');
  }

  constructor(video, url, opts = {}) {
    this.video = video;
    this.url = url;
    this.opts = opts;
    this.gen = 0;
    this.audioIdx = 0;
    this.audioTracks = [];
    this.codec = '';
    this.dead = false;
    // en la tele (Fire TV Stick, poca memoria) se carga menos por delante
    this.aheadLimit = typeof IS_TV !== 'undefined' && IS_TV ? 40 : VOD_AHEAD;
    this.onError = opts.onError || (() => {});
    this.onSeeking = () => this.handleSeek();
  }

  /* Lee la cabecera del archivo. Devuelve true si este reproductor se encarga
     (hay una pista Dolby que el sistema no puede oír) o false para usar el normal. */
  async open() {
    const MB = window.Mediabunny;
    registerZapAc3Decoder();
    this.input = new MB.Input({
      source: new MB.UrlSource(this.url, {
        parallelism: 1, // los proveedores limitan las conexiones simultáneas
        maxCacheSize: (typeof IS_TV !== 'undefined' && IS_TV ? 16 : 48) * 1024 * 1024,
        getRetryDelay: (n) => (n < 4 ? Math.min(1 + n, 4) : null),
      }),
      formats: MB.ALL_FORMATS,
    });
    const vt = await this.input.getPrimaryVideoTrack();
    const ats = await this.input.getAudioTracks();
    if (!vt || !ats.length || this.dead) return false;

    const info = [];
    for (const t of ats) {
      const codec = await t.getCodec();
      let lang = '';
      let name = '';
      let def = false;
      try { lang = await t.getLanguageCode(); } catch {}
      try { name = (await t.getName()) || ''; } catch {}
      try { def = !!(await t.getDisposition())?.default; } catch {}
      info.push({ track: t, codec, lang: lang && lang !== 'und' ? lang : '', name, def });
    }
    // pista que se oiría: la del idioma preferido o la principal del archivo
    const pref = this.opts.audioLang || 'auto';
    const primary = await this.input.getPrimaryAudioTrack();
    let idx = -1;
    if (pref !== 'auto' && typeof langCode === 'function') idx = info.findIndex((a) => langCode(a.lang, a.name) === pref);
    if (idx < 0) idx = Math.max(0, info.findIndex((a) => a.track === primary));
    if (!VOD_DOLBY.includes(info[idx].codec)) return false;

    // Solo se usan pistas que se puedan decodificar (Dolby con el decodificador de la app, AAC, etc.)
    const usable = [];
    for (const a of info) {
      let ok = false;
      try { ok = !!a.codec && (await a.track.canDecode()); } catch {}
      if (ok) usable.push(a);
    }
    if (!usable.includes(info[idx])) return false;
    this.audioTracks = usable;
    this.audioIdx = usable.indexOf(info[idx]);
    this.codec = info[idx].codec === 'eac3' ? 'ec-3' : 'ac-3';

    this.vt = vt;
    this.vcodec = await vt.getCodec();
    const vstr = await vt.getCodecParameterString();
    this.vconfig = await vt.getDecoderConfig();
    if (!this.vcodec || !vstr || !this.vconfig) return false;

    // Opus si el sistema lo puede comprimir; si no, AAC
    const choices = [
      ['opus', 'opus'],
      ['aac', 'mp4a.40.2'],
    ];
    for (const [enc, str] of choices) {
      const mime = `video/mp4; codecs="${vstr}, ${str}"`;
      if (!MediaSource.isTypeSupported(mime)) continue;
      let can = false;
      try { can = await MB.canEncodeAudio(enc, { numberOfChannels: 2, sampleRate: 48000, bitrate: 160000 }); } catch {}
      if (can) {
        this.enc = enc;
        this.mime = mime;
        break;
      }
    }
    if (!this.enc || this.dead) return false;

    let dur = null;
    try { dur = await this.input.getDurationFromMetadata(); } catch {}
    if (!dur) {
      try { dur = await this.input.computeDuration(); } catch {}
    }
    this.duration = dur || 0;

    // MediaSource
    const ms = new MediaSource();
    this.ms = ms;
    this.objUrl = URL.createObjectURL(ms);
    await new Promise((res, rej) => {
      ms.addEventListener('sourceopen', res, { once: true });
      setTimeout(() => rej(new Error('MediaSource no se abre')), 8000);
      this.video.src = this.objUrl;
    });
    if (this.dead) return true;
    if (this.duration > 0) ms.duration = this.duration;
    this.sb = ms.addSourceBuffer(this.mime);
    this.sb.mode = 'segments';
    this.video.addEventListener('seeking', this.onSeeking);
    this.startAt(this.opts.startAt > 0 && (!this.duration || this.opts.startAt < this.duration - 5) ? this.opts.startAt : 0);
    return true;
  }

  get audioCodecLabel() {
    return this.codec === 'ec-3' ? 'Dolby Digital Plus' : 'Dolby Digital';
  }

  /* ---------- Producción del flujo para MediaSource ---------- */

  startAt(t) {
    const gen = ++this.gen;
    this.segStart = t;
    this.producedTo = t;
    this.run(gen, t).catch((e) => {
      if (gen !== this.gen || this.dead) return;
      console.warn('[Zapping] Dolby VOD', e);
      this.onError(e);
    });
  }

  async run(gen, t0) {
    const MB = window.Mediabunny;
    const vsink = new MB.EncodedPacketSink(this.vt);
    const key =
      (await vsink.getKeyPacket(t0, { verifyKeyPackets: true })) || (await vsink.getFirstKeyPacket({ verifyKeyPackets: true }));
    if (!key || gen !== this.gen) return;
    const K = key.timestamp;
    // margen para fotogramas B que se muestran antes que el fotograma clave
    const base = Math.max(0, K - 1);
    this.segStart = K;

    // Vaciar lo anterior y colocar este tramo en su sitio de la línea de tiempo
    await this.withBuffer(async (sb) => {
      try { sb.abort(); } catch {}
      await sbIdle(sb);
      if (sb.buffered.length) {
        sb.remove(0, Infinity);
        await sbIdle(sb);
      }
      sb.timestampOffset = base;
    });
    if (gen !== this.gen) return;

    const output = new MB.Output({
      format: new MB.Mp4OutputFormat({ fastStart: 'fragmented', minimumFragmentDuration: 1 }),
      target: new MB.StreamTarget(
        new WritableStream({
          write: (chunk) => this.append(gen, chunk.data),
        })
      ),
    });
    this.output = output;
    const vsrc = new MB.EncodedVideoPacketSource(this.vcodec);
    let rotation = 0;
    try { rotation = await this.vt.getRotation(); } catch {}
    output.addVideoTrack(vsrc, rotation ? { rotation } : {});
    const asrc = new MB.AudioSampleSource({
      codec: this.enc,
      bitrate: 160000,
      transform: { numberOfChannels: 2, sampleRate: 48000 },
    });
    output.addAudioTrack(asrc);
    await output.start();

    const alive = () => gen === this.gen && !this.dead;

    const videoLoop = async () => {
      let first = true;
      for await (const pkt of vsink.packets(key)) {
        if (!alive()) break;
        if (pkt.timestamp < base) continue;
        await vsrc.add(pkt.clone({ timestamp: pkt.timestamp - base }), first ? { decoderConfig: this.vconfig } : undefined);
        first = false;
      }
      vsrc.close();
    };

    const audioLoop = async () => {
      const asink = new MB.AudioSampleSink(this.audioTracks[this.audioIdx].track);
      for await (const s of asink.samples(K)) {
        if (!alive()) {
          s.close();
          break;
        }
        const ts = s.timestamp - base;
        if (ts < 0) {
          s.close();
          continue;
        }
        s.setTimestamp(ts);
        await asrc.add(s);
        s.close();
      }
      asrc.close();
    };

    try {
      await Promise.all([videoLoop(), audioLoop()]);
    } catch (e) {
      if (!alive()) return;
      throw e;
    }
    if (!alive()) {
      output.cancel().catch(() => {});
      return;
    }
    await output.finalize();
    if (!alive()) return;
    await this.withBuffer(async () => {
      if (this.ms.readyState === 'open') {
        try { this.ms.endOfStream(); } catch {}
      }
    });
  }

  /* Ejecuta operaciones sobre el SourceBuffer de una en una */
  withBuffer(fn) {
    const run = (this.bufQueue || Promise.resolve()).then(async () => {
      if (this.dead || !this.sb) return;
      await sbIdle(this.sb);
      return fn(this.sb);
    });
    this.bufQueue = run.catch(() => {});
    return run;
  }

  bufferedEnd() {
    const b = this.sb?.buffered;
    if (!b || !b.length) return this.producedTo || 0;
    return b.end(b.length - 1);
  }

  async append(gen, data) {
    // no ir demasiado por delante de lo que se está viendo
    const ahead = () => {
      const b = this.sb?.buffered;
      if (!b || !b.length) return 0;
      return b.end(b.length - 1) - Math.max(this.video.currentTime, this.segStart);
    };
    while (gen === this.gen && !this.dead && ahead() > this.aheadLimit) {
      await new Promise((r) => setTimeout(r, 500));
    }
    if (gen !== this.gen || this.dead) return;
    await this.withBuffer(async (sb) => {
      if (gen !== this.gen) return;
      if (this.ms.readyState === 'ended') {
        // tras un fin de archivo, volver a abrir para seguir añadiendo
      }
      const cur = this.video.currentTime;
      // liberar lo ya visto
      if (sb.buffered.length && sb.buffered.start(0) < cur - VOD_BEHIND - 10) {
        sb.remove(0, cur - VOD_BEHIND);
        await sbIdle(sb);
      }
      for (let attempt = 0; ; attempt++) {
        try {
          sb.appendBuffer(data);
          await sbIdle(sb);
          break;
        } catch (e) {
          // memoria de vídeo llena (móviles con poca memoria): liberar lo visto, cargar menos por delante y esperar
          if (e && e.name === 'QuotaExceededError' && attempt < 400 && gen === this.gen && !this.dead) {
            const now = this.video.currentTime;
            const end = sb.buffered.length ? sb.buffered.end(sb.buffered.length - 1) : now;
            this.aheadLimit = Math.max(12, Math.min(this.aheadLimit, (end - now) * 0.8));
            if (sb.buffered.length && sb.buffered.start(0) < now - 3) {
              sb.remove(0, now - 3);
              await sbIdle(sb);
            }
            await new Promise((r) => setTimeout(r, attempt < 2 ? 300 : 1500));
            continue;
          }
          throw e;
        }
      }
      if (sb.buffered.length) {
        this.producedTo = sb.buffered.end(sb.buffered.length - 1);
        // el primer fotograma puede empezar unas décimas después del punto pedido
        const v = this.video;
        const first = sb.buffered.start(0);
        if (v.readyState < 3 && !this.isBuffered(v.currentTime) && first > v.currentTime && first - v.currentTime < 3) {
          v.currentTime = first + 0.01;
        }
      }
    });
  }

  /* ---------- Saltos en la barra de tiempo ---------- */

  isBuffered(t) {
    const b = this.sb?.buffered;
    if (!b) return false;
    for (let i = 0; i < b.length; i++) if (b.start(i) <= t + 0.3 && b.end(i) > t + 0.5) return true;
    return false;
  }

  handleSeek() {
    if (this.dead) return;
    clearTimeout(this.seekTimer);
    this.seekTimer = setTimeout(() => {
      const t = this.video.currentTime;
      if (this.isBuffered(t)) return;
      // ya viene de camino: está un poco por delante de lo último que se ha cargado
      const b = this.sb?.buffered;
      const from = b && b.length ? b.start(b.length - 1) : this.segStart;
      if (t >= Math.max(from, this.segStart) - 0.5 && t <= this.bufferedEnd() + 12) return;
      this.startAt(t);
    }, 180);
  }

  selectAudio(i) {
    if (i === this.audioIdx || !this.audioTracks[i]) return;
    this.audioIdx = i;
    const c = this.audioTracks[i].codec;
    this.codec = c === 'eac3' ? 'ec-3' : c === 'ac3' ? 'ac-3' : c;
    const t = this.video.currentTime;
    const wasPlaying = !this.video.paused;
    this.startAt(t);
    // tras vaciar el búfer, volver al mismo punto
    this.withBuffer(async () => {}).then(() => {
      if (this.dead) return;
      this.video.currentTime = t;
      if (wasPlaying) this.video.play().catch(() => {});
    });
  }

  destroy() {
    this.dead = true;
    this.gen++;
    clearTimeout(this.seekTimer);
    this.video.removeEventListener('seeking', this.onSeeking);
    try { this.output?.cancel().catch(() => {}); } catch {}
    try { this.input?.dispose?.(); } catch {}
    if (this.objUrl) {
      URL.revokeObjectURL(this.objUrl);
      this.objUrl = null;
    }
    this.sb = null;
    this.ms = null;
  }
}
