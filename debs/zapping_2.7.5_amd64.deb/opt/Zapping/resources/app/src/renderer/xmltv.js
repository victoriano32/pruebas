'use strict';
/* Guía externa XMLTV: se usa para los canales a los que el proveedor no da guía.
   Se descarga (comprimida o no), se analiza por partes y se guarda solo la
   programación de las próximas horas para no ocupar memoria. */

const XMLTV_DEFAULT_URL = 'https://raw.githubusercontent.com/davidmuma/EPG_dobleM/master/guiatv.xml.gz';
const XMLTV_MAX_AGE = 6 * 3600 * 1000; // volver a descargar cada 6 horas
const XMLTV_BEFORE = 3 * 3600 * 1000; // guardar desde hace 3 horas…
const XMLTV_AFTER = 36 * 3600 * 1000; // …hasta dentro de 36 horas

const XmlTv = {
  data: null, // { at, url, names: {norm: id}, progs: {id: [[start, end, title, desc]]} }
  loading: null,
  error: null,
};

/* Nombre de canal normalizado para emparejar «ES: LA 1 FHD» con «La 1» */
function xmltvNorm(name) {
  let s = String(name || '')
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .toLowerCase();
  // prefijos de país: «es:», «|es|», «[es]», «es -», «es |»
  s = s.replace(/^\s*(?:[\[|(]\s*[a-z]{2,3}\s*[\]|)]|[a-z]{2,3}\s*[:|\-–»]+)\s*/, '');
  s = s.replace(/\[[^\]]*\]|\([^)]*\)/g, ' ');
  s = s.replace(/\b(?:fhd|uhd|hd|sd|4k|8k|hevc|h\.?26[45]|1080[pi]?|720p?|2160p?|50\s?fps|60\s?fps|25\s?fps|backup|bk|vip|multi|raw|ott|tv\b(?=\s*$))\b/g, ' ');
  s = s.replace(/&/g, 'y').replace(/\+(?!\s*\d)/g, ''); // «Plus+» = «Plus», pero «+1» se mantiene
  return s.replace(/[^a-z0-9+]/g, '');
}

function xmlDecode(s) {
  return String(s || '')
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&amp;/g, '&');
}

function xmlAttr(tag, name) {
  const m = tag.match(new RegExp(`\\s${name}\\s*=\\s*"([^"]*)"`)) || tag.match(new RegExp(`\\s${name}\\s*=\\s*'([^']*)'`));
  return m ? xmlDecode(m[1]) : '';
}

/* Elige el texto en español si hay varios idiomas, y quita marcas de color de Kodi */
function xmlPick(block, tagName) {
  const re = new RegExp(`<${tagName}\\b([^>]*)>([\\s\\S]*?)</${tagName}>`, 'g');
  let first = null;
  let es = null;
  let m;
  while ((m = re.exec(block))) {
    const lang = xmlAttr(m[1], 'lang');
    if (first == null) first = m[2];
    if (lang === 'es' && es == null) es = m[2];
  }
  const raw = es ?? first;
  if (raw == null) return '';
  return xmlDecode(raw)
    .replace(/\[\/?(?:COLOR|B|I)[^\]]*\]/gi, '')
    .trim();
}

/* Diferencia entre la hora de España peninsular y la UTC en un instante (minutos), con horario de verano */
let madridFmt = null;
const madridOff = new Map();
function madridOffset(utcMs) {
  const key = Math.floor(utcMs / 3600000);
  if (madridOff.has(key)) return madridOff.get(key);
  let off = 60;
  try {
    madridFmt ||= new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Europe/Madrid', hourCycle: 'h23',
      year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit',
    });
    const p = {};
    for (const x of madridFmt.formatToParts(new Date(key * 3600000))) p[x.type] = x.value;
    off = (Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute) - key * 3600000) / 60000;
  } catch {}
  madridOff.set(key, off);
  return off;
}

/* «20261025120000» leído como hora de reloj en España → milisegundos UTC */
function madridWall(wallAsUtc) {
  const guess = wallAsUtc - madridOffset(wallAsUtc - 3600000) * 60000;
  return wallAsUtc - madridOffset(guess) * 60000;
}

/* «20261024070000 +0200» → milisegundos.
   Con spain = true se usa la hora tal cual en horario de España y se ignora la zona que
   indica el archivo: la guía de dobleM mantiene «+0200» en muchos canales después del
   cambio al horario de invierno, y la programación saldría con una hora de diferencia. */
function xmltvTime(s, spain = false) {
  const m = String(s).match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})?\s*([+-]\d{4})?/);
  if (!m) return 0;
  let t = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
  if (spain) return madridWall(t);
  if (m[7]) {
    const sign = m[7][0] === '-' ? -1 : 1;
    const off = (+m[7].slice(1, 3) * 60 + +m[7].slice(3, 5)) * 60000;
    t -= sign * off;
  }
  return t;
}

/* Análisis por partes: recibe trozos de texto y va guardando canales y programas */
function makeXmltvParser({ spain = false } = {}) {
  const now = Date.now();
  const from = now - XMLTV_BEFORE;
  // en la tele (Fire TV Stick, poca memoria) se guardan menos horas
  const to = now + (typeof IS_TV !== 'undefined' && IS_TV ? 14 * 3600 * 1000 : XMLTV_AFTER);
  const names = {};
  const progs = {};
  let buf = '';
  let count = 0;
  let channelsDone = false; // en XMLTV los canales van antes que los programas

  function handle(block, isProg) {
    const open = block.slice(0, block.indexOf('>') + 1);
    if (!isProg) {
      const id = xmlAttr(open, 'id');
      if (!id) return;
      const add = (n) => {
        const k = xmltvNorm(n);
        if (k && !(k in names)) names[k] = id;
      };
      add(id);
      const re = /<display-name\b[^>]*>([\s\S]*?)<\/display-name>/g;
      let m;
      while ((m = re.exec(block))) add(xmlDecode(m[1]));
      return;
    }
    const start = xmltvTime(xmlAttr(open, 'start'), spain);
    const end = xmltvTime(xmlAttr(open, 'stop'), spain) || start + 30 * 60000;
    if (!start || end < from || start > to) return;
    const ch = xmlAttr(open, 'channel');
    if (!ch) return;
    const title = xmlPick(block, 'title') || 'Sin título';
    let desc = xmlPick(block, 'desc').replace(/\s*\n\s*/g, ' ');
    if (desc.length > 400) desc = desc.slice(0, 397) + '…';
    (progs[ch] ||= []).push([start, end, title, desc]);
    count++;
  }

  return {
    push(chunk) {
      buf += chunk;
      let pos = 0;
      for (;;) {
        const p = buf.indexOf('<programme', pos);
        const c = channelsDone ? -1 : buf.indexOf('<channel', pos);
        if (p < 0 && c < 0) {
          pos = buf.length;
          break;
        }
        const isProg = c < 0 || (p >= 0 && p < c);
        if (isProg) channelsDone = true;
        const startAt = isProg ? p : c;
        const close = isProg ? '</programme>' : '</channel>';
        const end = buf.indexOf(close, startAt);
        if (end < 0) {
          pos = startAt;
          break;
        }
        handle(buf.slice(startAt, end + close.length), isProg);
        pos = end + close.length;
      }
      // conservar solo lo que falta por completar
      buf = buf.slice(Math.min(pos, buf.length));
      if (buf.length > 4e6) buf = buf.slice(-1e5);
    },
    finish() {
      for (const list of Object.values(progs)) list.sort((a, b) => a[0] - b[0]);
      return { names, progs, count };
    },
  };
}

async function xmltvParseBytes(bytes, opts) {
  const parser = makeXmltvParser(opts);
  const gz = bytes.length > 2 && bytes[0] === 0x1f && bytes[1] === 0x8b;
  if (gz && typeof DecompressionStream === 'undefined') {
    throw new Error('Este dispositivo no puede descomprimir la guía; usa una dirección .xml sin comprimir.');
  }
  let stream = new Blob([bytes]).stream();
  if (gz) stream = stream.pipeThrough(new DecompressionStream('gzip'));
  const reader = stream.pipeThrough(new TextDecoderStream('utf-8')).getReader();
  let pending = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (value) pending += value;
    // analizar en bloques de ~1 MB y dejar respirar a la interfaz entre bloques
    if (pending.length > 1e6 || (done && pending)) {
      parser.push(pending);
      pending = '';
      await new Promise((r) => setTimeout(r, 0));
    }
    if (done) break;
  }
  return parser.finish();
}

function xmltvUrls() {
  const st = S.store?.settings || {};
  if ((st.extEpg || 'on') === 'off') return [];
  const custom = String(st.extEpgUrl || '').trim();
  return custom ? custom.split(/\s+/).filter((u) => /^https?:\/\//i.test(u)) : [XMLTV_DEFAULT_URL];
}

function extEpgEnabled() {
  // modo seguro (la app se cerró por falta de memoria): sin guía externa en esta sesión
  if (window.ZAPPING_SAFE) return false;
  return xmltvUrls().length > 0;
}

async function xmltvLoad(force = false) {
  const urls = xmltvUrls();
  if (!urls.length) return null;
  const key = `v2|${S.store?.settings?.extEpgTz || 'auto'}|` + urls.join(' ');
  if (!force && XmlTv.data && XmlTv.data.url === key && Date.now() - XmlTv.data.at < XMLTV_MAX_AGE) return XmlTv.data;
  if (XmlTv.loading) return XmlTv.loading;
  XmlTv.loading = (async () => {
    try {
      if (!force) {
        const cached = await api.getCache('__xmltv');
        if (cached && cached.url === key && Date.now() - cached.at < XMLTV_MAX_AGE) {
          XmlTv.data = cached;
          return cached;
        }
      }
      const merged = { at: Date.now(), url: key, names: {}, progs: {} };
      let ok = 0;
      let lastErr = '';
      for (const url of urls) {
        const r = await api.httpBinary(url);
        if (r.error) {
          lastErr = r.error;
          continue;
        }
        // guías de España (dobleM y similares): horas en horario de España
        const tzMode = S.store?.settings?.extEpgTz || 'auto';
        const spain = tzMode === 'spain' || (tzMode === 'auto' && /dobleM|davidmuma/i.test(url));
        const res = await xmltvParseBytes(r.data, { spain });
        for (const [k, v] of Object.entries(res.names)) if (!(k in merged.names)) merged.names[k] = v;
        for (const [k, v] of Object.entries(res.progs)) if (!merged.progs[k]) merged.progs[k] = v;
        ok++;
      }
      if (!ok) throw new Error(lastErr || 'No se ha podido descargar la guía externa.');
      XmlTv.data = merged;
      XmlTv.error = null;
      api.setCache('__xmltv', merged);
      return merged;
    } catch (e) {
      XmlTv.error = e.message;
      // si falla, seguir con la copia anterior aunque sea antigua
      if (!XmlTv.data) XmlTv.data = (await api.getCache('__xmltv')) || null;
      return XmlTv.data;
    } finally {
      XmlTv.loading = null;
    }
  })();
  return XmlTv.loading;
}

function xmltvChannelFor(it, data) {
  if (!data) return null;
  if (it.epg && data.progs[it.epg]) return it.epg;
  for (const cand of [it.epg, it.name]) {
    const k = xmltvNorm(cand);
    if (k && data.names[k]) return data.names[k];
  }
  // «La 1 HD Madrid» → probar quitando palabras del final
  const words = String(it.name || '').split(/\s+/);
  for (let n = words.length - 1; n >= Math.max(1, words.length - 2); n--) {
    const k = xmltvNorm(words.slice(0, n).join(' '));
    if (k.length >= 3 && data.names[k]) return data.names[k];
  }
  return null;
}

async function extEpgLookup(it, { past = false } = {}) {
  const data = await xmltvLoad();
  const id = xmltvChannelFor(it, data);
  if (!id) return [];
  const now = Date.now();
  return (data.progs[id] || [])
    .filter((p) => (past ? p[1] > now - 4 * 3600000 : p[1] > now))
    .slice(0, 24)
    .map(([start, end, title, desc]) => ({ start, end, title, desc, src: 'ext' }));
}
